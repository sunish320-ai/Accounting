import React, { createContext, useContext, useState, useEffect, useMemo, ReactNode } from 'react';
import {
  Currency,
  CurrencyCode,
  TaxJurisdiction,
  TaxRate,
  TDSRate,
  Customer,
  Vendor,
  Invoice,
  Bill,
  BankAccount,
  BankTransaction,
  RecurringInvoiceConfig,
  PaymentReminderRule,
  ChartOfAccount,
  JournalEntry,
  OrganizationSettings,
  InvoiceItem,
  Estimate,
  SalesOrder,
  CreditNote,
  PurchaseOrder,
  Expense,
  DebitNote
} from '../types';
import {
  INITIAL_CURRENCIES,
  TAX_RATES,
  TDS_RATES,
  INITIAL_SETTINGS,
  INITIAL_CUSTOMERS,
  INITIAL_VENDORS,
  INITIAL_INVOICES,
  INITIAL_BILLS,
  INITIAL_BANK_ACCOUNTS,
  INITIAL_BANK_TRANSACTIONS,
  INITIAL_RECURRING_CONFIGS,
  INITIAL_REMINDER_RULES,
  INITIAL_CHART_OF_ACCOUNTS,
  INITIAL_JOURNAL_ENTRIES,
  INITIAL_ESTIMATES,
  INITIAL_SALES_ORDERS,
  INITIAL_CREDIT_NOTES,
  INITIAL_PURCHASE_ORDERS,
  INITIAL_EXPENSES,
  INITIAL_DEBIT_NOTES
} from '../data/mockData';
import {
  SAMPLE_CUSTOMERS,
  SAMPLE_VENDORS,
  SAMPLE_BANK_ACCOUNTS,
  SAMPLE_INVOICES,
  SAMPLE_BILLS,
  SAMPLE_EXPENSES
} from '../data/sampleDataset';
import { BackupPayload } from '../utils/exportHelper';

interface CashFlowProjectionItem {
  period: string; // e.g., 'Nov 1 - 10', 'Nov 11 - 20', etc.
  cashIn: number;
  cashOut: number;
  net: number;
  runningBalance: number;
}

interface AgingSummary {
  current: number;
  days1_30: number;
  days31_60: number;
  days61_90: number;
  days90Plus: number;
  total: number;
}

interface AccountingContextType {
  // Settings & Jurisdiction
  settings: OrganizationSettings;
  updateSettings: (newSettings: Partial<OrganizationSettings>) => void;
  setJurisdiction: (j: TaxJurisdiction) => void;

  // Currencies & Exchange Rates
  currencies: Currency[];
  selectedDisplayCurrency: CurrencyCode;
  setDisplayCurrency: (code: CurrencyCode) => void;
  convertAmount: (amount: number, from: CurrencyCode, to: CurrencyCode) => number;
  formatMoney: (amount: number, currencyCode?: CurrencyCode) => string;
  updateExchangeRate: (code: CurrencyCode, newRate: number) => void;
  syncLiveFxRates: () => Promise<void>;

  // Taxes
  taxRates: TaxRate[];
  tdsRates: TDSRate[];

  // Customers & Vendors
  customers: Customer[];
  vendors: Vendor[];
  addCustomer: (c: Omit<Customer, 'id'>) => Customer;
  updateCustomer: (id: string, partial: Partial<Customer>) => void;
  deleteCustomer: (id: string) => void;
  duplicateCustomer: (id: string) => Customer;
  addVendor: (v: Omit<Vendor, 'id'>) => Vendor;
  updateVendor: (id: string, partial: Partial<Vendor>) => void;
  deleteVendor: (id: string) => void;
  duplicateVendor: (id: string) => Vendor;

  // Sales Workflow: Estimates, Orders, Invoices, Returns (Credit Notes)
  estimates: Estimate[];
  createEstimate: (est: Omit<Estimate, 'id'>) => Estimate;
  updateEstimate: (id: string, partial: Partial<Estimate>) => void;
  deleteEstimate: (id: string) => void;
  duplicateEstimate: (id: string) => Estimate;
  convertEstimateToSalesOrder: (id: string) => SalesOrder;
  convertEstimateToInvoice: (id: string) => Invoice;

  salesOrders: SalesOrder[];
  createSalesOrder: (so: Omit<SalesOrder, 'id'>) => SalesOrder;
  updateSalesOrder: (id: string, partial: Partial<SalesOrder>) => void;
  deleteSalesOrder: (id: string) => void;
  duplicateSalesOrder: (id: string) => SalesOrder;
  convertSalesOrderToInvoice: (id: string) => Invoice;

  creditNotes: CreditNote[];
  createCreditNote: (cn: Omit<CreditNote, 'id' | 'refundedAmount'>) => CreditNote;
  updateCreditNote: (id: string, partial: Partial<CreditNote>) => void;
  deleteCreditNote: (id: string) => void;
  duplicateCreditNote: (id: string) => CreditNote;

  // Invoices (Sales Invoices)
  invoices: Invoice[];
  createInvoice: (inv: Omit<Invoice, 'id' | 'balanceDue' | 'remindersSent'>) => Invoice;
  updateInvoice: (id: string, partial: Partial<Invoice>) => void;
  deleteInvoice: (id: string) => void;
  duplicateInvoice: (id: string) => Invoice;
  recordInvoicePayment: (invoiceId: string, amount: number, tdsDeducted: number, bankAccountId: string, notes?: string) => void;
  sendPaymentReminder: (invoiceId: string, channel: 'email' | 'whatsapp', customMsg?: string) => void;
  voidInvoice: (id: string) => void;

  // Purchases Workflow: Purchase Orders, Bills, Expenses, Purchase Returns (Debit Notes)
  purchaseOrders: PurchaseOrder[];
  createPurchaseOrder: (po: Omit<PurchaseOrder, 'id'>) => PurchaseOrder;
  updatePurchaseOrder: (id: string, partial: Partial<PurchaseOrder>) => void;
  deletePurchaseOrder: (id: string) => void;
  duplicatePurchaseOrder: (id: string) => PurchaseOrder;
  convertPurchaseOrderToBill: (id: string) => Bill;

  expenses: Expense[];
  createExpense: (exp: Omit<Expense, 'id'>) => Expense;
  updateExpense: (id: string, partial: Partial<Expense>) => void;
  deleteExpense: (id: string) => void;
  duplicateExpense: (id: string) => Expense;

  debitNotes: DebitNote[];
  createDebitNote: (dn: Omit<DebitNote, 'id'>) => DebitNote;
  updateDebitNote: (id: string, partial: Partial<DebitNote>) => void;
  deleteDebitNote: (id: string) => void;
  duplicateDebitNote: (id: string) => DebitNote;

  // Bills (Accounts Payable)
  bills: Bill[];
  createBill: (bill: Omit<Bill, 'id' | 'netPayable' | 'balanceDue'>) => Bill;
  updateBill: (id: string, partial: Partial<Bill>) => void;
  deleteBill: (id: string) => void;
  duplicateBill: (id: string) => Bill;
  recordBillPayment: (billId: string, amount: number, bankAccountId: string, refNo?: string) => void;

  // Recurring & Reminders
  recurringConfigs: RecurringInvoiceConfig[];
  createRecurringConfig: (cfg: Omit<RecurringInvoiceConfig, 'id'>) => void;
  toggleRecurringConfig: (id: string) => void;
  triggerRecurringRunNow: (id: string) => Invoice;
  reminderRules: PaymentReminderRule[];
  updateReminderRule: (id: string, partial: Partial<PaymentReminderRule>) => void;
  runAutomatedRemindersCheck: () => { count: number; messages: string[] };

  // Banking & Feeds
  bankAccounts: BankAccount[];
  bankTransactions: BankTransaction[];
  isSyncingBank: boolean;
  syncBankFeeds: () => Promise<void>;
  reconcileTransaction: (txnId: string, matchType: 'invoice' | 'bill' | 'manual', entityId?: string, description?: string) => void;
  excludeTransaction: (txnId: string) => void;
  importBankStatement: (bankAccountId: string, newTxns: Partial<BankTransaction>[]) => void;
  connectNewBankAccount: (acc: Omit<BankAccount, 'id' | 'lastSyncedAt'>) => void;
  updateBankAccount: (id: string, partial: Partial<BankAccount>) => void;
  deleteBankAccount: (id: string) => void;
  duplicateBankAccount: (id: string) => BankAccount;

  // Chart of Accounts & General Ledger
  chartOfAccounts: ChartOfAccount[];
  journalEntries: JournalEntry[];
  addJournalEntry: (entry: Omit<JournalEntry, 'id'>) => void;

  // Dashboard Aggregates
  cashFlowForecast: CashFlowProjectionItem[];
  apAging: AgingSummary;
  arAging: AgingSummary;
  totalCashBalanceBase: number;
  totalReceivablesBase: number;
  totalPayablesBase: number;
  totalTdsPayableBase: number;
  totalTdsReceivableBase: number;
  netIncomeBase: number;

  // Reset & Backup Data
  resetToDemoData: () => void;
  resetToFreshBlank: () => void;
  clearAllTransactions: () => void;
  loadDemoSampleData: () => void;
  restoreFromJson: (jsonData: string) => boolean;
  getBackupPayload: () => BackupPayload;
}

const STORAGE_KEY = 'ledgerpulse_books_v4';

const AccountingContext = createContext<AccountingContextType | undefined>(undefined);

export const AccountingProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  // Load from LocalStorage or initialize with mock data
  const loadInitial = () => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        return JSON.parse(stored);
      }
    } catch (e) {
      console.warn('Failed to read from localStorage', e);
    }
    return null;
  };

  const initial = loadInitial();

  const [settings, setSettings] = useState<OrganizationSettings>(initial?.settings || INITIAL_SETTINGS);
  const [currencies, setCurrencies] = useState<Currency[]>(initial?.currencies || INITIAL_CURRENCIES);
  const [selectedDisplayCurrency, setSelectedDisplayCurrency] = useState<CurrencyCode>(settings.baseCurrency || 'INR');
  const [taxRates] = useState<TaxRate[]>(TAX_RATES);
  const [tdsRates] = useState<TDSRate[]>(TDS_RATES);
  const [customers, setCustomers] = useState<Customer[]>(initial?.customers || INITIAL_CUSTOMERS);
  const [vendors, setVendors] = useState<Vendor[]>(initial?.vendors || INITIAL_VENDORS);
  const [invoices, setInvoices] = useState<Invoice[]>(initial?.invoices || INITIAL_INVOICES);
  const [estimates, setEstimates] = useState<Estimate[]>(initial?.estimates || INITIAL_ESTIMATES);
  const [salesOrders, setSalesOrders] = useState<SalesOrder[]>(initial?.salesOrders || INITIAL_SALES_ORDERS);
  const [creditNotes, setCreditNotes] = useState<CreditNote[]>(initial?.creditNotes || INITIAL_CREDIT_NOTES);
  const [purchaseOrders, setPurchaseOrders] = useState<PurchaseOrder[]>(initial?.purchaseOrders || INITIAL_PURCHASE_ORDERS);
  const [bills, setBills] = useState<Bill[]>(initial?.bills || INITIAL_BILLS);
  const [expenses, setExpenses] = useState<Expense[]>(initial?.expenses || INITIAL_EXPENSES);
  const [debitNotes, setDebitNotes] = useState<DebitNote[]>(initial?.debitNotes || INITIAL_DEBIT_NOTES);
  const [bankAccounts, setBankAccounts] = useState<BankAccount[]>(initial?.bankAccounts || INITIAL_BANK_ACCOUNTS);
  const [bankTransactions, setBankTransactions] = useState<BankTransaction[]>(initial?.bankTransactions || INITIAL_BANK_TRANSACTIONS);
  const [recurringConfigs, setRecurringConfigs] = useState<RecurringInvoiceConfig[]>(initial?.recurringConfigs || INITIAL_RECURRING_CONFIGS);
  const [reminderRules, setReminderRules] = useState<PaymentReminderRule[]>(initial?.reminderRules || INITIAL_REMINDER_RULES);
  const [chartOfAccounts, setChartOfAccounts] = useState<ChartOfAccount[]>(initial?.chartOfAccounts || INITIAL_CHART_OF_ACCOUNTS);
  const [journalEntries, setJournalEntries] = useState<JournalEntry[]>(initial?.journalEntries || INITIAL_JOURNAL_ENTRIES);
  const [isSyncingBank, setIsSyncingBank] = useState<boolean>(false);

  // Sync to LocalStorage on changes
  useEffect(() => {
    try {
      const stateToSave = {
        settings,
        currencies,
        customers,
        vendors,
        invoices,
        estimates,
        salesOrders,
        creditNotes,
        purchaseOrders,
        bills,
        expenses,
        debitNotes,
        bankAccounts,
        bankTransactions,
        recurringConfigs,
        reminderRules,
        chartOfAccounts,
        journalEntries
      };
      localStorage.setItem(STORAGE_KEY, JSON.stringify(stateToSave));
    } catch (err) {
      console.error('Error saving state to localStorage', err);
    }
  }, [
    settings,
    currencies,
    customers,
    vendors,
    invoices,
    estimates,
    salesOrders,
    creditNotes,
    purchaseOrders,
    bills,
    expenses,
    debitNotes,
    bankAccounts,
    bankTransactions,
    recurringConfigs,
    reminderRules,
    chartOfAccounts,
    journalEntries
  ]);

  // Currency Conversion Helpers
  const convertAmount = (amount: number, from: CurrencyCode, to: CurrencyCode): number => {
    if (from === to) return amount;
    const fromCur = currencies.find(c => c.code === from) || { exchangeRateToBase: 1 };
    const toCur = currencies.find(c => c.code === to) || { exchangeRateToBase: 1 };
    // Convert to base currency first (multiplying by fromCur.exchangeRateToBase)
    const amountInBase = amount * fromCur.exchangeRateToBase;
    // Then convert to target currency (dividing by toCur.exchangeRateToBase)
    return amountInBase / toCur.exchangeRateToBase;
  };

  const formatMoney = (amount: number, currencyCode?: CurrencyCode): string => {
    const code = currencyCode || selectedDisplayCurrency;
    const cur = currencies.find(c => c.code === code);
    const symbol = cur ? cur.symbol : '$';
    
    // Format with 2 decimal places and locale separators
    const formatted = Math.abs(amount).toLocaleString(code === 'INR' ? 'en-IN' : 'en-US', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    });

    return amount < 0 ? `-${symbol}${formatted}` : `${symbol}${formatted}`;
  };

  const updateExchangeRate = (code: CurrencyCode, newRate: number) => {
    setCurrencies(prev => prev.map(c => c.code === code ? { ...c, exchangeRateToBase: newRate } : c));
  };

  const syncLiveFxRates = async () => {
    // Simulate real-time FX API refresh with realistic market ticks
    await new Promise(r => setTimeout(r, 600));
    setCurrencies(prev => prev.map(c => {
      if (c.code === 'INR') return c;
      const jitter = (Math.random() - 0.48) * 0.15; // slight random fluctuation
      const updatedRate = Number((c.exchangeRateToBase * (1 + jitter / 100)).toFixed(2));
      return { ...c, exchangeRateToBase: updatedRate };
    }));
  };

  const updateSettings = (newSettings: Partial<OrganizationSettings>) => {
    setSettings(prev => ({ ...prev, ...newSettings }));
  };

  const setJurisdiction = (j: TaxJurisdiction) => {
    setSettings(prev => ({
      ...prev,
      jurisdiction: j,
      baseCurrency: j === 'INDIA' ? 'INR' : j === 'USA' ? 'USD' : j === 'UK_EU' ? 'GBP' : 'AED'
    }));
  };

  // Customers & Vendors
  const addCustomer = (c: Omit<Customer, 'id'>): Customer => {
    const newCust: Customer = {
      ...c,
      id: `cust-${Date.now()}`
    };
    setCustomers(prev => [newCust, ...prev]);
    return newCust;
  };

  const updateCustomer = (id: string, partial: Partial<Customer>) => {
    setCustomers(prev => prev.map(c => c.id === id ? { ...c, ...partial } : c));
  };

  const deleteCustomer = (id: string) => {
    setCustomers(prev => prev.filter(c => c.id !== id));
  };

  const duplicateCustomer = (id: string): Customer => {
    const cust = customers.find(c => c.id === id);
    if (!cust) throw new Error('Customer not found');
    const newCust: Customer = {
      ...cust,
      id: `cust-${Date.now()}`,
      name: `${cust.name} (Copy)`,
      companyName: `${cust.companyName} (Copy)`,
    };
    setCustomers(prev => [newCust, ...prev]);
    return newCust;
  };

  const addVendor = (v: Omit<Vendor, 'id'>): Vendor => {
    const newVendor: Vendor = {
      ...v,
      id: `vend-${Date.now()}`
    };
    setVendors(prev => [newVendor, ...prev]);
    return newVendor;
  };

  const updateVendor = (id: string, partial: Partial<Vendor>) => {
    setVendors(prev => prev.map(v => v.id === id ? { ...v, ...partial } : v));
  };

  const deleteVendor = (id: string) => {
    setVendors(prev => prev.filter(v => v.id !== id));
  };

  const duplicateVendor = (id: string): Vendor => {
    const vend = vendors.find(v => v.id === id);
    if (!vend) throw new Error('Vendor not found');
    const newVend: Vendor = {
      ...vend,
      id: `vend-${Date.now()}`,
      name: `${vend.name} (Copy)`,
      companyName: `${vend.companyName} (Copy)`,
    };
    setVendors(prev => [newVend, ...prev]);
    return newVend;
  };

  // Estimates
  const createEstimate = (est: Omit<Estimate, 'id'>): Estimate => {
    const newEst: Estimate = { ...est, id: `est-${Date.now()}` };
    setEstimates(prev => [newEst, ...prev]);
    return newEst;
  };

  const updateEstimate = (id: string, partial: Partial<Estimate>) => {
    setEstimates(prev => prev.map(e => e.id === id ? { ...e, ...partial } : e));
  };

  const deleteEstimate = (id: string) => {
    setEstimates(prev => prev.filter(e => e.id !== id));
  };

  const duplicateEstimate = (id: string): Estimate => {
    const est = estimates.find(e => e.id === id);
    if (!est) throw new Error('Estimate not found');
    const newEst: Estimate = {
      ...est,
      id: `est-${Date.now()}`,
      estimateNumber: `EST-${Date.now().toString().slice(-4)}`,
      status: 'draft',
      convertedInvoiceId: undefined,
      convertedSalesOrderId: undefined,
    };
    setEstimates(prev => [newEst, ...prev]);
    return newEst;
  };

  const convertEstimateToSalesOrder = (id: string): SalesOrder => {
    const est = estimates.find(e => e.id === id);
    if (!est) throw new Error('Estimate not found');
    const newSo: SalesOrder = {
      id: `so-${Date.now()}`,
      orderNumber: `SO-2026-${salesOrders.length + 30}`,
      estimateId: est.id,
      customerId: est.customerId,
      customerName: est.customerName,
      customerTaxId: est.customerTaxId,
      placeOfSupply: est.placeOfSupply,
      date: new Date().toISOString().split('T')[0],
      expectedDeliveryDate: new Date(Date.now() + 15 * 86400000).toISOString().split('T')[0],
      status: 'confirmed',
      currency: est.currency,
      exchangeRate: est.exchangeRate,
      items: est.items,
      subtotal: est.subtotal,
      totalTax: est.totalTax,
      totalAmount: est.totalAmount,
      notes: `Generated from estimate ${est.estimateNumber}. ${est.notes}`
    };
    setSalesOrders(prev => [newSo, ...prev]);
    updateEstimate(est.id, { status: 'accepted', convertedSalesOrderId: newSo.id });
    return newSo;
  };

  const convertEstimateToInvoice = (id: string): Invoice => {
    const est = estimates.find(e => e.id === id);
    if (!est) throw new Error('Estimate not found');
    const newInv = createInvoice({
      invoiceNumber: `INV-2026-00${invoices.length + 50}`,
      customerId: est.customerId,
      customerName: est.customerName,
      customerTaxId: est.customerTaxId,
      placeOfSupply: est.placeOfSupply,
      isInterState: est.isInterState,
      issueDate: new Date().toISOString().split('T')[0],
      dueDate: new Date(Date.now() + 30 * 86400000).toISOString().split('T')[0],
      status: 'draft',
      currency: est.currency,
      exchangeRate: est.exchangeRate,
      items: est.items,
      subtotal: est.subtotal,
      discountTotal: est.discountTotal,
      cgstTotal: est.isInterState ? 0 : est.totalTax / 2,
      sgstTotal: est.isInterState ? 0 : est.totalTax / 2,
      igstTotal: est.isInterState ? est.totalTax : 0,
      totalTax: est.totalTax,
      totalAmount: est.totalAmount,
      baseCurrencyTotal: est.totalAmount * est.exchangeRate,
      paidAmount: 0,
      tdsDeductedByCustomer: 0,
      notes: `Converted from estimate ${est.estimateNumber}. ${est.notes}`,
      terms: est.terms
    });
    updateEstimate(est.id, { status: 'invoiced', convertedInvoiceId: newInv.id });
    return newInv;
  };

  // Sales Orders
  const createSalesOrder = (so: Omit<SalesOrder, 'id'>): SalesOrder => {
    const newSo: SalesOrder = { ...so, id: `so-${Date.now()}` };
    setSalesOrders(prev => [newSo, ...prev]);
    return newSo;
  };

  const updateSalesOrder = (id: string, partial: Partial<SalesOrder>) => {
    setSalesOrders(prev => prev.map(s => s.id === id ? { ...s, ...partial } : s));
  };

  const deleteSalesOrder = (id: string) => {
    setSalesOrders(prev => prev.filter(s => s.id !== id));
  };

  const duplicateSalesOrder = (id: string): SalesOrder => {
    const so = salesOrders.find(s => s.id === id);
    if (!so) throw new Error('Sales Order not found');
    const newSo: SalesOrder = {
      ...so,
      id: `so-${Date.now()}`,
      orderNumber: `SO-${Date.now().toString().slice(-4)}`,
      status: 'draft',
      convertedInvoiceId: undefined,
    };
    setSalesOrders(prev => [newSo, ...prev]);
    return newSo;
  };

  const convertSalesOrderToInvoice = (id: string): Invoice => {
    const so = salesOrders.find(s => s.id === id);
    if (!so) throw new Error('Sales Order not found');
    const isInterState = !so.placeOfSupply.includes('Maharashtra');
    const newInv = createInvoice({
      invoiceNumber: `INV-2026-00${invoices.length + 50}`,
      customerId: so.customerId,
      customerName: so.customerName,
      customerTaxId: so.customerTaxId,
      placeOfSupply: so.placeOfSupply,
      isInterState,
      issueDate: new Date().toISOString().split('T')[0],
      dueDate: new Date(Date.now() + 30 * 86400000).toISOString().split('T')[0],
      status: 'draft',
      currency: so.currency,
      exchangeRate: so.exchangeRate,
      items: so.items,
      subtotal: so.subtotal,
      discountTotal: 0,
      cgstTotal: isInterState ? 0 : so.totalTax / 2,
      sgstTotal: isInterState ? 0 : so.totalTax / 2,
      igstTotal: isInterState ? so.totalTax : 0,
      totalTax: so.totalTax,
      totalAmount: so.totalAmount,
      baseCurrencyTotal: so.totalAmount * so.exchangeRate,
      paidAmount: 0,
      tdsDeductedByCustomer: 0,
      notes: `Converted from Sales Order ${so.orderNumber}. ${so.notes}`,
      terms: 'Net 30 days.'
    });
    updateSalesOrder(so.id, { status: 'invoiced', convertedInvoiceId: newInv.id });
    return newInv;
  };

  // Credit Notes (Sales Returns)
  const createCreditNote = (cn: Omit<CreditNote, 'id' | 'refundedAmount'>): CreditNote => {
    const newCn: CreditNote = {
      ...cn,
      id: `cn-${Date.now()}`,
      refundedAmount: 0
    };
    setCreditNotes(prev => [newCn, ...prev]);

    if (cn.invoiceId) {
      setInvoices(prev => prev.map(inv => {
        if (inv.id === cn.invoiceId) {
          const newBalance = Math.max(0, inv.balanceDue - cn.totalAmount);
          return {
            ...inv,
            balanceDue: newBalance,
            status: newBalance <= 0.01 ? 'paid' : inv.status
          };
        }
        return inv;
      }));
    }

    const je: JournalEntry = {
      id: `je-cn-${Date.now()}`,
      entryNumber: `JE-CN-${Date.now().toString().slice(-4)}`,
      date: cn.date,
      reference: cn.creditNoteNumber,
      narration: `Credit Note / Sales Return issued to ${cn.customerName} for ${cn.reason}`,
      lines: [
        { accountCode: '4000', accountName: 'Domestic Software Revenue (Credit Return)', debit: cn.subtotal * cn.exchangeRate, credit: 0, description: 'Sales reversal' },
        ...(cn.totalTax > 0 ? [{ accountCode: '2100', accountName: 'GST Output Liability (Reversal)', debit: cn.totalTax * cn.exchangeRate, credit: 0, description: 'GST reduction under Sec 34(1)' }] : []),
        { accountCode: '1100', accountName: 'Accounts Receivable', debit: 0, credit: cn.totalAmount * cn.exchangeRate, description: `Receivable reduction for ${cn.customerName}` }
      ],
      totalDebit: cn.totalAmount * cn.exchangeRate,
      totalCredit: cn.totalAmount * cn.exchangeRate
    };
    setJournalEntries(prev => [je, ...prev]);

    return newCn;
  };

  const updateCreditNote = (id: string, partial: Partial<CreditNote>) => {
    setCreditNotes(prev => prev.map(c => c.id === id ? { ...c, ...partial } : c));
  };

  const deleteCreditNote = (id: string) => {
    setCreditNotes(prev => prev.filter(c => c.id !== id));
  };

  const duplicateCreditNote = (id: string): CreditNote => {
    const cn = creditNotes.find(c => c.id === id);
    if (!cn) throw new Error('Credit Note not found');
    const newCn: CreditNote = {
      ...cn,
      id: `cn-${Date.now()}`,
      creditNoteNumber: `CN-${Date.now().toString().slice(-4)}`,
      status: 'draft',
      refundedAmount: 0,
    };
    setCreditNotes(prev => [newCn, ...prev]);
    return newCn;
  };

  // Invoices & Sales
  const createInvoice = (inv: Omit<Invoice, 'id' | 'balanceDue' | 'remindersSent'>): Invoice => {
    const id = `inv-${Date.now()}`;
    const balanceDue = inv.totalAmount - (inv.paidAmount || 0);
    const newInvoice: Invoice = {
      ...inv,
      id,
      balanceDue,
      remindersSent: []
    };

    setInvoices(prev => [newInvoice, ...prev]);

    // Automatically create a Journal Entry for Double Entry Bookkeeping
    const isExport = inv.placeOfSupply.includes('Overseas') || inv.items.some(it => it.taxRateId === 'tax-gst-0');
    const revenueAccount = isExport ? '4100' : '4000';
    const revenueAccountName = isExport ? 'Export of Software Services' : 'Domestic Software Revenue';

    const journalLines = [
      {
        accountCode: '1100',
        accountName: 'Accounts Receivable',
        debit: inv.baseCurrencyTotal,
        credit: 0,
        description: `Receivable for ${inv.invoiceNumber} (${inv.customerName})`
      },
      {
        accountCode: revenueAccount,
        accountName: revenueAccountName,
        debit: 0,
        credit: inv.subtotal * inv.exchangeRate,
        description: `Revenue from ${inv.invoiceNumber}`
      }
    ];

    if (inv.cgstTotal > 0) {
      journalLines.push({
        accountCode: '2100',
        accountName: 'GST Output Liability - CGST Payable',
        debit: 0,
        credit: inv.cgstTotal * inv.exchangeRate,
        description: `CGST Output on ${inv.invoiceNumber}`
      });
    }
    if (inv.sgstTotal > 0) {
      journalLines.push({
        accountCode: '2110',
        accountName: 'GST Output Liability - SGST Payable',
        debit: 0,
        credit: inv.sgstTotal * inv.exchangeRate,
        description: `SGST Output on ${inv.invoiceNumber}`
      });
    }
    if (inv.igstTotal > 0) {
      journalLines.push({
        accountCode: '2120',
        accountName: 'GST Output Liability - IGST Payable',
        debit: 0,
        credit: inv.igstTotal * inv.exchangeRate,
        description: `IGST Output on ${inv.invoiceNumber}`
      });
    }

    const journalEntry: JournalEntry = {
      id: `je-${Date.now()}`,
      entryNumber: `JE-2026-${journalEntries.length + 10}`,
      date: inv.issueDate,
      reference: inv.invoiceNumber,
      narration: `Automated journal entry generated on invoice issuance to ${inv.customerName}`,
      lines: journalLines,
      totalDebit: inv.baseCurrencyTotal,
      totalCredit: inv.baseCurrencyTotal
    };

    setJournalEntries(prev => [journalEntry, ...prev]);
    return newInvoice;
  };

  const updateInvoice = (id: string, partial: Partial<Invoice>) => {
    setInvoices(prev => prev.map(inv => {
      if (inv.id !== id) return inv;
      const updated = { ...inv, ...partial };
      if (partial.paidAmount !== undefined || partial.totalAmount !== undefined) {
        updated.balanceDue = (updated.totalAmount || 0) - (updated.paidAmount || 0);
        if (updated.balanceDue <= 0.01) {
          updated.status = 'paid';
        } else if (updated.paidAmount > 0) {
          updated.status = 'partially_paid';
        }
      }
      return updated;
    }));
  };

  const deleteInvoice = (id: string) => {
    setInvoices(prev => prev.filter(inv => inv.id !== id));
  };

  const duplicateInvoice = (id: string): Invoice => {
    const inv = invoices.find(i => i.id === id);
    if (!inv) throw new Error('Invoice not found');
    const newInv = createInvoice({
      ...inv,
      invoiceNumber: `INV-2026-00${invoices.length + 10}`,
      issueDate: new Date().toISOString().split('T')[0],
      dueDate: new Date(Date.now() + 30 * 86400000).toISOString().split('T')[0],
      status: 'draft',
      paidAmount: 0,
      tdsDeductedByCustomer: 0,
    });
    return newInv;
  };

  const voidInvoice = (id: string) => {
    setInvoices(prev => prev.map(inv => inv.id === id ? { ...inv, status: 'void', balanceDue: 0 } : inv));
  };

  const recordInvoicePayment = (
    invoiceId: string,
    amountReceived: number,
    tdsDeducted: number,
    bankAccountId: string,
    notes?: string
  ) => {
    const targetInvoice = invoices.find(inv => inv.id === invoiceId);
    if (!targetInvoice) return;

    const totalSettled = amountReceived + tdsDeducted;
    const newPaidAmount = targetInvoice.paidAmount + totalSettled;
    const newBalanceDue = Math.max(0, targetInvoice.totalAmount - newPaidAmount);
    const newStatus = newBalanceDue <= 0.01 ? 'paid' : 'partially_paid';

    setInvoices(prev => prev.map(inv => inv.id === invoiceId ? {
      ...inv,
      paidAmount: newPaidAmount,
      tdsDeductedByCustomer: inv.tdsDeductedByCustomer + tdsDeducted,
      balanceDue: newBalanceDue,
      status: newStatus
    } : inv));

    // Update bank balance
    setBankAccounts(prev => prev.map(acc => {
      if (acc.id === bankAccountId) {
        return { ...acc, balance: acc.balance + amountReceived };
      }
      return acc;
    }));

    // Record bank transaction
    const newTxn: BankTransaction = {
      id: `txn-${Date.now()}`,
      bankAccountId,
      date: new Date().toISOString().split('T')[0],
      description: `PAYMENT RECEIVED - ${targetInvoice.invoiceNumber} (${targetInvoice.customerName})`,
      amount: amountReceived,
      currency: targetInvoice.currency,
      referenceNumber: `REC-${Date.now().toString().slice(-6)}`,
      matchStatus: 'matched',
      matchedType: 'invoice',
      matchedEntityId: targetInvoice.id,
      matchedEntityDescription: `${targetInvoice.invoiceNumber} (${targetInvoice.customerName})`
    };
    setBankTransactions(prev => [newTxn, ...prev]);

    // Create Payment Journal Entry
    const rate = targetInvoice.exchangeRate;
    const bankDebitBase = amountReceived * rate;
    const tdsDebitBase = tdsDeducted * rate;
    const arCreditBase = totalSettled * rate;

    const pJe: JournalEntry = {
      id: `je-p-${Date.now()}`,
      entryNumber: `JE-PAY-${Date.now().toString().slice(-4)}`,
      date: new Date().toISOString().split('T')[0],
      reference: targetInvoice.invoiceNumber,
      narration: `Payment settlement for ${targetInvoice.invoiceNumber}. Net received in bank: ${amountReceived}, TDS deducted: ${tdsDeducted}. ${notes || ''}`,
      lines: [
        { accountCode: '1010', accountName: 'Bank Operating Account', debit: bankDebitBase, credit: 0, description: 'Bank receipt' },
        ...(tdsDeducted > 0 ? [{ accountCode: '1200', accountName: 'TDS Receivable', debit: tdsDebitBase, credit: 0, description: `TDS withheld by ${targetInvoice.customerName}` }] : []),
        { accountCode: '1100', accountName: 'Accounts Receivable', debit: 0, credit: arCreditBase, description: 'Reduction in receivable' }
      ],
      totalDebit: arCreditBase,
      totalCredit: arCreditBase
    };
    setJournalEntries(prev => [pJe, ...prev]);
  };

  const sendPaymentReminder = (invoiceId: string, channel: 'email' | 'whatsapp', customMsg?: string) => {
    const invoice = invoices.find(inv => inv.id === invoiceId);
    if (!invoice) return;

    const message = customMsg || `Dear ${invoice.customerName}, this is a reminder for Invoice ${invoice.invoiceNumber} for ${formatMoney(invoice.balanceDue, invoice.currency)} which was due on ${invoice.dueDate}.`;
    const newLog = {
      id: `rem-${Date.now()}`,
      date: new Date().toISOString().split('T')[0],
      channel,
      recipient: invoice.customerName,
      message
    };

    setInvoices(prev => prev.map(inv => inv.id === invoiceId ? {
      ...inv,
      remindersSent: [newLog, ...inv.remindersSent]
    } : inv));
  };

  // Purchase Orders
  const createPurchaseOrder = (po: Omit<PurchaseOrder, 'id'>): PurchaseOrder => {
    const newPo: PurchaseOrder = { ...po, id: `po-${Date.now()}` };
    setPurchaseOrders(prev => [newPo, ...prev]);
    return newPo;
  };

  const updatePurchaseOrder = (id: string, partial: Partial<PurchaseOrder>) => {
    setPurchaseOrders(prev => prev.map(p => p.id === id ? { ...p, ...partial } : p));
  };

  const deletePurchaseOrder = (id: string) => {
    setPurchaseOrders(prev => prev.filter(p => p.id !== id));
  };

  const duplicatePurchaseOrder = (id: string): PurchaseOrder => {
    const po = purchaseOrders.find(p => p.id === id);
    if (!po) throw new Error('PO not found');
    const newPo: PurchaseOrder = {
      ...po,
      id: `po-${Date.now()}`,
      poNumber: `PO-${Date.now().toString().slice(-4)}`,
      status: 'draft',
      convertedBillId: undefined,
    };
    setPurchaseOrders(prev => [newPo, ...prev]);
    return newPo;
  };

  const convertPurchaseOrderToBill = (id: string): Bill => {
    const po = purchaseOrders.find(p => p.id === id);
    if (!po) throw new Error('PO not found');
    const newBill = createBill({
      billNumber: `BILL-${po.poNumber.slice(-4)}-${Date.now().toString().slice(-3)}`,
      vendorId: po.vendorId,
      vendorName: po.vendorName,
      vendorTaxId: po.vendorTaxId,
      vendorPan: po.vendorPan,
      billDate: new Date().toISOString().split('T')[0],
      dueDate: new Date(Date.now() + 30 * 86400000).toISOString().split('T')[0],
      status: 'approved',
      currency: po.currency,
      exchangeRate: po.exchangeRate,
      items: po.items,
      subtotal: po.subtotal,
      taxAmount: po.taxAmount,
      grossAmount: po.grossAmount,
      tdsSection: '194C_COMPANY',
      tdsRatePercent: 2,
      tdsAmount: Math.round(po.subtotal * 0.02),
      paidAmount: 0,
      notes: `Converted from PO ${po.poNumber}`,
      category: po.items[0]?.category || 'General Procurement'
    });
    updatePurchaseOrder(po.id, { status: 'billed', convertedBillId: newBill.id });
    return newBill;
  };

  // Expenses (Direct Outlays / Petty Cash / Subs)
  const createExpense = (exp: Omit<Expense, 'id'>): Expense => {
    const newExp: Expense = { ...exp, id: `exp-${Date.now()}` };
    setExpenses(prev => [newExp, ...prev]);

    setBankAccounts(prev => prev.map(acc => {
      if (acc.id === exp.paidThroughBankAccountId) {
        return { ...acc, balance: acc.balance - exp.totalAmount };
      }
      return acc;
    }));

    const newTxn: BankTransaction = {
      id: `txn-exp-${Date.now()}`,
      bankAccountId: exp.paidThroughBankAccountId,
      date: exp.date,
      description: `EXPENSE: ${exp.category} - ${exp.vendorName || exp.accountName}`,
      amount: -exp.totalAmount,
      currency: exp.currency,
      referenceNumber: exp.referenceNumber || `EXP-${Date.now().toString().slice(-5)}`,
      matchStatus: 'matched',
      matchedType: 'expense',
      matchedEntityId: newExp.id,
      matchedEntityDescription: `${exp.expenseNumber} (${exp.category})`
    };
    setBankTransactions(prev => [newTxn, ...prev]);

    const je: JournalEntry = {
      id: `je-exp-${Date.now()}`,
      entryNumber: `JE-EXP-${Date.now().toString().slice(-4)}`,
      date: exp.date,
      reference: exp.expenseNumber,
      narration: `Direct expense for ${exp.category} - ${exp.notes}`,
      lines: [
        { accountCode: exp.accountCode, accountName: exp.accountName, debit: exp.amount * exp.exchangeRate, credit: 0, description: 'Expense debit' },
        ...(exp.taxAmount > 0 ? [{ accountCode: '1300', accountName: 'GST Input Tax Credit', debit: exp.taxAmount * exp.exchangeRate, credit: 0, description: 'GST ITC claim' }] : []),
        { accountCode: '1010', accountName: 'Bank Operating Account', debit: 0, credit: exp.totalAmount * exp.exchangeRate, description: 'Bank disbursement' }
      ],
      totalDebit: exp.totalAmount * exp.exchangeRate,
      totalCredit: exp.totalAmount * exp.exchangeRate
    };
    setJournalEntries(prev => [je, ...prev]);

    return newExp;
  };

  const deleteExpense = (id: string) => {
    setExpenses(prev => prev.filter(e => e.id !== id));
  };

  const updateExpense = (id: string, partial: Partial<Expense>) => {
    setExpenses(prev => prev.map(e => e.id === id ? { ...e, ...partial } : e));
  };

  const duplicateExpense = (id: string): Expense => {
    const exp = expenses.find(e => e.id === id);
    if (!exp) throw new Error('Expense not found');
    const newExp: Expense = {
      ...exp,
      id: `exp-${Date.now()}`,
      expenseNumber: `EXP-${Date.now().toString().slice(-4)}`,
      date: new Date().toISOString().split('T')[0],
    };
    setExpenses(prev => [newExp, ...prev]);
    return newExp;
  };

  // Debit Notes (Purchase Returns)
  const createDebitNote = (dn: Omit<DebitNote, 'id'>): DebitNote => {
    const newDn: DebitNote = { ...dn, id: `dn-${Date.now()}` };
    setDebitNotes(prev => [newDn, ...prev]);

    if (dn.billId) {
      setBills(prev => prev.map(bill => {
        if (bill.id === dn.billId) {
          const newBal = Math.max(0, bill.balanceDue - dn.netDebitAmount);
          return {
            ...bill,
            balanceDue: newBal,
            status: newBal <= 0.01 ? 'paid' : bill.status
          };
        }
        return bill;
      }));
    }

    const je: JournalEntry = {
      id: `je-dn-${Date.now()}`,
      entryNumber: `JE-DN-${Date.now().toString().slice(-4)}`,
      date: dn.date,
      reference: dn.debitNoteNumber,
      narration: `Debit Note / Purchase Return issued to ${dn.vendorName} for ${dn.reason}`,
      lines: [
        { accountCode: '2000', accountName: 'Accounts Payable', debit: dn.netDebitAmount * dn.exchangeRate, credit: 0, description: `Reduction in liability to ${dn.vendorName}` },
        { accountCode: '5000', accountName: 'Direct Expenses (Purchase Return)', debit: 0, credit: dn.subtotal * dn.exchangeRate, description: 'Expense reversal' },
        ...(dn.taxAmount > 0 ? [{ accountCode: '1300', accountName: 'GST Input Tax Credit (ITC Reversal)', debit: 0, credit: dn.taxAmount * dn.exchangeRate, description: 'ITC credit reduction' }] : [])
      ],
      totalDebit: dn.grossAmount * dn.exchangeRate,
      totalCredit: dn.grossAmount * dn.exchangeRate
    };
    setJournalEntries(prev => [je, ...prev]);

    return newDn;
  };

  const updateDebitNote = (id: string, partial: Partial<DebitNote>) => {
    setDebitNotes(prev => prev.map(d => d.id === id ? { ...d, ...partial } : d));
  };

  const deleteDebitNote = (id: string) => {
    setDebitNotes(prev => prev.filter(d => d.id !== id));
  };

  const duplicateDebitNote = (id: string): DebitNote => {
    const dn = debitNotes.find(d => d.id === id);
    if (!dn) throw new Error('Debit Note not found');
    const newDn: DebitNote = {
      ...dn,
      id: `dn-${Date.now()}`,
      debitNoteNumber: `DN-${Date.now().toString().slice(-4)}`,
      date: new Date().toISOString().split('T')[0],
      status: 'open',
    };
    setDebitNotes(prev => [newDn, ...prev]);
    return newDn;
  };

  // Bills (Accounts Payable)
  const createBill = (bill: Omit<Bill, 'id' | 'netPayable' | 'balanceDue'>): Bill => {
    const id = `bill-${Date.now()}`;
    const netPayable = bill.grossAmount - (bill.tdsAmount || 0);
    const balanceDue = netPayable - (bill.paidAmount || 0);

    const newBill: Bill = {
      ...bill,
      id,
      netPayable,
      balanceDue
    };

    setBills(prev => [newBill, ...prev]);

    // Book General Ledger Journal Entry for Vendor Bill
    const je: JournalEntry = {
      id: `je-b-${Date.now()}`,
      entryNumber: `JE-BILL-${Date.now().toString().slice(-4)}`,
      date: bill.billDate,
      reference: bill.billNumber,
      narration: `Vendor bill recorded from ${bill.vendorName} with TDS Section ${bill.tdsSection || 'N/A'}`,
      lines: [
        { accountCode: '5000', accountName: `${bill.category} Expense`, debit: bill.subtotal * bill.exchangeRate, credit: 0, description: 'Bill expense' },
        ...(bill.taxAmount > 0 ? [{ accountCode: '1300', accountName: 'GST Input Tax Credit (ITC)', debit: bill.taxAmount * bill.exchangeRate, credit: 0, description: 'Input tax credit' }] : []),
        ...(bill.tdsAmount > 0 ? [{ accountCode: '2200', accountName: 'TDS Payable to Government', debit: 0, credit: bill.tdsAmount * bill.exchangeRate, description: `TDS deduction under Sec ${bill.tdsSection}` }] : []),
        { accountCode: '2000', accountName: 'Accounts Payable', debit: 0, credit: netPayable * bill.exchangeRate, description: `Net payable to ${bill.vendorName}` }
      ],
      totalDebit: (bill.subtotal + bill.taxAmount) * bill.exchangeRate,
      totalCredit: (bill.subtotal + bill.taxAmount) * bill.exchangeRate
    };
    setJournalEntries(prev => [je, ...prev]);

    return newBill;
  };

  const updateBill = (id: string, partial: Partial<Bill>) => {
    setBills(prev => prev.map(b => {
      if (b.id !== id) return b;
      const updated = { ...b, ...partial };
      if (partial.grossAmount !== undefined || partial.tdsAmount !== undefined || partial.paidAmount !== undefined) {
        updated.netPayable = updated.grossAmount - (updated.tdsAmount || 0);
        updated.balanceDue = updated.netPayable - (updated.paidAmount || 0);
        if (updated.balanceDue <= 0.01) {
          updated.status = 'paid';
        } else if (updated.paidAmount > 0) {
          updated.status = 'partially_paid';
        }
      }
      return updated;
    }));
  };

  const deleteBill = (id: string) => {
    setBills(prev => prev.filter(b => b.id !== id));
  };

  const duplicateBill = (id: string): Bill => {
    const bill = bills.find(b => b.id === id);
    if (!bill) throw new Error('Bill not found');
    const newBill: Bill = {
      ...bill,
      id: `bill-${Date.now()}`,
      billNumber: `BILL-${Date.now().toString().slice(-4)}`,
      billDate: new Date().toISOString().split('T')[0],
      dueDate: new Date(Date.now() + 30 * 86400000).toISOString().split('T')[0],
      status: 'draft',
      paidAmount: 0,
      balanceDue: bill.netPayable,
    };
    setBills(prev => [newBill, ...prev]);
    return newBill;
  };

  const recordBillPayment = (billId: string, amount: number, bankAccountId: string, refNo?: string) => {
    const bill = bills.find(b => b.id === billId);
    if (!bill) return;

    const newPaidAmount = bill.paidAmount + amount;
    const newBalanceDue = Math.max(0, bill.netPayable - newPaidAmount);
    const newStatus = newBalanceDue <= 0.01 ? 'paid' : 'partially_paid';

    setBills(prev => prev.map(b => b.id === billId ? {
      ...b,
      paidAmount: newPaidAmount,
      balanceDue: newBalanceDue,
      status: newStatus
    } : b));

    // Deduct from bank account
    setBankAccounts(prev => prev.map(acc => {
      if (acc.id === bankAccountId) {
        return { ...acc, balance: acc.balance - amount };
      }
      return acc;
    }));

    // Record Outflow Transaction
    const newTxn: BankTransaction = {
      id: `txn-${Date.now()}`,
      bankAccountId,
      date: new Date().toISOString().split('T')[0],
      description: `PAYMENT TO VENDOR - ${bill.billNumber} (${bill.vendorName})`,
      amount: -amount,
      currency: bill.currency,
      referenceNumber: refNo || `RTGS-${Date.now().toString().slice(-6)}`,
      matchStatus: 'matched',
      matchedType: 'bill',
      matchedEntityId: bill.id,
      matchedEntityDescription: `${bill.billNumber} (${bill.vendorName})`
    };
    setBankTransactions(prev => [newTxn, ...prev]);
  };

  // Recurring & Automated Reminders
  const createRecurringConfig = (cfg: Omit<RecurringInvoiceConfig, 'id'>) => {
    const newCfg: RecurringInvoiceConfig = {
      ...cfg,
      id: `rec-${Date.now()}`
    };
    setRecurringConfigs(prev => [newCfg, ...prev]);
  };

  const toggleRecurringConfig = (id: string) => {
    setRecurringConfigs(prev => prev.map(c => c.id === id ? { ...c, active: !c.active } : c));
  };

  const triggerRecurringRunNow = (id: string): Invoice => {
    const config = recurringConfigs.find(c => c.id === id);
    if (!config) throw new Error('Recurring profile not found');

    const customer = customers.find(c => c.id === config.customerId) || customers[0];
    const isInterState = !customer.placeOfSupply.includes('Maharashtra');
    const today = new Date().toISOString().split('T')[0];
    const dueDateObj = new Date();
    dueDateObj.setDate(dueDateObj.getDate() + customer.paymentTermsDays);
    const dueDate = dueDateObj.toISOString().split('T')[0];

    // Compute next schedule date based on frequency
    const nextDateObj = new Date();
    if (config.frequency === 'weekly') nextDateObj.setDate(nextDateObj.getDate() + 7);
    else if (config.frequency === 'monthly') nextDateObj.setMonth(nextDateObj.getMonth() + 1);
    else if (config.frequency === 'quarterly') nextDateObj.setMonth(nextDateObj.getMonth() + 3);
    else nextDateObj.setFullYear(nextDateObj.getFullYear() + 1);
    const nextRun = nextDateObj.toISOString().split('T')[0];

    const cur = currencies.find(c => c.code === config.currency) || { exchangeRateToBase: 1 };
    const taxRate = isInterState ? 0.18 : 0.18; // default 18% GST
    const taxable = config.amount;
    const cgst = isInterState ? 0 : taxable * 0.09;
    const sgst = isInterState ? 0 : taxable * 0.09;
    const igst = isInterState ? taxable * 0.18 : 0;
    const totalTax = cgst + sgst + igst;
    const totalAmount = taxable + totalTax;

    const newInv = createInvoice({
      invoiceNumber: `INV-AUTO-${Date.now().toString().slice(-4)}`,
      customerId: customer.id,
      customerName: customer.companyName,
      customerTaxId: customer.taxId,
      placeOfSupply: customer.placeOfSupply,
      isInterState,
      issueDate: today,
      dueDate,
      status: config.autoSendEmail ? 'sent' : 'draft',
      currency: config.currency,
      exchangeRate: cur.exchangeRateToBase,
      items: [
        {
          id: `item-${Date.now()}`,
          description: config.description,
          hsnSac: '998313',
          quantity: 1,
          unitRate: config.amount,
          discountPercent: 0,
          taxRateId: 'tax-gst-18',
          taxableAmount: taxable,
          cgstAmount: cgst,
          sgstAmount: sgst,
          igstAmount: igst,
          totalAmount
        }
      ],
      subtotal: taxable,
      discountTotal: 0,
      cgstTotal: cgst,
      sgstTotal: sgst,
      igstTotal: igst,
      totalTax,
      totalAmount,
      baseCurrencyTotal: totalAmount * cur.exchangeRateToBase,
      paidAmount: 0,
      tdsDeductedByCustomer: 0,
      notes: `Automated invoice generated by recurring schedule (${config.frequency}).`,
      terms: `Net ${customer.paymentTermsDays} days.`,
      recurringConfigId: config.id
    });

    // Update config last and next run
    setRecurringConfigs(prev => prev.map(c => c.id === id ? {
      ...c,
      lastRunDate: today,
      nextRunDate: nextRun
    } : c));

    return newInv;
  };

  const updateReminderRule = (id: string, partial: Partial<PaymentReminderRule>) => {
    setReminderRules(prev => prev.map(r => r.id === id ? { ...r, ...partial } : r));
  };

  const runAutomatedRemindersCheck = () => {
    const today = new Date();
    let sentCount = 0;
    const logs: string[] = [];

    invoices.forEach(inv => {
      if (inv.status === 'paid' || inv.status === 'void' || inv.balanceDue <= 0) return;

      const due = new Date(inv.dueDate);
      const diffDays = Math.round((today.getTime() - due.getTime()) / (1000 * 3600 * 24));

      reminderRules.forEach(rule => {
        if (!rule.enabled) return;
        // Check if rule matches diffDays (e.g. triggerDays = -3 means 3 days before due -> diffDays === -3)
        if (rule.triggerDays === diffDays) {
          sendPaymentReminder(inv.id, rule.channel, `[Automated Schedule: ${rule.title}] - ${inv.invoiceNumber}`);
          sentCount++;
          logs.push(`Sent ${rule.channel.toUpperCase()} reminder to ${inv.customerName} for ${inv.invoiceNumber} (${diffDays > 0 ? `${diffDays}d overdue` : `${Math.abs(diffDays)}d before due`})`);
        }
      });
    });

    return { count: sentCount, messages: logs };
  };

  // Banking Feeds & Open Banking Integration
  const syncBankFeeds = async () => {
    setIsSyncingBank(true);
    await new Promise(r => setTimeout(r, 1200));

    const now = new Date().toISOString();
    // Simulate incoming feed items
    const sampleIncoming: BankTransaction[] = [
      {
        id: `txn-feed-${Date.now()}-1`,
        bankAccountId: bankAccounts[0].id,
        date: new Date().toISOString().split('T')[0],
        description: 'UPI/CREDIT/KAVERI INFOTECH SOLUTIONS/RTGS-AUTO',
        amount: 165200,
        currency: 'INR',
        referenceNumber: `UPI${Date.now().toString().slice(-6)}`,
        matchStatus: 'unmatched',
        suggestedMatchId: 'inv-1003',
        suggestedMatchReason: 'Exact amount match ₹165,200 with Kaveri Infotech (INV-2026-0044)'
      }
    ];

    setBankTransactions(prev => [sampleIncoming[0], ...prev]);
    setBankAccounts(prev => prev.map(b => ({
      ...b,
      lastSyncedAt: now,
      status: 'connected'
    })));
    setIsSyncingBank(false);
  };

  const reconcileTransaction = (
    txnId: string,
    matchType: 'invoice' | 'bill' | 'manual',
    entityId?: string,
    description?: string
  ) => {
    const txn = bankTransactions.find(t => t.id === txnId);
    if (!txn) return;

    if (matchType === 'invoice' && entityId) {
      recordInvoicePayment(entityId, Math.abs(txn.amount), 0, txn.bankAccountId, `Matched from bank transaction ${txn.referenceNumber}`);
    } else if (matchType === 'bill' && entityId) {
      recordBillPayment(entityId, Math.abs(txn.amount), txn.bankAccountId, txn.referenceNumber);
    }

    setBankTransactions(prev => prev.map(t => t.id === txnId ? {
      ...t,
      matchStatus: 'matched',
      matchedType: matchType,
      matchedEntityId: entityId,
      matchedEntityDescription: description || `Manually reconciled as ${matchType}`
    } : t));
  };

  const excludeTransaction = (txnId: string) => {
    setBankTransactions(prev => prev.map(t => t.id === txnId ? { ...t, matchStatus: 'excluded' } : t));
  };

  const importBankStatement = (bankAccountId: string, newTxns: Partial<BankTransaction>[]) => {
    const formatted: BankTransaction[] = newTxns.map((t, idx) => ({
      id: `txn-imp-${Date.now()}-${idx}`,
      bankAccountId,
      date: t.date || new Date().toISOString().split('T')[0],
      description: t.description || 'Imported Statement Line',
      amount: t.amount || 0,
      currency: t.currency || 'INR',
      referenceNumber: t.referenceNumber || `IMP-${Date.now().toString().slice(-4)}-${idx}`,
      matchStatus: 'unmatched'
    }));

    setBankTransactions(prev => [...formatted, ...prev]);
  };

  const connectNewBankAccount = (acc: Omit<BankAccount, 'id' | 'lastSyncedAt'>) => {
    const newAcc: BankAccount = {
      ...acc,
      id: `bank-${Date.now()}`,
      lastSyncedAt: new Date().toISOString()
    };
    setBankAccounts(prev => [...prev, newAcc]);
  };

  const updateBankAccount = (id: string, partial: Partial<BankAccount>) => {
    setBankAccounts(prev => prev.map(b => b.id === id ? { ...b, ...partial } : b));
  };

  const deleteBankAccount = (id: string) => {
    setBankAccounts(prev => prev.filter(b => b.id !== id));
  };

  const duplicateBankAccount = (id: string): BankAccount => {
    const acc = bankAccounts.find(b => b.id === id);
    if (!acc) throw new Error('Bank account not found');
    const newAcc: BankAccount = {
      ...acc,
      id: `bank-${Date.now()}`,
      name: `${acc.name} (Copy)`,
      accountNumber: `${acc.accountNumber}-CPY`,
      balance: 0,
    };
    setBankAccounts(prev => [...prev, newAcc]);
    return newAcc;
  };

  // Journal Entries
  const addJournalEntry = (entry: Omit<JournalEntry, 'id'>) => {
    const newJe: JournalEntry = {
      ...entry,
      id: `je-${Date.now()}`
    };
    setJournalEntries(prev => [newJe, ...prev]);
  };

  // Dashboard Aggregates & Aging Calculations
  const todayDate = new Date('2026-10-31'); // Anchor to current context date

  // Accounts Payable Aging
  const apAging: AgingSummary = useMemo(() => {
    const summary: AgingSummary = { current: 0, days1_30: 0, days31_60: 0, days61_90: 0, days90Plus: 0, total: 0 };
    bills.forEach(bill => {
      if (bill.status === 'paid' || bill.balanceDue <= 0) return;
      const amountInBase = bill.balanceDue * bill.exchangeRate;
      summary.total += amountInBase;

      const dueDate = new Date(bill.dueDate);
      const diffTime = todayDate.getTime() - dueDate.getTime();
      const overdueDays = Math.floor(diffTime / (1000 * 3600 * 24));

      if (overdueDays <= 0) {
        summary.current += amountInBase;
      } else if (overdueDays <= 30) {
        summary.days1_30 += amountInBase;
      } else if (overdueDays <= 60) {
        summary.days31_60 += amountInBase;
      } else if (overdueDays <= 90) {
        summary.days61_90 += amountInBase;
      } else {
        summary.days90Plus += amountInBase;
      }
    });
    return summary;
  }, [bills, todayDate]);

  // Accounts Receivable Aging
  const arAging: AgingSummary = useMemo(() => {
    const summary: AgingSummary = { current: 0, days1_30: 0, days31_60: 0, days61_90: 0, days90Plus: 0, total: 0 };
    invoices.forEach(inv => {
      if (inv.status === 'paid' || inv.status === 'void' || inv.balanceDue <= 0) return;
      const amountInBase = inv.balanceDue * inv.exchangeRate;
      summary.total += amountInBase;

      const dueDate = new Date(inv.dueDate);
      const diffTime = todayDate.getTime() - dueDate.getTime();
      const overdueDays = Math.floor(diffTime / (1000 * 3600 * 24));

      if (overdueDays <= 0) {
        summary.current += amountInBase;
      } else if (overdueDays <= 30) {
        summary.days1_30 += amountInBase;
      } else if (overdueDays <= 60) {
        summary.days31_60 += amountInBase;
      } else if (overdueDays <= 90) {
        summary.days61_90 += amountInBase;
      } else {
        summary.days90Plus += amountInBase;
      }
    });
    return summary;
  }, [invoices, todayDate]);

  // Total Cash in Base Currency
  const totalCashBalanceBase = useMemo(() => {
    return bankAccounts.reduce((sum, acc) => {
      const cur = currencies.find(c => c.code === acc.currency) || { exchangeRateToBase: 1 };
      return sum + (acc.balance * cur.exchangeRateToBase);
    }, 0);
  }, [bankAccounts, currencies]);

  const totalReceivablesBase = arAging.total;
  const totalPayablesBase = apAging.total;

  const totalTdsPayableBase = useMemo(() => {
    return bills.reduce((sum, b) => sum + (b.tdsAmount * b.exchangeRate), 0);
  }, [bills]);

  const totalTdsReceivableBase = useMemo(() => {
    return invoices.reduce((sum, inv) => sum + (inv.tdsDeductedByCustomer * inv.exchangeRate), 0);
  }, [invoices]);

  const netIncomeBase = useMemo(() => {
    const revenue = invoices
      .filter(i => i.status !== 'void')
      .reduce((sum, i) => sum + (i.subtotal * i.exchangeRate), 0);
    const expenses = bills.reduce((sum, b) => sum + (b.subtotal * b.exchangeRate), 0);
    return revenue - expenses;
  }, [invoices, bills]);

  // Real-time Cash Flow Forecast (30/60/90 days in 15-day buckets)
  const cashFlowForecast: CashFlowProjectionItem[] = useMemo(() => {
    let running = totalCashBalanceBase;
    const periods = [
      { label: 'Nov 01 - Nov 15', startDays: 0, endDays: 15 },
      { label: 'Nov 16 - Nov 30', startDays: 16, endDays: 30 },
      { label: 'Dec 01 - Dec 15', startDays: 31, endDays: 45 },
      { label: 'Dec 16 - Dec 31', startDays: 46, endDays: 60 },
      { label: 'Jan 01 - Jan 15', startDays: 61, endDays: 75 },
      { label: 'Jan 16 - Jan 31', startDays: 76, endDays: 90 },
    ];

    return periods.map(p => {
      // Inflows from invoices due in this bucket
      let cashIn = 0;
      invoices.forEach(inv => {
        if (inv.status === 'paid' || inv.status === 'void' || inv.balanceDue <= 0) return;
        const due = new Date(inv.dueDate);
        const dayDiff = Math.floor((due.getTime() - todayDate.getTime()) / (1000 * 3600 * 24));
        if (dayDiff >= p.startDays && dayDiff <= p.endDays) {
          cashIn += inv.balanceDue * inv.exchangeRate;
        }
      });

      // Outflows from bills due in this bucket
      let cashOut = 0;
      bills.forEach(bill => {
        if (bill.status === 'paid' || bill.balanceDue <= 0) return;
        const due = new Date(bill.dueDate);
        const dayDiff = Math.floor((due.getTime() - todayDate.getTime()) / (1000 * 3600 * 24));
        if (dayDiff >= p.startDays && dayDiff <= p.endDays) {
          cashOut += bill.balanceDue * bill.exchangeRate;
        }
      });

      // Add baseline operational estimate if early buckets
      if (cashIn === 0 && p.startDays <= 30) cashIn = 120000;
      if (cashOut === 0 && p.startDays <= 30) cashOut = 85000;

      const net = cashIn - cashOut;
      running += net;

      return {
        period: p.label,
        cashIn,
        cashOut,
        net,
        runningBalance: running
      };
    });
  }, [invoices, bills, totalCashBalanceBase, todayDate]);

  const resetToDemoData = () => {
    localStorage.removeItem(STORAGE_KEY);
    setSettings(INITIAL_SETTINGS);
    setCurrencies(INITIAL_CURRENCIES);
    setSelectedDisplayCurrency('INR');
    setCustomers(INITIAL_CUSTOMERS);
    setVendors(INITIAL_VENDORS);
    setInvoices(INITIAL_INVOICES);
    setEstimates(INITIAL_ESTIMATES);
    setSalesOrders(INITIAL_SALES_ORDERS);
    setCreditNotes(INITIAL_CREDIT_NOTES);
    setPurchaseOrders(INITIAL_PURCHASE_ORDERS);
    setBills(INITIAL_BILLS);
    setExpenses(INITIAL_EXPENSES);
    setDebitNotes(INITIAL_DEBIT_NOTES);
    setBankAccounts(INITIAL_BANK_ACCOUNTS);
    setBankTransactions(INITIAL_BANK_TRANSACTIONS);
    setRecurringConfigs(INITIAL_RECURRING_CONFIGS);
    setReminderRules(INITIAL_REMINDER_RULES);
    setChartOfAccounts(INITIAL_CHART_OF_ACCOUNTS);
    setJournalEntries(INITIAL_JOURNAL_ENTRIES);
  };

  const resetToFreshBlank = () => {
    localStorage.removeItem(STORAGE_KEY);
    setCustomers([]);
    setVendors([]);
    setInvoices([]);
    setEstimates([]);
    setSalesOrders([]);
    setCreditNotes([]);
    setPurchaseOrders([]);
    setBills([]);
    setExpenses([]);
    setDebitNotes([]);
    setBankAccounts([]);
    setBankTransactions([]);
    setRecurringConfigs([]);
    setJournalEntries([]);
  };

  const clearAllTransactions = () => {
    setInvoices([]);
    setEstimates([]);
    setSalesOrders([]);
    setCreditNotes([]);
    setPurchaseOrders([]);
    setBills([]);
    setExpenses([]);
    setDebitNotes([]);
    setBankTransactions([]);
    setJournalEntries([]);
  };

  const loadDemoSampleData = () => {
    setCustomers(SAMPLE_CUSTOMERS);
    setVendors(SAMPLE_VENDORS);
    setBankAccounts(SAMPLE_BANK_ACCOUNTS);
    setInvoices(SAMPLE_INVOICES);
    setBills(SAMPLE_BILLS);
    setExpenses(SAMPLE_EXPENSES);
  };

  const getBackupPayload = (): BackupPayload => {
    return {
      version: '2.5',
      exportDate: new Date().toISOString(),
      settings,
      customers,
      vendors,
      invoices,
      bills,
      expenses,
      bankAccounts,
      creditNotes,
      debitNotes,
      estimates,
      salesOrders,
      purchaseOrders,
    };
  };

  const restoreFromJson = (jsonData: string): boolean => {
    try {
      const data = JSON.parse(jsonData);
      if (data.settings) setSettings(data.settings);
      if (Array.isArray(data.customers)) setCustomers(data.customers);
      if (Array.isArray(data.vendors)) setVendors(data.vendors);
      if (Array.isArray(data.invoices)) setInvoices(data.invoices);
      if (Array.isArray(data.bills)) setBills(data.bills);
      if (Array.isArray(data.expenses)) setExpenses(data.expenses);
      if (Array.isArray(data.bankAccounts)) setBankAccounts(data.bankAccounts);
      if (Array.isArray(data.creditNotes)) setCreditNotes(data.creditNotes);
      if (Array.isArray(data.debitNotes)) setDebitNotes(data.debitNotes);
      if (Array.isArray(data.estimates)) setEstimates(data.estimates);
      if (Array.isArray(data.salesOrders)) setSalesOrders(data.salesOrders);
      if (Array.isArray(data.purchaseOrders)) setPurchaseOrders(data.purchaseOrders);
      return true;
    } catch (e) {
      console.error('Failed to parse backup JSON:', e);
      return false;
    }
  };

  return (
    <AccountingContext.Provider
      value={{
        settings,
        updateSettings,
        setJurisdiction,
        currencies,
        selectedDisplayCurrency,
        setDisplayCurrency: setSelectedDisplayCurrency,
        convertAmount,
        formatMoney,
        updateExchangeRate,
        syncLiveFxRates,
        taxRates,
        tdsRates,
        customers,
        vendors,
        addCustomer,
        updateCustomer,
        deleteCustomer,
        duplicateCustomer,
        addVendor,
        updateVendor,
        deleteVendor,
        duplicateVendor,
        estimates,
        createEstimate,
        updateEstimate,
        deleteEstimate,
        duplicateEstimate,
        convertEstimateToSalesOrder,
        convertEstimateToInvoice,
        salesOrders,
        createSalesOrder,
        updateSalesOrder,
        deleteSalesOrder,
        duplicateSalesOrder,
        convertSalesOrderToInvoice,
        creditNotes,
        createCreditNote,
        updateCreditNote,
        deleteCreditNote,
        duplicateCreditNote,
        invoices,
        createInvoice,
        updateInvoice,
        deleteInvoice,
        duplicateInvoice,
        recordInvoicePayment,
        sendPaymentReminder,
        voidInvoice,
        purchaseOrders,
        createPurchaseOrder,
        updatePurchaseOrder,
        deletePurchaseOrder,
        duplicatePurchaseOrder,
        convertPurchaseOrderToBill,
        expenses,
        createExpense,
        updateExpense,
        deleteExpense,
        duplicateExpense,
        debitNotes,
        createDebitNote,
        updateDebitNote,
        deleteDebitNote,
        duplicateDebitNote,
        bills,
        createBill,
        updateBill,
        deleteBill,
        duplicateBill,
        recordBillPayment,
        recurringConfigs,
        createRecurringConfig,
        toggleRecurringConfig,
        triggerRecurringRunNow,
        reminderRules,
        updateReminderRule,
        runAutomatedRemindersCheck,
        bankAccounts,
        bankTransactions,
        isSyncingBank,
        syncBankFeeds,
        reconcileTransaction,
        excludeTransaction,
        importBankStatement,
        connectNewBankAccount,
        updateBankAccount,
        deleteBankAccount,
        duplicateBankAccount,
        chartOfAccounts,
        journalEntries,
        addJournalEntry,
        cashFlowForecast,
        apAging,
        arAging,
        totalCashBalanceBase,
        totalReceivablesBase,
        totalPayablesBase,
        totalTdsPayableBase,
        totalTdsReceivableBase,
        netIncomeBase,
        resetToDemoData,
        resetToFreshBlank,
        clearAllTransactions,
        loadDemoSampleData,
        restoreFromJson,
        getBackupPayload,
      }}
    >
      {children}
    </AccountingContext.Provider>
  );
};

export const useAccounting = () => {
  const context = useContext(AccountingContext);
  if (!context) {
    throw new Error('useAccounting must be used within an AccountingProvider');
  }
  return context;
};
