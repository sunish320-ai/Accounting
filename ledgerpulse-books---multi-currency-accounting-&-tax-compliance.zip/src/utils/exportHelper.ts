import * as XLSX from 'xlsx';
import {
  OrganizationSettings,
  Customer,
  Vendor,
  Invoice,
  Bill,
  Expense,
  BankAccount,
  CreditNote,
  DebitNote,
  Estimate,
  SalesOrder,
  PurchaseOrder
} from '../types';

export interface BackupPayload {
  version: string;
  exportDate: string;
  settings: OrganizationSettings;
  customers: Customer[];
  vendors: Vendor[];
  invoices: Invoice[];
  bills: Bill[];
  expenses: Expense[];
  bankAccounts: BankAccount[];
  creditNotes: CreditNote[];
  debitNotes: DebitNote[];
  estimates: Estimate[];
  salesOrders: SalesOrder[];
  purchaseOrders: PurchaseOrder[];
}

// 1. Export as Multi-Sheet XLSX
export function exportToXLSX(data: BackupPayload, customFilename?: string) {
  const wb = XLSX.utils.book_new();

  // Sheet 1: Invoices
  const invoicesData = data.invoices.map(inv => ({
    'Invoice Number': inv.invoiceNumber,
    'Issue Date': inv.issueDate,
    'Due Date': inv.dueDate,
    'Customer': inv.customerName,
    'Customer Tax ID (GSTIN)': inv.customerTaxId || '',
    'Place of Supply': inv.placeOfSupply || '',
    'Status': inv.status.toUpperCase(),
    'Currency': inv.currency,
    'Subtotal': inv.subtotal,
    'Total Tax': inv.totalTax,
    'Total Amount': inv.totalAmount,
    'Paid Amount': inv.paidAmount,
    'Balance Due': inv.balanceDue,
    'Notes': inv.notes || ''
  }));
  const wsInvoices = XLSX.utils.json_to_sheet(invoicesData.length > 0 ? invoicesData : [{ 'Status': 'No invoices recorded' }]);
  XLSX.utils.book_append_sheet(wb, wsInvoices, 'Sales Invoices');

  // Sheet 2: Bills (AP)
  const billsData = data.bills.map(b => ({
    'Bill Number': b.billNumber,
    'Bill Date': b.billDate,
    'Due Date': b.dueDate,
    'Vendor': b.vendorName,
    'Vendor PAN': b.vendorPan || '',
    'Category': b.category,
    'Status': b.status.toUpperCase(),
    'Currency': b.currency,
    'Gross Amount': b.grossAmount,
    'TDS Section': b.tdsSection || 'None',
    'TDS Amount': b.tdsAmount,
    'Net Payable': b.netPayable,
    'Balance Due': b.balanceDue
  }));
  const wsBills = XLSX.utils.json_to_sheet(billsData.length > 0 ? billsData : [{ 'Status': 'No vendor bills recorded' }]);
  XLSX.utils.book_append_sheet(wb, wsBills, 'Vendor Bills');

  // Sheet 3: Expenses
  const expensesData = data.expenses.map(exp => ({
    'Expense Number': exp.expenseNumber,
    'Date': exp.date,
    'Category': exp.category,
    'Payee / Vendor': exp.vendorName || '',
    'Account': `${exp.accountCode} - ${exp.accountName}`,
    'Payment Mode': exp.paymentMode,
    'Taxable Amount': exp.amount,
    'GST Tax': exp.taxAmount,
    'Total Amount': exp.totalAmount,
    'Currency': exp.currency
  }));
  const wsExpenses = XLSX.utils.json_to_sheet(expensesData.length > 0 ? expensesData : [{ 'Status': 'No direct expenses recorded' }]);
  XLSX.utils.book_append_sheet(wb, wsExpenses, 'Direct Expenses');

  // Sheet 4: Customers
  const customersData = data.customers.map(c => ({
    'Company Name': c.companyName,
    'Contact Person': c.name,
    'Email': c.email,
    'Phone': c.phone,
    'GSTIN / Tax ID': c.taxId || '',
    'PAN': c.pan || '',
    'Place of Supply': c.placeOfSupply,
    'Pincode': c.pincode || '',
    'Billing Address': c.billingAddress,
    'Currency': c.currency,
    'Payment Terms (Days)': c.paymentTermsDays
  }));
  const wsCustomers = XLSX.utils.json_to_sheet(customersData.length > 0 ? customersData : [{ 'Status': 'No customers registered' }]);
  XLSX.utils.book_append_sheet(wb, wsCustomers, 'Customers');

  // Sheet 5: Vendors
  const vendorsData = data.vendors.map(v => ({
    'Company Name': v.companyName,
    'Contact Person': v.name,
    'Email': v.email,
    'Phone': v.phone,
    'GSTIN / Tax ID': v.taxId || '',
    'PAN': v.pan,
    'Place of Supply': v.placeOfSupply || '',
    'Pincode': v.pincode || '',
    'Category': v.category,
    'Default TDS Section': v.defaultTdsSection || '',
    'Bank Name': v.bankAccount?.bankName || '',
    'Bank Account': v.bankAccount?.accountNumber || '',
    'IFSC': v.bankAccount?.ifscOrRouting || ''
  }));
  const wsVendors = XLSX.utils.json_to_sheet(vendorsData.length > 0 ? vendorsData : [{ 'Status': 'No vendors registered' }]);
  XLSX.utils.book_append_sheet(wb, wsVendors, 'Vendors');

  // Sheet 6: Bank Accounts
  const banksData = data.bankAccounts.map(b => ({
    'Bank Name': b.bankName,
    'Account Name': b.name,
    'Account Number': b.accountNumber,
    'Type': b.accountType,
    'Currency': b.currency,
    'Balance': b.balance,
    'Status': b.status
  }));
  const wsBanks = XLSX.utils.json_to_sheet(banksData.length > 0 ? banksData : [{ 'Status': 'No bank accounts linked' }]);
  XLSX.utils.book_append_sheet(wb, wsBanks, 'Bank Accounts');

  // Sheet 7: Organization & Summary
  const orgData = [
    { 'Field': 'Business / Brand Name', 'Value': data.settings.businessName },
    { 'Field': 'Legal Entity Name', 'Value': data.settings.legalEntityName },
    { 'Field': 'GSTIN', 'Value': data.settings.gstin || 'None' },
    { 'Field': 'PAN', 'Value': data.settings.pan || 'None' },
    { 'Field': 'Base Currency', 'Value': data.settings.baseCurrency },
    { 'Field': 'Registered State', 'Value': data.settings.registeredState },
    { 'Field': 'Registered Address', 'Value': data.settings.address },
    { 'Field': 'Email', 'Value': data.settings.email },
    { 'Field': 'Phone', 'Value': data.settings.phone },
    { 'Field': 'Backup Created', 'Value': data.exportDate }
  ];
  const wsOrg = XLSX.utils.json_to_sheet(orgData);
  XLSX.utils.book_append_sheet(wb, wsOrg, 'Organization Profile');

  const filename = customFilename || `LedgerPulse_Backup_${new Date().toISOString().split('T')[0]}.xlsx`;
  XLSX.writeFile(wb, filename);
}

// 2. Export as CSV (Combined Master CSV or Section CSV)
export function exportToCSV(data: BackupPayload, section: 'all' | 'invoices' | 'bills' | 'customers' | 'vendors' = 'all') {
  let csvContent = '';

  if (section === 'invoices' || section === 'all') {
    csvContent += '# === SALES INVOICES ===\n';
    csvContent += 'Invoice Number,Issue Date,Due Date,Customer Name,Tax ID,Place of Supply,Status,Currency,Subtotal,Total Tax,Total Amount,Paid Amount,Balance Due\n';
    data.invoices.forEach(inv => {
      csvContent += `"${inv.invoiceNumber}","${inv.issueDate}","${inv.dueDate}","${inv.customerName}","${inv.customerTaxId || ''}","${inv.placeOfSupply || ''}","${inv.status}","${inv.currency}",${inv.subtotal},${inv.totalTax},${inv.totalAmount},${inv.paidAmount},${inv.balanceDue}\n`;
    });
    csvContent += '\n';
  }

  if (section === 'bills' || section === 'all') {
    csvContent += '# === VENDOR BILLS & ACCOUNTS PAYABLE ===\n';
    csvContent += 'Bill Number,Bill Date,Due Date,Vendor Name,PAN,Category,Status,Currency,Gross Amount,TDS Amount,Net Payable,Balance Due\n';
    data.bills.forEach(b => {
      csvContent += `"${b.billNumber}","${b.billDate}","${b.dueDate}","${b.vendorName}","${b.vendorPan || ''}","${b.category}","${b.status}","${b.currency}",${b.grossAmount},${b.tdsAmount},${b.netPayable},${b.balanceDue}\n`;
    });
    csvContent += '\n';
  }

  if (section === 'customers' || section === 'all') {
    csvContent += '# === CUSTOMERS DIRECTORY ===\n';
    csvContent += 'Company Name,Contact Name,Email,Phone,GSTIN,PAN,Place of Supply,Pincode,Currency,Terms Days\n';
    data.customers.forEach(c => {
      csvContent += `"${c.companyName}","${c.name}","${c.email}","${c.phone}","${c.taxId || ''}","${c.pan || ''}","${c.placeOfSupply}","${c.pincode || ''}","${c.currency}",${c.paymentTermsDays}\n`;
    });
    csvContent += '\n';
  }

  if (section === 'vendors' || section === 'all') {
    csvContent += '# === VENDORS DIRECTORY ===\n';
    csvContent += 'Company Name,Contact Name,Email,Phone,GSTIN,PAN,Place of Supply,Pincode,Category,TDS Section,Bank Name\n';
    data.vendors.forEach(v => {
      csvContent += `"${v.companyName}","${v.name}","${v.email}","${v.phone}","${v.taxId || ''}","${v.pan}","${v.placeOfSupply || ''}","${v.pincode || ''}","${v.category}","${v.defaultTdsSection || ''}","${v.bankAccount?.bankName || ''}"\n`;
    });
    csvContent += '\n';
  }

  downloadFile(csvContent, `LedgerPulse_${section}_${new Date().toISOString().split('T')[0]}.csv`, 'text/csv;charset=utf-8;');
}

// 3. Export as Standalone Printable HTML Ledger & Audit Report
export function exportToHTML(data: BackupPayload) {
  const totalInvoiced = data.invoices.reduce((s, i) => s + (i.totalAmount * i.exchangeRate), 0);
  const totalReceivable = data.invoices.reduce((s, i) => s + (i.balanceDue * i.exchangeRate), 0);
  const totalPayable = data.bills.reduce((s, b) => s + (b.balanceDue * b.exchangeRate), 0);
  const totalCash = data.bankAccounts.reduce((s, b) => s + b.balance, 0);

  const html = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Financial Audit & Ledger Report - ${escapeHtml(data.settings.businessName)}</title>
  <style>
    body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; margin: 40px; color: #1e293b; background: #fff; }
    h1, h2, h3 { margin: 0 0 8px 0; color: #0f172a; }
    .header-banner { border-bottom: 2px solid #0284c7; padding-bottom: 20px; margin-bottom: 30px; display: flex; justify-content: space-between; align-items: flex-start; }
    .company-name { font-size: 24px; font-bold; color: #0f172a; }
    .meta-line { font-size: 13px; color: #64748b; margin-top: 4px; }
    .cards-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 16px; margin-bottom: 30px; }
    .card { background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 14px; }
    .card-title { font-size: 11px; text-transform: uppercase; font-weight: 600; color: #64748b; margin-bottom: 6px; }
    .card-val { font-size: 20px; font-weight: 700; color: #0f172a; font-family: monospace; }
    table { width: 100%; border-collapse: collapse; margin-bottom: 30px; font-size: 12px; }
    th { background: #f1f5f9; padding: 10px 12px; text-align: left; font-weight: 600; color: #475569; border-bottom: 1px solid #cbd5e1; font-size: 11px; text-transform: uppercase; }
    td { padding: 10px 12px; border-bottom: 1px solid #e2e8f0; color: #334155; }
    .text-right { text-align: right; }
    .font-mono { font-family: monospace; }
    .badge { display: inline-block; padding: 2px 8px; border-radius: 4px; font-size: 10px; font-weight: 600; text-transform: uppercase; }
    .badge-paid { background: #dcfce7; color: #15803d; }
    .badge-open { background: #dbeafe; color: #1d4ed8; }
    .badge-overdue { background: #fee2e2; color: #b91c1c; }
    .footer { border-top: 1px solid #e2e8f0; padding-top: 15px; margin-top: 40px; font-size: 11px; color: #94a3b8; display: flex; justify-content: space-between; }
    @media print { body { margin: 15px; } .no-print { display: none; } }
  </style>
</head>
<body>
  <div class="header-banner">
    <div>
      <div class="company-name">${escapeHtml(data.settings.businessName)}</div>
      <div class="meta-line">${escapeHtml(data.settings.legalEntityName)} · ${escapeHtml(data.settings.address)}</div>
      <div class="meta-line">GSTIN: <strong>${escapeHtml(data.settings.gstin || 'None')}</strong> · PAN: <strong>${escapeHtml(data.settings.pan || 'None')}</strong></div>
    </div>
    <div style="text-align: right;">
      <h2 style="font-size: 18px; color: #0284c7;">Financial Audit & Ledger Export</h2>
      <div class="meta-line">Exported Date: ${data.exportDate}</div>
      <div class="meta-line">Base Currency: <strong>${data.settings.baseCurrency}</strong></div>
    </div>
  </div>

  <div class="cards-grid">
    <div class="card">
      <div class="card-title">Total Sales Invoiced</div>
      <div class="card-val">${data.settings.baseCurrency} ${totalInvoiced.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</div>
    </div>
    <div class="card">
      <div class="card-title">Accounts Receivable (AR)</div>
      <div class="card-val" style="color: #0284c7;">${data.settings.baseCurrency} ${totalReceivable.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</div>
    </div>
    <div class="card">
      <div class="card-title">Accounts Payable (AP)</div>
      <div class="card-val" style="color: #e11d48;">${data.settings.baseCurrency} ${totalPayable.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</div>
    </div>
    <div class="card">
      <div class="card-title">Live Bank Balance</div>
      <div class="card-val" style="color: #16a34a;">${data.settings.baseCurrency} ${totalCash.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</div>
    </div>
  </div>

  <h3>Sales Invoices Register</h3>
  <table>
    <thead>
      <tr>
        <th>Date</th>
        <th>Invoice #</th>
        <th>Customer</th>
        <th>Place of Supply</th>
        <th>Status</th>
        <th class="text-right">Total</th>
        <th class="text-right">Balance Due</th>
      </tr>
    </thead>
    <tbody>
      ${data.invoices.length === 0 ? '<tr><td colspan="7" style="text-align:center; color:#94a3b8;">No invoices on record</td></tr>' : data.invoices.map(inv => `
        <tr>
          <td>${inv.issueDate}</td>
          <td class="font-mono"><strong>${escapeHtml(inv.invoiceNumber)}</strong></td>
          <td>${escapeHtml(inv.customerName)}</td>
          <td>${escapeHtml(inv.placeOfSupply || '—')}</td>
          <td><span class="badge ${inv.status === 'paid' ? 'badge-paid' : inv.status === 'overdue' ? 'badge-overdue' : 'badge-open'}">${inv.status}</span></td>
          <td class="text-right font-mono">${inv.currency} ${inv.totalAmount.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</td>
          <td class="text-right font-mono font-bold">${inv.currency} ${inv.balanceDue.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</td>
        </tr>
      `).join('')}
    </tbody>
  </table>

  <h3>Vendor Bills & Liabilities (Accounts Payable)</h3>
  <table>
    <thead>
      <tr>
        <th>Date</th>
        <th>Bill #</th>
        <th>Vendor Name</th>
        <th>Category</th>
        <th>Status</th>
        <th class="text-right">Gross</th>
        <th class="text-right">TDS</th>
        <th class="text-right">Net Due</th>
      </tr>
    </thead>
    <tbody>
      ${data.bills.length === 0 ? '<tr><td colspan="8" style="text-align:center; color:#94a3b8;">No vendor bills on record</td></tr>' : data.bills.map(b => `
        <tr>
          <td>${b.billDate}</td>
          <td class="font-mono"><strong>${escapeHtml(b.billNumber)}</strong></td>
          <td>${escapeHtml(b.vendorName)}</td>
          <td>${escapeHtml(b.category)}</td>
          <td><span class="badge ${b.status === 'paid' ? 'badge-paid' : b.status === 'overdue' ? 'badge-overdue' : 'badge-open'}">${b.status}</span></td>
          <td class="text-right font-mono">${b.currency} ${b.grossAmount.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</td>
          <td class="text-right font-mono" style="color:#0284c7;">-${b.currency} ${b.tdsAmount.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</td>
          <td class="text-right font-mono font-bold">${b.currency} ${b.balanceDue.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</td>
        </tr>
      `).join('')}
    </tbody>
  </table>

  <h3>Linked Bank Accounts</h3>
  <table>
    <thead>
      <tr>
        <th>Bank / Financial Institution</th>
        <th>Account Title</th>
        <th>Account Identifier</th>
        <th>Currency</th>
        <th class="text-right">Current Ledger Balance</th>
      </tr>
    </thead>
    <tbody>
      ${data.bankAccounts.length === 0 ? '<tr><td colspan="5" style="text-align:center; color:#94a3b8;">No bank accounts linked</td></tr>' : data.bankAccounts.map(b => `
        <tr>
          <td><strong>${escapeHtml(b.bankName)}</strong></td>
          <td>${escapeHtml(b.name)}</td>
          <td class="font-mono">${escapeHtml(b.accountNumber)}</td>
          <td>${b.currency}</td>
          <td class="text-right font-mono font-bold">${b.currency} ${b.balance.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</td>
        </tr>
      `).join('')}
    </tbody>
  </table>

  <div class="footer">
    <div>Generated by LedgerPulse Notes Accounting Engine · Encrypted Audit Record</div>
    <div>Report Timestamp: ${new Date().toISOString()}</div>
  </div>
</body>
</html>`;

  downloadFile(html, `LedgerPulse_Audit_Report_${new Date().toISOString().split('T')[0]}.html`, 'text/html;charset=utf-8;');
}

// 4. Export as JSON Backup
export function exportToJSON(data: BackupPayload) {
  const jsonContent = JSON.stringify(data, null, 2);
  downloadFile(jsonContent, `LedgerPulse_Full_Backup_${new Date().toISOString().split('T')[0]}.json`, 'application/json;charset=utf-8;');
}

// Helper: Trigger browser file download
function downloadFile(content: string, filename: string, mimeType: string) {
  const blob = new Blob([content], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

function escapeHtml(str: string): string {
  return String(str || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}
