/**
 * GST & Tax Compliance Utility for Indian Regulations
 * Includes standard 2-digit GST state codes, GSTIN automated verification,
 * and PAN synchronization rules.
 */

export interface GSTState {
  code: string;
  name: string;
  label: string; // e.g. "27-Maharashtra"
}

export const INDIAN_GST_STATES: GSTState[] = [
  { code: '01', name: 'Jammu and Kashmir', label: '01-Jammu and Kashmir' },
  { code: '02', name: 'Himachal Pradesh', label: '02-Himachal Pradesh' },
  { code: '03', name: 'Punjab', label: '03-Punjab' },
  { code: '04', name: 'Chandigarh', label: '04-Chandigarh' },
  { code: '05', name: 'Uttarakhand', label: '05-Uttarakhand' },
  { code: '06', name: 'Haryana', label: '06-Haryana' },
  { code: '07', name: 'Delhi', label: '07-Delhi' },
  { code: '08', name: 'Rajasthan', label: '08-Rajasthan' },
  { code: '09', name: 'Uttar Pradesh', label: '09-Uttar Pradesh' },
  { code: '10', name: 'Bihar', label: '10-Bihar' },
  { code: '11', name: 'Sikkim', label: '11-Sikkim' },
  { code: '12', name: 'Arunachal Pradesh', label: '12-Arunachal Pradesh' },
  { code: '13', name: 'Nagaland', label: '13-Nagaland' },
  { code: '14', name: 'Manipur', label: '14-Manipur' },
  { code: '15', name: 'Mizoram', label: '15-Mizoram' },
  { code: '16', name: 'Tripura', label: '16-Tripura' },
  { code: '17', name: 'Meghalaya', label: '17-Meghalaya' },
  { code: '18', name: 'Assam', label: '18-Assam' },
  { code: '19', name: 'West Bengal', label: '19-West Bengal' },
  { code: '20', name: 'Jharkhand', label: '20-Jharkhand' },
  { code: '21', name: 'Odisha', label: '21-Odisha' },
  { code: '22', name: 'Chhattisgarh', label: '22-Chhattisgarh' },
  { code: '23', name: 'Madhya Pradesh', label: '23-Madhya Pradesh' },
  { code: '24', name: 'Gujarat', label: '24-Gujarat' },
  { code: '26', name: 'Dadra & Nagar Haveli and Daman & Diu', label: '26-Dadra & Nagar Haveli and Daman & Diu' },
  { code: '27', name: 'Maharashtra', label: '27-Maharashtra' },
  { code: '28', name: 'Andhra Pradesh (Old)', label: '28-Andhra Pradesh (Old)' },
  { code: '29', name: 'Karnataka', label: '29-Karnataka' },
  { code: '30', name: 'Goa', label: '30-Goa' },
  { code: '31', name: 'Lakshadweep', label: '31-Lakshadweep' },
  { code: '32', name: 'Kerala', label: '32-Kerala' },
  { code: '33', name: 'Tamil Nadu', label: '33-Tamil Nadu' },
  { code: '34', name: 'Puducherry', label: '34-Puducherry' },
  { code: '35', name: 'Andaman & Nicobar Islands', label: '35-Andaman & Nicobar Islands' },
  { code: '36', name: 'Telangana', label: '36-Telangana' },
  { code: '37', name: 'Andhra Pradesh (New)', label: '37-Andhra Pradesh (New)' },
  { code: '38', name: 'Ladakh', label: '38-Ladakh' },
  { code: '97', name: 'Other Territory', label: '97-Other Territory' },
  { code: '99', name: 'International / Export (Outside India)', label: '99-International / Export' },
];

export interface GSTVerificationResult {
  isValid: boolean;
  isActive: boolean;
  stateCode: string;
  stateName: string;
  extractedPan: string;
  message: string;
  taxpayerType: string;
  complianceScore: number;
}

/**
 * Validates and simulates automated real-time GST portal verification.
 * Format: 2 digits (State code) + 10 chars (PAN) + 1 entity num + 'Z' + 1 checksum
 */
export function verifyGSTIN(gstin: string): GSTVerificationResult {
  const clean = gstin.trim().toUpperCase();

  if (!clean) {
    return {
      isValid: false,
      isActive: false,
      stateCode: '',
      stateName: '',
      extractedPan: '',
      message: 'GSTIN is empty',
      taxpayerType: '',
      complianceScore: 0,
    };
  }

  // Length check
  if (clean.length !== 15) {
    return {
      isValid: false,
      isActive: false,
      stateCode: clean.slice(0, 2),
      stateName: '',
      extractedPan: clean.slice(2, 12),
      message: `GSTIN must be exactly 15 characters (current: ${clean.length})`,
      taxpayerType: '',
      complianceScore: 0,
    };
  }

  // Regex format check
  const gstRegex = /^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$/;
  const matchesRegex = gstRegex.test(clean);

  const stateCode = clean.slice(0, 2);
  const matchedState = INDIAN_GST_STATES.find(s => s.code === stateCode);
  const extractedPan = clean.slice(2, 12);
  const fourteenthChar = clean[13];

  if (!matchedState) {
    return {
      isValid: false,
      isActive: false,
      stateCode,
      stateName: 'Unknown State',
      extractedPan,
      message: `Invalid State Code '${stateCode}'. Must be a recognized Indian State (01-38 or 97)`,
      taxpayerType: '',
      complianceScore: 0,
    };
  }

  if (fourteenthChar !== 'Z') {
    return {
      isValid: false,
      isActive: false,
      stateCode,
      stateName: matchedState.name,
      extractedPan,
      message: `14th character must be 'Z' as per GST specifications (found '${fourteenthChar}')`,
      taxpayerType: '',
      complianceScore: 0,
    };
  }

  if (!matchesRegex) {
    return {
      isValid: false,
      isActive: false,
      stateCode,
      stateName: matchedState.name,
      extractedPan,
      message: 'Invalid GSTIN structure. Must contain 2-digit state, 10-char PAN, entity code, Z, and check character.',
      taxpayerType: '',
      complianceScore: 0,
    };
  }

  // Active verified status
  return {
    isValid: true,
    isActive: true,
    stateCode,
    stateName: matchedState.name,
    extractedPan,
    message: `Active on GST Portal (${matchedState.name})`,
    taxpayerType: 'Regular Taxpayer',
    complianceScore: 100,
  };
}

/**
 * Validates PAN and checks alignment with GST number.
 * "the pan number should always start with the 4th letter of gst number" / match GST's PAN.
 */
export function validateAndDerivePAN(pan: string, gstin?: string): {
  isValid: boolean;
  message: string;
  derivedPan: string;
} {
  const cleanPan = pan.trim().toUpperCase();
  const cleanGst = (gstin || '').trim().toUpperCase();

  // If GST is provided and at least 12 chars, the official PAN is cleanGst.slice(2, 12)
  const officialPanFromGst = cleanGst.length >= 12 ? cleanGst.slice(2, 12) : '';

  // 4th letter of GST number (or 4th character)
  const gstChar4 = cleanGst.length >= 4 ? cleanGst[3] : '';

  const panRegex = /^[A-Z]{5}[0-9]{4}[A-Z]{1}$/;
  const isPanFormatValid = panRegex.test(cleanPan);

  if (!cleanPan) {
    return {
      isValid: false,
      message: 'PAN is required',
      derivedPan: officialPanFromGst,
    };
  }

  if (cleanGst && cleanGst.length >= 4) {
    // Check if PAN starts with 4th char of GST or matches official PAN
    const startsWithChar4 = cleanPan.startsWith(gstChar4);
    const matchesGstPan = officialPanFromGst ? cleanPan === officialPanFromGst : true;

    if (!isPanFormatValid && !matchesGstPan) {
      return {
        isValid: false,
        message: 'Invalid PAN format. Must be 10 characters (e.g. ABCDE1234F)',
        derivedPan: officialPanFromGst,
      };
    }

    if (!matchesGstPan && !startsWithChar4) {
      return {
        isValid: false,
        message: `PAN does not correspond to GSTIN. GSTIN has PAN '${officialPanFromGst || cleanGst.slice(2)}'`,
        derivedPan: officialPanFromGst,
      };
    }

    return {
      isValid: true,
      message: `Verified PAN (Active & synced with GST: ${cleanGst.slice(0, 12)}...)`,
      derivedPan: officialPanFromGst || cleanPan,
    };
  }

  if (!isPanFormatValid) {
    return {
      isValid: false,
      message: 'Invalid PAN format (Expected 5 letters, 4 digits, 1 letter)',
      derivedPan: cleanPan,
    };
  }

  return {
    isValid: true,
    message: 'Valid 10-character Indian PAN',
    derivedPan: cleanPan,
  };
}
