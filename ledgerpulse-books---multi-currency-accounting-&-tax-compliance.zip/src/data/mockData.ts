import {
  Currency,
  TaxRate,
  TDSRate,
  Customer,
  Vendor,
  Invoice,
  Bill,
  BankAccount,
  BankTransaction,
  RecurringInvoiceConfig,
  PaymentReminderRule,
  ChartOfAccount,
  JournalEntry,
  OrganizationSettings,
  Estimate,
  SalesOrder,
  CreditNote,
  PurchaseOrder,
  Expense,
  DebitNote
} from '../types';

export const INITIAL_CURRENCIES: Currency[] = [
  { code: 'INR', symbol: '₹', name: 'Indian Rupee', exchangeRateToBase: 1.0 },
  { code: 'USD', symbol: '$', name: 'US Dollar', exchangeRateToBase: 84.15 },
  { code: 'EUR', symbol: '€', name: 'Euro', exchangeRateToBase: 91.80 },
  { code: 'GBP', symbol: '£', name: 'British Pound', exchangeRateToBase: 107.50 },
  { code: 'AED', symbol: 'AED', name: 'UAE Dirham', exchangeRateToBase: 22.90 },
  { code: 'SGD', symbol: 'S$', name: 'Singapore Dollar', exchangeRateToBase: 63.20 },
  { code: 'CAD', symbol: 'CA$', name: 'Canadian Dollar', exchangeRateToBase: 61.40 },
  { code: 'AUD', symbol: 'A$', name: 'Australian Dollar', exchangeRateToBase: 55.30 },
  { code: 'JPY', symbol: '¥', name: 'Japanese Yen', exchangeRateToBase: 0.56 },
];

export const TAX_RATES: TaxRate[] = [
  { id: 'tax-gst-18', name: 'GST 18% (Standard IT/Services)', rate: 18, type: 'GST_18', description: '9% CGST + 9% SGST or 18% IGST' },
  { id: 'tax-gst-12', name: 'GST 12% (Goods & Select Services)', rate: 12, type: 'GST_12', description: '6% CGST + 6% SGST or 12% IGST' },
  { id: 'tax-gst-5', name: 'GST 5% (Essentials / Freight)', rate: 5, type: 'GST_5', description: '2.5% CGST + 2.5% SGST or 5% IGST' },
  { id: 'tax-gst-28', name: 'GST 28% (Luxury / Automobiles)', rate: 28, type: 'GST_28', description: '14% CGST + 14% SGST or 28% IGST' },
  { id: 'tax-gst-0', name: 'GST 0% (Zero-rated / SEZ Export)', rate: 0, type: 'GST_0', description: 'Zero rated export of services under LUT' },
  { id: 'tax-vat-20', name: 'UK VAT 20%', rate: 20, type: 'VAT_20', description: 'Standard UK Value Added Tax' },
  { id: 'tax-vat-5', name: 'UAE VAT 5%', rate: 5, type: 'VAT_5', description: 'Federal Tax Authority standard rate' },
  { id: 'tax-sales-8', name: 'US State Sales Tax 8.25%', rate: 8.25, type: 'SALES_TAX_8', description: 'Standard state and local sales tax' },
  { id: 'tax-exempt', name: 'Tax Exempt', rate: 0, type: 'EXEMPT', description: 'No tax applicable' },
];

export const TDS_RATES: TDSRate[] = [
  { section: '194J_TECH', code: '194J(a)', label: 'Sec 194J - Fees for Technical Services (FTS)', rate: 2, threshold: 30000, applicableFor: 'All' },
  { section: '194J_PROF', code: '194J(b)', label: 'Sec 194J - Professional / Legal / Consulting Fees', rate: 10, threshold: 30000, applicableFor: 'All' },
  { section: '194C_COMPANY', code: '194C(2)', label: 'Sec 194C - Contractor Payments (Corporate)', rate: 2, threshold: 100000, applicableFor: 'Company' },
  { section: '194C_INDIVIDUAL', code: '194C(1)', label: 'Sec 194C - Contractor Payments (Individual/HUF)', rate: 1, threshold: 100000, applicableFor: 'Individual' },
  { section: '194I_RENT', code: '194I', label: 'Sec 194I - Rent on Real Estate / Office Premises', rate: 10, threshold: 240000, applicableFor: 'All' },
  { section: '194H_COMMISSION', code: '194H', label: 'Sec 194H - Commission or Brokerage', rate: 5, threshold: 15000, applicableFor: 'All' },
  { section: '194Q_PURCHASE', code: '194Q', label: 'Sec 194Q - Purchase of Goods exceeding 50L', rate: 0.1, threshold: 5000000, applicableFor: 'Company' },
];

export const INITIAL_SETTINGS: OrganizationSettings = {
  businessName: 'My Business Enterprise',
  legalEntityName: 'My Business Enterprise LLP',
  gstin: '27AABCA1234F1Z8',
  pan: 'AABCA1234F',
  vatNumber: 'GB982345671',
  ein: '84-1239847',
  jurisdiction: 'INDIA',
  baseCurrency: 'INR',
  registeredState: '27-Maharashtra',
  registeredCountry: 'India',
  email: 'finance@mybusiness.com',
  phone: '+91 98200 12345',
  website: 'https://mybusiness.com',
  address: 'Commercial Hub, Business District',
  fiscalYearStartMonth: 4, // April (Indian FY: Apr - Mar)
  enableAutoTds: true,
  enableAutoBankSync: true,
  syncIntervalMinutes: 30,
};

// All transactional and master directories initialized completely empty per user request
export const INITIAL_CUSTOMERS: Customer[] = [];
export const INITIAL_VENDORS: Vendor[] = [];
export const INITIAL_ESTIMATES: Estimate[] = [];
export const INITIAL_SALES_ORDERS: SalesOrder[] = [];
export const INITIAL_INVOICES: Invoice[] = [];
export const INITIAL_CREDIT_NOTES: CreditNote[] = [];
export const INITIAL_PURCHASE_ORDERS: PurchaseOrder[] = [];
export const INITIAL_BILLS: Bill[] = [];
export const INITIAL_EXPENSES: Expense[] = [];
export const INITIAL_DEBIT_NOTES: DebitNote[] = [];
export const INITIAL_BANK_ACCOUNTS: BankAccount[] = [];
export const INITIAL_BANK_TRANSACTIONS: BankTransaction[] = [];
export const INITIAL_RECURRING_CONFIGS: RecurringInvoiceConfig[] = [];
export const INITIAL_JOURNAL_ENTRIES: JournalEntry[] = [];

export const INITIAL_REMINDER_RULES: PaymentReminderRule[] = [
  {
    id: 'rem-1',
    title: 'Upcoming Due Reminder (3 Days Before)',
    triggerDays: -3,
    timing: 'before',
    subject: 'Friendly Reminder: Invoice #{invoice_number} is due soon',
    bodyTemplate: 'Dear {customer_name},\n\nThis is a friendly reminder that invoice {invoice_number} for {amount} is due on {due_date}.\n\nThank you for your business.',
    enabled: true,
    channel: 'email',
  },
  {
    id: 'rem-2',
    title: 'Due Date Notification (Today)',
    triggerDays: 0,
    timing: 'on_due',
    subject: 'Notice: Invoice #{invoice_number} is due today',
    bodyTemplate: 'Hi {customer_name},\n\nYour invoice {invoice_number} ({amount}) is due for settlement today. Kindly process the remittance via NEFT/RTGS.\n\nBest regards.',
    enabled: true,
    channel: 'email',
  },
  {
    id: 'rem-3',
    title: 'Overdue First Notice (+7 Days Overdue)',
    triggerDays: 7,
    timing: 'after',
    subject: 'Overdue Notice: Invoice #{invoice_number} is 7 days past due',
    bodyTemplate: 'Attention {customer_name},\n\nWe have not received payment for invoice {invoice_number} due on {due_date}. Balance due: {amount}.\n\nPlease clear the outstanding dues immediately.',
    enabled: true,
    channel: 'email',
  },
  {
    id: 'rem-4',
    title: 'WhatsApp Immediate Urgent Chase (+15 Days)',
    triggerDays: 15,
    timing: 'after',
    subject: 'Urgent Payment Due',
    bodyTemplate: '⚠️ Urgent: Dear {customer_name}, your account shows an overdue balance of {amount} against invoice {invoice_number}. Please submit payment reference immediately.',
    enabled: true,
    channel: 'whatsapp',
  },
];

export const INITIAL_CHART_OF_ACCOUNTS: ChartOfAccount[] = [
  { code: '1000', name: 'Cash on Hand', type: 'asset', subType: 'Current Asset', balance: 0, currency: 'INR', description: 'Petty cash balances' },
  { code: '1010', name: 'Bank Operating Account', type: 'asset', subType: 'Bank Account', balance: 0, currency: 'INR', description: 'Primary working capital accounts' },
  { code: '1200', name: 'Accounts Receivable (Trade Debtors)', type: 'asset', subType: 'Current Asset', balance: 0, currency: 'INR', description: 'Amounts owed by customers on credit sales' },
  { code: '1300', name: 'GST Input Tax Credit (ITC)', type: 'asset', subType: 'Tax Asset', balance: 0, currency: 'INR', description: 'ITC available from vendor bills' },
  { code: '1400', name: 'TDS Receivable (Tax Deducted by Clients)', type: 'asset', subType: 'Tax Asset', balance: 0, currency: 'INR', description: 'Withheld by clients under Sec 194J/194C' },
  { code: '2000', name: 'Accounts Payable (Trade Creditors)', type: 'liability', subType: 'Current Liability', balance: 0, currency: 'INR', description: 'Amounts owed to suppliers for goods & services' },
  { code: '2100', name: 'GST Output Liability (CGST + SGST + IGST)', type: 'liability', subType: 'Tax Liability', balance: 0, currency: 'INR', description: 'Taxes collected on customer sales' },
  { code: '2200', name: 'TDS Payable to Government', type: 'liability', subType: 'Tax Liability', balance: 0, currency: 'INR', description: 'TDS withheld from vendors pending deposit' },
  { code: '3000', name: 'Partners / Owners Capital Equity', type: 'equity', subType: 'Equity', balance: 0, currency: 'INR', description: 'Contributed capital by founders' },
  { code: '3100', name: 'Retained Earnings', type: 'equity', subType: 'Equity', balance: 0, currency: 'INR', description: 'Accumulated profits retained in company' },
  { code: '4000', name: 'Sales & Cloud Services Revenue', type: 'income', subType: 'Operating Revenue', balance: 0, currency: 'INR', description: 'Income from client billing' },
  { code: '5000', name: 'Direct Cost of Sales / Infrastructure', type: 'expense', subType: 'Direct Expense', balance: 0, currency: 'INR', description: 'Hosting, SaaS infrastructure and contractor costs' },
  { code: '5100', name: 'Administrative & Operating Expenses', type: 'expense', subType: 'Operating Expense', balance: 0, currency: 'INR', description: 'Office rent, legal, compliance and professional fees' },
];
