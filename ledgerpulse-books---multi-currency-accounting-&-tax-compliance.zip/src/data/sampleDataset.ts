import {
  Customer,
  Vendor,
  Invoice,
  Bill,
  BankAccount,
  Expense
} from '../types';

export const SAMPLE_CUSTOMERS: Customer[] = [
  {
    id: 'cust-demo-1',
    name: 'Vikramaditya Sharma',
    companyName: 'Apex Cloud Solutions Pvt Ltd',
    email: 'accounts@apexcloud.in',
    phone: '+91 98201 11223',
    taxId: '27AAACA1234F1Z5',
    pan: 'AAACA1234F',
    placeOfSupply: '27-Maharashtra',
    billingAddress: 'Unit 402, Trade Center, BKC, Bandra East, Mumbai',
    pincode: '400051',
    currency: 'INR',
    paymentTermsDays: 30
  },
  {
    id: 'cust-demo-2',
    name: 'Ananya Deshmukh',
    companyName: 'Zenith Retail & Logistics LLP',
    email: 'billing@zenithlogistics.com',
    phone: '+91 80234 56789',
    taxId: '29AABCZ9876C1Z4',
    pan: 'AABCZ9876C',
    placeOfSupply: '29-Karnataka',
    billingAddress: '88, Outer Ring Road, Bellandur, Bengaluru',
    pincode: '560103',
    currency: 'INR',
    paymentTermsDays: 15
  },
  {
    id: 'cust-demo-3',
    name: 'David Miller',
    companyName: 'Global SaaS Tech Corp',
    email: 'ap@globalsaas.io',
    phone: '+1 415 555 0199',
    taxId: 'US-EIN-9844129',
    pan: 'AABCG9999M',
    placeOfSupply: '99-Other Territory / International',
    billingAddress: '500 Howard Street, San Francisco, CA',
    pincode: '94105',
    currency: 'USD',
    paymentTermsDays: 30
  }
];

export const SAMPLE_VENDORS: Vendor[] = [
  {
    id: 'vend-demo-1',
    name: 'Rajesh Kulkarni',
    companyName: 'Amazon Web Services India (AWS)',
    email: 'invoicing@aws.amazon.in',
    phone: '+91 22 6789 0000',
    taxId: '27AABCA5678K1Z2',
    pan: 'AABCA5678K',
    placeOfSupply: '27-Maharashtra',
    address: 'Bandra Kurla Complex, Mumbai',
    pincode: '400051',
    category: 'Hosting & Cloud Infrastructure',
    defaultTdsSection: '194J_TECH',
    currency: 'INR',
    bankAccount: {
      bankName: 'HDFC Bank',
      accountNumber: '•••• •••• 9821',
      ifscOrRouting: 'HDFC0000128'
    }
  },
  {
    id: 'vend-demo-2',
    name: 'Meera Iyer',
    companyName: 'Vertex Legal & Tax Advisors',
    email: 'tax@vertexadvisors.in',
    phone: '+91 11 2334 4556',
    taxId: '07AAACV4321P1Z9',
    pan: 'AAACV4321P',
    placeOfSupply: '07-Delhi',
    address: 'Barakhamba Road, Connaught Place, New Delhi',
    pincode: '110001',
    category: 'Legal & Professional Fees',
    defaultTdsSection: '194J_PROF',
    currency: 'INR',
    bankAccount: {
      bankName: 'ICICI Bank',
      accountNumber: '•••• •••• 4410',
      ifscOrRouting: 'ICIC0000004'
    }
  }
];

export const SAMPLE_BANK_ACCOUNTS: BankAccount[] = [
  {
    id: 'bank-demo-1',
    name: 'HDFC Current Account (INR)',
    accountNumber: '•••• •••• 4492',
    bankName: 'HDFC Bank',
    accountType: 'checking',
    currency: 'INR',
    balance: 425000,
    status: 'connected',
    institutionCode: 'HDFC_OPEN_BANKING',
    lastSyncedAt: new Date().toISOString()
  },
  {
    id: 'bank-demo-2',
    name: 'ICICI Corporate Treasury (INR)',
    accountNumber: '•••• •••• 8812',
    bankName: 'ICICI Bank',
    accountType: 'savings',
    currency: 'INR',
    balance: 280000,
    status: 'connected',
    institutionCode: 'ICICI_API',
    lastSyncedAt: new Date().toISOString()
  }
];

export const SAMPLE_INVOICES: Invoice[] = [
  {
    id: 'inv-demo-1',
    invoiceNumber: 'INV-2026-001',
    customerId: 'cust-demo-1',
    customerName: 'Apex Cloud Solutions Pvt Ltd',
    customerTaxId: '27AAACA1234F1Z5',
    placeOfSupply: '27-Maharashtra',
    isInterState: false,
    issueDate: '2026-10-15',
    dueDate: '2026-11-14',
    status: 'paid',
    currency: 'INR',
    exchangeRate: 1.0,
    subtotal: 100000,
    discountTotal: 0,
    cgstTotal: 9000,
    sgstTotal: 9000,
    igstTotal: 0,
    totalTax: 18000,
    totalAmount: 118000,
    baseCurrencyTotal: 118000,
    paidAmount: 118000,
    balanceDue: 0,
    tdsDeductedByCustomer: 2000,
    items: [
      {
        id: 'item-demo-1',
        description: 'Enterprise Cloud Architecture & DevOps Implementation',
        hsnSac: '998313',
        quantity: 1,
        unitRate: 100000,
        discountPercent: 0,
        taxRateId: 'tax-gst-18',
        taxableAmount: 100000,
        cgstAmount: 9000,
        sgstAmount: 9000,
        igstAmount: 0,
        totalAmount: 118000
      }
    ],
    remindersSent: [],
    notes: 'Payment received in full via RTGS.',
    terms: 'Net 30 days.'
  },
  {
    id: 'inv-demo-2',
    invoiceNumber: 'INV-2026-002',
    customerId: 'cust-demo-2',
    customerName: 'Zenith Retail & Logistics LLP',
    customerTaxId: '29AABCZ9876C1Z4',
    placeOfSupply: '29-Karnataka',
    isInterState: true,
    issueDate: '2026-10-25',
    dueDate: '2026-11-09',
    status: 'sent',
    currency: 'INR',
    exchangeRate: 1.0,
    subtotal: 75000,
    discountTotal: 0,
    cgstTotal: 0,
    sgstTotal: 0,
    igstTotal: 13500,
    totalTax: 13500,
    totalAmount: 88500,
    baseCurrencyTotal: 88500,
    paidAmount: 0,
    balanceDue: 88500,
    tdsDeductedByCustomer: 0,
    items: [
      {
        id: 'item-demo-2',
        description: 'Annual Software Maintenance & Automated Reporting Engine',
        hsnSac: '998314',
        quantity: 1,
        unitRate: 75000,
        discountPercent: 0,
        taxRateId: 'tax-gst-18',
        taxableAmount: 75000,
        cgstAmount: 0,
        sgstAmount: 0,
        igstAmount: 13500,
        totalAmount: 88500
      }
    ],
    remindersSent: [],
    notes: 'Payment due on or before Nov 9, 2026.',
    terms: 'Net 15 days.'
  }
];

export const SAMPLE_BILLS: Bill[] = [
  {
    id: 'bill-demo-1',
    billNumber: 'BILL-AWS-9041',
    vendorId: 'vend-demo-1',
    vendorName: 'Amazon Web Services India (AWS)',
    vendorTaxId: '27AABCA5678K1Z2',
    vendorPan: 'AABCA5678K',
    category: 'Hosting & Cloud Infrastructure',
    billDate: '2026-10-20',
    dueDate: '2026-11-19',
    status: 'approved',
    currency: 'INR',
    exchangeRate: 1.0,
    subtotal: 50000,
    taxAmount: 9000,
    grossAmount: 50000,
    tdsRatePercent: 2,
    tdsSection: '194J_TECH',
    tdsAmount: 1000,
    netPayable: 49000,
    balanceDue: 49000,
    paidAmount: 0,
    notes: 'Monthly AWS cloud infrastructure bill',
    items: [
      {
        id: 'bitem-demo-1',
        description: 'Compute EC2 & S3 Cloud Storage Oct 2026',
        category: 'Hosting & Cloud Infrastructure',
        hsnSac: '998315',
        quantity: 1,
        unitRate: 50000,
        taxRateId: 'tax-gst-18',
        amount: 50000,
        taxAmount: 9000
      }
    ]
  }
];

export const SAMPLE_EXPENSES: Expense[] = [
  {
    id: 'exp-demo-1',
    expenseNumber: 'EXP-2026-001',
    date: '2026-10-28',
    category: 'Software Subscriptions',
    accountCode: '6100',
    accountName: 'Software Licenses & Subscriptions',
    vendorName: 'GitHub Enterprise',
    paymentMode: 'credit_card',
    paidThroughBankAccountId: 'bank-demo-1',
    referenceNumber: 'TXN-GH-90812',
    amount: 12000,
    taxRateId: 'tax-gst-18',
    taxAmount: 2160,
    totalAmount: 14160,
    currency: 'INR',
    exchangeRate: 1.0,
    notes: 'Monthly engineering team GitHub seat licenses'
  }
];
