import React, { useState } from 'react';
import { AccountingProvider } from './context/AccountingContext';
import { Header } from './components/common/Header';
import { Sidebar } from './components/common/Sidebar';

// Core Dashboard & Financials
import { DashboardView } from './components/dashboard/DashboardView';
import { RecurringAndRemindersView } from './components/recurring/RecurringAndRemindersView';
import { BankingView } from './components/banking/BankingView';
import { TaxComplianceView } from './components/taxes/TaxComplianceView';
import { ChartOfAccountsView } from './components/accounts/ChartOfAccountsView';
import { SettingsView } from './components/settings/SettingsView';

// Sales Column Components & Modals
import { CustomersView } from './components/sales/CustomersView';
import { EstimatesView } from './components/sales/EstimatesView';
import { EstimateCreateModal } from './components/sales/EstimateCreateModal';
import { SalesOrdersView } from './components/sales/SalesOrdersView';
import { SalesOrderCreateModal } from './components/sales/SalesOrderCreateModal';
import { InvoicesView } from './components/invoices/InvoicesView';
import { InvoiceCreateModal } from './components/invoices/InvoiceCreateModal';
import { InvoiceDetailModal } from './components/invoices/InvoiceDetailModal';
import { RecordPaymentModal } from './components/invoices/RecordPaymentModal';
import { SalesReturnsView } from './components/sales/SalesReturnsView';
import { SalesReturnCreateModal } from './components/sales/SalesReturnCreateModal';

// Purchases Column Components & Modals
import { VendorsView } from './components/purchases/VendorsView';
import { PurchaseOrdersView } from './components/purchases/PurchaseOrdersView';
import { PurchaseOrderCreateModal } from './components/purchases/PurchaseOrderCreateModal';
import { BillsPayableView } from './components/bills/BillsPayableView';
import { BillCreateModal } from './components/bills/BillCreateModal';
import { ExpensesView } from './components/purchases/ExpensesView';
import { ExpenseCreateModal } from './components/purchases/ExpenseCreateModal';
import { PurchaseReturnsView } from './components/purchases/PurchaseReturnsView';
import { PurchaseReturnCreateModal } from './components/purchases/PurchaseReturnCreateModal';

// Reports Column Component
import { ReportsView, ReportTab } from './components/reports/ReportsView';

import { AddCustomerModal } from './components/common/AddCustomerModal';
import { AddVendorModal } from './components/common/AddVendorModal';
import { Customer, Vendor } from './types';

function MainLayout() {
  const [activeView, setActiveView] = useState<string>('dashboard');

  // Modal dialog open/close states
  const [isCreateInvoiceOpen, setIsCreateInvoiceOpen] = useState(false);
  const [isCreateBillOpen, setIsCreateBillOpen] = useState(false);
  const [isAddCustomerOpen, setIsAddCustomerOpen] = useState(false);
  const [isAddVendorOpen, setIsAddVendorOpen] = useState(false);
  const [isCreateEstimateOpen, setIsCreateEstimateOpen] = useState(false);
  const [isCreateOrderOpen, setIsCreateOrderOpen] = useState(false);
  const [isCreateCreditNoteOpen, setIsCreateCreditNoteOpen] = useState(false);
  const [isCreatePOOpen, setIsCreatePOOpen] = useState(false);
  const [isCreateExpenseOpen, setIsCreateExpenseOpen] = useState(false);
  const [isCreateDebitNoteOpen, setIsCreateDebitNoteOpen] = useState(false);

  // Edit states for customer and vendor
  const [customerToEdit, setCustomerToEdit] = useState<Customer | null>(null);
  const [vendorToEdit, setVendorToEdit] = useState<Vendor | null>(null);

  // Preselected contextual state
  const [viewingInvoiceId, setViewingInvoiceId] = useState<string | null>(null);
  const [paymentInvoiceId, setPaymentInvoiceId] = useState<string | null>(null);
  const [selectedBillIdForPayment, setSelectedBillIdForPayment] = useState<string | null>(null);
  const [targetCustomerId, setTargetCustomerId] = useState<string | undefined>(undefined);
  const [targetVendorId, setTargetVendorId] = useState<string | undefined>(undefined);

  // Cross-entity shortcuts
  const handleOpenPaymentFromInvoice = (invId: string) => {
    setPaymentInvoiceId(invId);
  };

  const handlePayBillFromDashboard = (billId: string) => {
    setSelectedBillIdForPayment(billId);
    setActiveView('bills');
  };

  const handleCreateEstimateForCustomer = (custId: string) => {
    setTargetCustomerId(custId);
    setIsCreateEstimateOpen(true);
  };

  const handleCreateInvoiceForCustomer = (custId: string) => {
    setTargetCustomerId(custId);
    setIsCreateInvoiceOpen(true);
  };

  const handleCreatePOForVendor = (vendId: string) => {
    setTargetVendorId(vendId);
    setIsCreatePOOpen(true);
  };

  const handleCreateBillForVendor = (vendId: string) => {
    setTargetVendorId(vendId);
    setIsCreateBillOpen(true);
  };

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-slate-50 font-sans text-slate-800">
      {/* Navigation Sidebar */}
      <Sidebar activeView={activeView} setActiveView={setActiveView} />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Top Header */}
        <Header
          activeView={activeView}
          onOpenCreateInvoice={() => {
            setTargetCustomerId(undefined);
            setIsCreateInvoiceOpen(true);
          }}
          onOpenCreateBill={() => {
            setTargetVendorId(undefined);
            setIsCreateBillOpen(true);
          }}
          onOpenAddCustomer={() => setIsAddCustomerOpen(true)}
          onOpenAddVendor={() => setIsAddVendorOpen(true)}
          onOpenCreateEstimate={() => {
            setTargetCustomerId(undefined);
            setIsCreateEstimateOpen(true);
          }}
          onOpenCreateOrder={() => {
            setTargetCustomerId(undefined);
            setIsCreateOrderOpen(true);
          }}
          onOpenCreatePO={() => {
            setTargetVendorId(undefined);
            setIsCreatePOOpen(true);
          }}
          onOpenCreateExpense={() => setIsCreateExpenseOpen(true)}
        />

        {/* Viewport View Component */}
        <main className="flex-1 overflow-y-auto p-6 md:p-8">
          {/* Dashboard */}
          {activeView === 'dashboard' && (
            <DashboardView
              onNavigateToInvoices={() => setActiveView('invoices')}
              onNavigateToBills={() => setActiveView('bills')}
              onNavigateToBanking={() => setActiveView('banking')}
              onViewInvoice={id => setViewingInvoiceId(id)}
              onPayBill={handlePayBillFromDashboard}
            />
          )}

          {/* === SALES COLUMN === */}
          {activeView === 'customers' && (
            <CustomersView
              onOpenAddCustomer={() => {
                setCustomerToEdit(null);
                setIsAddCustomerOpen(true);
              }}
              onEditCustomer={cust => {
                setCustomerToEdit(cust);
                setIsAddCustomerOpen(true);
              }}
              onCreateEstimateForCustomer={handleCreateEstimateForCustomer}
              onCreateInvoiceForCustomer={handleCreateInvoiceForCustomer}
            />
          )}

          {activeView === 'estimates' && (
            <EstimatesView
              onOpenCreateEstimate={() => {
                setTargetCustomerId(undefined);
                setIsCreateEstimateOpen(true);
              }}
              onNavigateToInvoices={() => setActiveView('invoices')}
              onNavigateToSalesOrders={() => setActiveView('sales_orders')}
            />
          )}

          {activeView === 'sales_orders' && (
            <SalesOrdersView
              onOpenCreateOrder={() => {
                setTargetCustomerId(undefined);
                setIsCreateOrderOpen(true);
              }}
              onNavigateToInvoices={() => setActiveView('invoices')}
            />
          )}

          {activeView === 'invoices' && (
            <InvoicesView
              onOpenCreateModal={() => {
                setTargetCustomerId(undefined);
                setIsCreateInvoiceOpen(true);
              }}
              onViewInvoice={id => setViewingInvoiceId(id)}
              onRecordPayment={id => setPaymentInvoiceId(id)}
            />
          )}

          {activeView === 'sales_returns' && (
            <SalesReturnsView
              onOpenCreateCreditNote={() => setIsCreateCreditNoteOpen(true)}
            />
          )}

          {/* === PURCHASES COLUMN === */}
          {activeView === 'vendors' && (
            <VendorsView
              onOpenAddVendor={() => {
                setVendorToEdit(null);
                setIsAddVendorOpen(true);
              }}
              onEditVendor={vend => {
                setVendorToEdit(vend);
                setIsAddVendorOpen(true);
              }}
              onCreatePOForVendor={handleCreatePOForVendor}
              onCreateBillForVendor={handleCreateBillForVendor}
            />
          )}

          {activeView === 'purchase_orders' && (
            <PurchaseOrdersView
              onOpenCreatePO={() => {
                setTargetVendorId(undefined);
                setIsCreatePOOpen(true);
              }}
              onNavigateToBills={() => setActiveView('bills')}
            />
          )}

          {activeView === 'bills' && (
            <BillsPayableView
              onOpenCreateBill={() => {
                setTargetVendorId(undefined);
                setIsCreateBillOpen(true);
              }}
              selectedBillIdForPayment={selectedBillIdForPayment}
            />
          )}

          {activeView === 'expenses' && (
            <ExpensesView
              onOpenCreateExpense={() => setIsCreateExpenseOpen(true)}
            />
          )}

          {activeView === 'purchase_returns' && (
            <PurchaseReturnsView
              onOpenCreateDebitNote={() => setIsCreateDebitNoteOpen(true)}
            />
          )}

          {/* === REPORTS COLUMN === */}
          {(activeView === 'reports' || activeView === 'reports_balance_sheet') && (
            <ReportsView
              initialTab="balance_sheet"
              onNavigateToInvoices={() => setActiveView('invoices')}
              onNavigateToBills={() => setActiveView('bills')}
              onViewInvoice={id => setViewingInvoiceId(id)}
              onPayBill={handlePayBillFromDashboard}
            />
          )}

          {activeView === 'reports_profit_loss' && (
            <ReportsView
              initialTab="profit_loss"
              onNavigateToInvoices={() => setActiveView('invoices')}
              onNavigateToBills={() => setActiveView('bills')}
              onViewInvoice={id => setViewingInvoiceId(id)}
              onPayBill={handlePayBillFromDashboard}
            />
          )}

          {activeView === 'reports_cash_flow' && (
            <ReportsView
              initialTab="cash_flow"
              onNavigateToInvoices={() => setActiveView('invoices')}
              onNavigateToBills={() => setActiveView('bills')}
              onViewInvoice={id => setViewingInvoiceId(id)}
              onPayBill={handlePayBillFromDashboard}
            />
          )}

          {activeView === 'reports_accounts_payables' && (
            <ReportsView
              initialTab="accounts_payables"
              onNavigateToInvoices={() => setActiveView('invoices')}
              onNavigateToBills={() => setActiveView('bills')}
              onViewInvoice={id => setViewingInvoiceId(id)}
              onPayBill={handlePayBillFromDashboard}
            />
          )}

          {activeView === 'reports_accounts_receivables' && (
            <ReportsView
              initialTab="accounts_receivables"
              onNavigateToInvoices={() => setActiveView('invoices')}
              onNavigateToBills={() => setActiveView('bills')}
              onViewInvoice={id => setViewingInvoiceId(id)}
              onPayBill={handlePayBillFromDashboard}
            />
          )}

          {activeView === 'reports_financial_ratios' && (
            <ReportsView
              initialTab="financial_ratios"
              onNavigateToInvoices={() => setActiveView('invoices')}
              onNavigateToBills={() => setActiveView('bills')}
              onViewInvoice={id => setViewingInvoiceId(id)}
              onPayBill={handlePayBillFromDashboard}
            />
          )}

          {/* === ACCOUNTING & BANKING === */}
          {activeView === 'recurring' && (
            <RecurringAndRemindersView />
          )}

          {activeView === 'banking' && (
            <BankingView />
          )}

          {activeView === 'taxes' && (
            <TaxComplianceView />
          )}

          {activeView === 'accounts' && (
            <ChartOfAccountsView />
          )}

          {activeView === 'settings' && (
            <SettingsView />
          )}
        </main>
      </div>

      {/* Global Modals: Sales */}
      <InvoiceCreateModal
        isOpen={isCreateInvoiceOpen}
        onClose={() => {
          setIsCreateInvoiceOpen(false);
          setTargetCustomerId(undefined);
        }}
        onInvoiceCreated={id => setViewingInvoiceId(id)}
        preselectedCustomerId={targetCustomerId}
      />

      <EstimateCreateModal
        isOpen={isCreateEstimateOpen}
        onClose={() => {
          setIsCreateEstimateOpen(false);
          setTargetCustomerId(undefined);
        }}
        preselectedCustomerId={targetCustomerId}
      />

      <SalesOrderCreateModal
        isOpen={isCreateOrderOpen}
        onClose={() => {
          setIsCreateOrderOpen(false);
          setTargetCustomerId(undefined);
        }}
        preselectedCustomerId={targetCustomerId}
      />

      <SalesReturnCreateModal
        isOpen={isCreateCreditNoteOpen}
        onClose={() => setIsCreateCreditNoteOpen(false)}
      />

      <InvoiceDetailModal
        invoiceId={viewingInvoiceId}
        onClose={() => setViewingInvoiceId(null)}
        onRecordPayment={handleOpenPaymentFromInvoice}
      />

      <RecordPaymentModal
        isOpen={!!paymentInvoiceId}
        invoiceId={paymentInvoiceId}
        onClose={() => setPaymentInvoiceId(null)}
      />

      {/* Global Modals: Purchases */}
      <BillCreateModal
        isOpen={isCreateBillOpen}
        onClose={() => {
          setIsCreateBillOpen(false);
          setTargetVendorId(undefined);
        }}
        preselectedVendorId={targetVendorId}
      />

      <PurchaseOrderCreateModal
        isOpen={isCreatePOOpen}
        onClose={() => {
          setIsCreatePOOpen(false);
          setTargetVendorId(undefined);
        }}
        preselectedVendorId={targetVendorId}
      />

      <ExpenseCreateModal
        isOpen={isCreateExpenseOpen}
        onClose={() => setIsCreateExpenseOpen(false)}
      />

      <PurchaseReturnCreateModal
        isOpen={isCreateDebitNoteOpen}
        onClose={() => setIsCreateDebitNoteOpen(false)}
      />

      {/* Global Modals: Contacts */}
      <AddCustomerModal
        isOpen={isAddCustomerOpen}
        customerToEdit={customerToEdit}
        onClose={() => {
          setIsAddCustomerOpen(false);
          setCustomerToEdit(null);
        }}
      />

      <AddVendorModal
        isOpen={isAddVendorOpen}
        vendorToEdit={vendorToEdit}
        onClose={() => {
          setIsAddVendorOpen(false);
          setVendorToEdit(null);
        }}
      />
    </div>
  );
}

export default function App() {
  return (
    <AccountingProvider>
      <MainLayout />
    </AccountingProvider>
  );
}
