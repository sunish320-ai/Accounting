export type CurrencyCode = 'USD' | 'INR' | 'EUR' | 'GBP' | 'AED' | 'SGD' | 'CAD' | 'AUD' | 'JPY';

export interface Currency {
  code: CurrencyCode;
  symbol: string;
  name: string;
  exchangeRateToBase: number; // 1 unit of this currency in base currency (e.g. INR)
}

export type TaxJurisdiction = 'INDIA' | 'USA' | 'UK_EU' | 'UAE';

export interface TaxRate {
  id: string;
  name: string;
  rate: number; // percentage, e.g. 18 for 18%
  type: 'GST_18' | 'GST_12' | 'GST_5' | 'GST_28' | 'GST_0' | 'VAT_20' | 'VAT_5' | 'SALES_TAX_8' | 'EXEMPT';
  description: string;
}

export interface TDSRate {
  section: '194C_INDIVIDUAL' | '194C_COMPANY' | '194J_TECH' | '194J_PROF' | '194I_RENT' | '194H_COMMISSION' | '194Q_PURCHASE';
  code: string;
  label: string;
  rate: number; // percentage, e.g. 10 for 10%
  threshold: number; // yearly threshold in base currency
  applicableFor: 'Individual' | 'Company' | 'All';
}

export interface Customer {
  id: string;
  name: string;
  companyName: string;
  email: string;
  phone: string;
  currency: CurrencyCode;
  taxId: string; // GSTIN or Tax ID
  pan?: string;
  placeOfSupply: string; // State or Country code e.g. "27-Maharashtra"
  billingAddress: string;
  pincode?: string;
  paymentTermsDays: number;
}

export interface Vendor {
  id: string;
  name: string;
  companyName: string;
  email: string;
  phone: string;
  currency: CurrencyCode;
  taxId: string; // GSTIN or VAT
  pan: string;
  placeOfSupply?: string; // State or Country code e.g. "27-Maharashtra"
  defaultTdsSection?: TDSRate['section'];
  bankAccount: {
    accountNumber: string;
    ifscOrRouting: string;
    bankName: string;
  };
  address: string;
  pincode?: string;
  category: string;
}

export interface InvoiceItem {
  id: string;
  description: string;
  hsnSac: string; // HSN or SAC code (e.g. 998311 for IT services)
  quantity: number;
  unitRate: number; // In invoice currency
  discountPercent: number;
  taxRateId: string;
  // Computed values
  taxableAmount: number;
  cgstAmount: number;
  sgstAmount: number;
  igstAmount: number;
  totalAmount: number;
}

export type InvoiceStatus = 'draft' | 'sent' | 'partially_paid' | 'paid' | 'overdue' | 'void';

export type EstimateStatus = 'draft' | 'sent' | 'accepted' | 'declined' | 'invoiced';

export interface Estimate {
  id: string;
  estimateNumber: string;
  customerId: string;
  customerName: string;
  customerTaxId: string;
  placeOfSupply: string;
  isInterState: boolean;
  date: string;
  expiryDate: string;
  status: EstimateStatus;
  currency: CurrencyCode;
  exchangeRate: number;
  items: InvoiceItem[];
  subtotal: number;
  discountTotal: number;
  totalTax: number;
  totalAmount: number;
  notes: string;
  terms: string;
  convertedInvoiceId?: string;
  convertedSalesOrderId?: string;
}

export type SalesOrderStatus = 'draft' | 'confirmed' | 'fulfilled' | 'invoiced' | 'cancelled';

export interface SalesOrder {
  id: string;
  orderNumber: string;
  estimateId?: string;
  customerId: string;
  customerName: string;
  customerTaxId: string;
  placeOfSupply: string;
  date: string;
  expectedDeliveryDate: string;
  status: SalesOrderStatus;
  currency: CurrencyCode;
  exchangeRate: number;
  items: InvoiceItem[];
  subtotal: number;
  totalTax: number;
  totalAmount: number;
  convertedInvoiceId?: string;
  notes: string;
}

export type CreditNoteStatus = 'draft' | 'open' | 'closed' | 'refunded';

export interface CreditNote {
  id: string;
  creditNoteNumber: string;
  invoiceId?: string;
  customerId: string;
  customerName: string;
  customerTaxId: string;
  date: string;
  status: CreditNoteStatus;
  currency: CurrencyCode;
  exchangeRate: number;
  items: InvoiceItem[];
  subtotal: number;
  totalTax: number;
  totalAmount: number;
  refundedAmount: number;
  reason: string;
  notes: string;
}

export type PurchaseOrderStatus = 'draft' | 'issued' | 'billed' | 'cancelled';

export interface PurchaseOrder {
  id: string;
  poNumber: string;
  vendorId: string;
  vendorName: string;
  vendorTaxId: string;
  vendorPan: string;
  date: string;
  expectedDate: string;
  status: PurchaseOrderStatus;
  currency: CurrencyCode;
  exchangeRate: number;
  items: BillLineItem[];
  subtotal: number;
  taxAmount: number;
  grossAmount: number;
  convertedBillId?: string;
  notes: string;
}

export interface Expense {
  id: string;
  expenseNumber: string;
  date: string;
  category: string;
  accountCode: string;
  accountName: string;
  vendorId?: string;
  vendorName?: string;
  amount: number;
  currency: CurrencyCode;
  exchangeRate: number;
  taxRateId?: string;
  taxAmount: number;
  totalAmount: number;
  paidThroughBankAccountId: string;
  paymentMode: 'bank_transfer' | 'credit_card' | 'upi' | 'cash';
  referenceNumber: string;
  notes: string;
}

export type DebitNoteStatus = 'draft' | 'open' | 'adjusted' | 'refunded';

export interface DebitNote {
  id: string;
  debitNoteNumber: string;
  billId?: string;
  vendorId: string;
  vendorName: string;
  vendorPan: string;
  date: string;
  status: DebitNoteStatus;
  currency: CurrencyCode;
  exchangeRate: number;
  items: BillLineItem[];
  subtotal: number;
  taxAmount: number;
  grossAmount: number;
  tdsReversalAmount: number;
  netDebitAmount: number;
  reason: string;
  notes: string;
}

export interface PaymentReminderLog {
  id: string;
  date: string;
  channel: 'email' | 'whatsapp';
  recipient: string;
  message: string;
}

export interface Invoice {
  id: string;
  invoiceNumber: string;
  customerId: string;
  customerName: string;
  customerTaxId: string;
  placeOfSupply: string;
  isInterState: boolean; // For India GST: true = IGST, false = CGST + SGST
  issueDate: string; // YYYY-MM-DD
  dueDate: string; // YYYY-MM-DD
  status: InvoiceStatus;
  currency: CurrencyCode;
  exchangeRate: number; // Rate to base currency at time of invoice
  items: InvoiceItem[];
  subtotal: number;
  discountTotal: number;
  cgstTotal: number;
  sgstTotal: number;
  igstTotal: number;
  totalTax: number;
  totalAmount: number; // In invoice currency
  baseCurrencyTotal: number; // In base currency
  paidAmount: number;
  tdsDeductedByCustomer: number; // TDS withheld by buyer (asset for seller)
  balanceDue: number;
  notes: string;
  terms: string;
  recurringConfigId?: string;
  remindersSent: PaymentReminderLog[];
}

export interface RecurringInvoiceConfig {
  id: string;
  customerName: string;
  customerId: string;
  frequency: 'weekly' | 'monthly' | 'quarterly' | 'annually';
  nextRunDate: string;
  lastRunDate?: string;
  autoSendEmail: boolean;
  active: boolean;
  amount: number;
  currency: CurrencyCode;
  description: string;
}

export interface PaymentReminderRule {
  id: string;
  title: string;
  triggerDays: number; // e.g. -3 (3 days before due), 0 (on due date), 7 (7 days overdue), 15 (15 days overdue)
  timing: 'before' | 'on_due' | 'after';
  subject: string;
  bodyTemplate: string;
  enabled: boolean;
  channel: 'email' | 'whatsapp';
}

export type BillStatus = 'draft' | 'approved' | 'partially_paid' | 'paid' | 'overdue';

export interface BillLineItem {
  id: string;
  description: string;
  category: string;
  hsnSac: string;
  quantity: number;
  unitRate: number;
  taxRateId: string;
  amount: number;
  taxAmount: number;
}

export interface Bill {
  id: string;
  billNumber: string;
  vendorId: string;
  vendorName: string;
  vendorTaxId: string;
  vendorPan: string;
  billDate: string;
  dueDate: string;
  status: BillStatus;
  currency: CurrencyCode;
  exchangeRate: number;
  items: BillLineItem[];
  subtotal: number;
  taxAmount: number;
  grossAmount: number;
  // Regional TDS deduction fields
  tdsSection?: TDSRate['section'];
  tdsRatePercent: number;
  tdsAmount: number; // Amount deducted and credited to TDS Payable to Gov
  netPayable: number; // grossAmount - tdsAmount
  paidAmount: number;
  balanceDue: number;
  notes: string;
  category: string;
}

export interface BankAccount {
  id: string;
  name: string;
  accountNumber: string;
  bankName: string;
  accountType: 'checking' | 'savings' | 'credit_card' | 'merchant';
  currency: CurrencyCode;
  balance: number;
  status: 'connected' | 'syncing' | 'error';
  lastSyncedAt: string;
  institutionCode: string;
}

export interface BankTransaction {
  id: string;
  bankAccountId: string;
  date: string;
  description: string;
  amount: number; // positive = credit (inflow), negative = debit (outflow)
  currency: CurrencyCode;
  referenceNumber: string;
  matchStatus: 'matched' | 'unmatched' | 'excluded' | 'manual';
  matchedType?: 'invoice' | 'bill' | 'expense' | 'transfer' | 'manual';
  matchedEntityId?: string;
  matchedEntityDescription?: string;
  suggestedMatchId?: string;
  suggestedMatchReason?: string;
}

export interface ChartOfAccount {
  code: string;
  name: string;
  type: 'asset' | 'liability' | 'equity' | 'income' | 'expense';
  subType: string;
  balance: number;
  currency: CurrencyCode;
  description: string;
}

export interface JournalLine {
  accountCode: string;
  accountName: string;
  debit: number;
  credit: number;
  description: string;
}

export interface JournalEntry {
  id: string;
  entryNumber: string;
  date: string;
  reference: string;
  narration: string;
  lines: JournalLine[];
  totalDebit: number;
  totalCredit: number;
}

export interface OrganizationSettings {
  businessName: string;
  legalEntityName: string;
  gstin: string;
  pan: string;
  vatNumber: string;
  ein: string;
  jurisdiction: TaxJurisdiction;
  baseCurrency: CurrencyCode;
  registeredState: string;
  registeredCountry: string;
  email: string;
  phone: string;
  website: string;
  address: string;
  fiscalYearStartMonth: number; // 4 for April (India), 1 for January (US/UK)
  enableAutoTds: boolean;
  enableAutoBankSync: boolean;
  syncIntervalMinutes: number;
}
