import React, { useState } from 'react';
import { useAccounting } from '../../context/AccountingContext';
import { X, Plus, Trash2, Calculator, Info } from 'lucide-react';
import { InvoiceItem, CurrencyCode } from '../../types';
import { INDIAN_GST_STATES } from '../../utils/gstHelper';

interface InvoiceCreateModalProps {
  isOpen: boolean;
  onClose: () => void;
  onInvoiceCreated: (invoiceId: string) => void;
  preselectedCustomerId?: string;
}

export const InvoiceCreateModal: React.FC<InvoiceCreateModalProps> = ({
  isOpen,
  onClose,
  onInvoiceCreated,
  preselectedCustomerId,
}) => {
  const {
    customers,
    currencies,
    taxRates,
    settings,
    createInvoice,
    invoices,
    formatMoney
  } = useAccounting();

  if (!isOpen) return null;

  // Selected Customer
  const [selectedCustomerId, setSelectedCustomerId] = useState<string>(
    preselectedCustomerId || customers[0]?.id || ''
  );
  const currentCustomer = customers.find(c => c.id === selectedCustomerId) || customers[0];

  // Dates & Details
  const defaultIssueDate = new Date().toISOString().split('T')[0];
  const [issueDate, setIssueDate] = useState(defaultIssueDate);
  const [termsDays, setTermsDays] = useState(currentCustomer?.paymentTermsDays || 30);
  const [placeOfSupply, setPlaceOfSupply] = useState(currentCustomer?.placeOfSupply || '27-Maharashtra');

  const calculateDueDate = (issued: string, days: number) => {
    const d = new Date(issued);
    d.setDate(d.getDate() + days);
    return d.toISOString().split('T')[0];
  };

  const [dueDate, setDueDate] = useState(calculateDueDate(defaultIssueDate, currentCustomer?.paymentTermsDays || 30));
  const [currency, setCurrency] = useState<CurrencyCode>(currentCustomer?.currency || 'INR');

  const nextInvoiceNumber = `INV-2026-00${invoices.length + 47}`;
  const [invoiceNumber, setInvoiceNumber] = useState(nextInvoiceNumber);

  // Line items state
  const [items, setItems] = useState<InvoiceItem[]>([
    {
      id: `item-${Date.now()}-1`,
      description: 'Professional Services / Technical Consulting',
      hsnSac: '998313',
      quantity: 1,
      unitRate: 10000,
      discountPercent: 0,
      taxRateId: 'tax-gst-18',
      taxableAmount: 10000,
      cgstAmount: 900,
      sgstAmount: 900,
      igstAmount: 0,
      totalAmount: 11800
    }
  ]);

  const [notes, setNotes] = useState('Payment via NEFT/RTGS to our designated current account. Please quote invoice number.');
  const [terms, setTerms] = useState('Standard payment terms: 30 days from invoice date. Subject to Mumbai jurisdiction.');

  // Determine if Inter-state or Intra-state supply based on place of supply code
  const isInterState = !placeOfSupply.startsWith('27');

  // Recalculate row amounts
  const updateRow = (index: number, updates: Partial<InvoiceItem>) => {
    setItems(prev => {
      const next = [...prev];
      const item = { ...next[index], ...updates };

      const rawAmount = (item.quantity || 0) * (item.unitRate || 0);
      const discount = rawAmount * ((item.discountPercent || 0) / 100);

      const taxable = rawAmount - discount;

      const rateObj = taxRates.find(t => t.id === item.taxRateId);
      const ratePct = rateObj ? rateObj.rate : 0;

      let cgst = 0;
      let sgst = 0;
      let igst = 0;

      if (isInterState) {
        igst = taxable * (ratePct / 100);
      } else {
        cgst = taxable * (ratePct / 200);
        sgst = taxable * (ratePct / 200);
      }

      const totalTax = isInterState ? igst : (cgst + sgst);
      const rowTotal = taxable + totalTax;

      next[index] = {
        ...item,
        taxableAmount: taxable,
        cgstAmount: cgst,
        sgstAmount: sgst,
        igstAmount: igst,
        totalAmount: rowTotal
      };
      return next;
    });
  };

  const addRow = () => {
    const newItem: InvoiceItem = {
      id: `item-${Date.now()}-${items.length}`,
      description: '',
      hsnSac: '998311',
      quantity: 1,
      unitRate: 0,
      discountPercent: 0,
      taxRateId: 'tax-gst-18',
      taxableAmount: 0,
      cgstAmount: 0,
      sgstAmount: 0,
      igstAmount: 0,
      totalAmount: 0
    };
    setItems([...items, newItem]);
  };

  const removeRow = (index: number) => {
    if (items.length <= 1) return;
    setItems(items.filter((_, idx) => idx !== index));
  };

  // Grand totals
  const subtotal = items.reduce((sum, item) => sum + ((item.quantity || 0) * (item.unitRate || 0)), 0);
  const discountTotal = items.reduce((sum, item) => sum + (((item.quantity || 0) * (item.unitRate || 0)) * ((item.discountPercent || 0) / 100)), 0);
  const taxableTotal = items.reduce((sum, item) => sum + item.taxableAmount, 0);
  const cgstTotal = items.reduce((sum, item) => sum + item.cgstAmount, 0);
  const sgstTotal = items.reduce((sum, item) => sum + item.sgstAmount, 0);
  const igstTotal = items.reduce((sum, item) => sum + item.igstAmount, 0);
  const totalTax = cgstTotal + sgstTotal + igstTotal;
  const grandTotal = taxableTotal + totalTax;

  const curObj = currencies.find(c => c.code === currency) || { exchangeRateToBase: 1 };
  const baseCurrencyTotal = grandTotal * curObj.exchangeRateToBase;

  const handleSubmit = (status: 'draft' | 'sent') => {
    if (!currentCustomer) return;

    const created = createInvoice({
      invoiceNumber,
      customerId: currentCustomer.id,
      customerName: currentCustomer.companyName,
      customerTaxId: currentCustomer.taxId,
      placeOfSupply,
      isInterState,
      issueDate,
      dueDate,
      status,
      currency,
      exchangeRate: curObj.exchangeRateToBase,
      items,
      subtotal,
      discountTotal,
      cgstTotal,
      sgstTotal,
      igstTotal,
      totalTax,
      totalAmount: grandTotal,
      baseCurrencyTotal,
      paidAmount: 0,
      tdsDeductedByCustomer: 0,
      notes,
      terms
    });

    onInvoiceCreated(created.id);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="bg-white w-full max-w-4xl rounded-2xl shadow-2xl border border-slate-200 overflow-hidden my-6 animate-in fade-in zoom-in-95">
        {/* Modal Header */}
        <div className="px-6 py-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
          <div>
            <h2 className="text-sm font-bold text-slate-900">Create Tax Invoice</h2>
            <p className="text-xs text-slate-500">
              Automated GST / Tax breakdown, multi-currency conversion, and general ledger journal posting
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-200/50 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 space-y-6 max-h-[75vh] overflow-y-auto">
          {/* Customer & Primary Details Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Customer Name <span className="text-rose-500">*</span>
              </label>
              <select
                value={selectedCustomerId}
                onChange={e => {
                  setSelectedCustomerId(e.target.value);
                  const cust = customers.find(c => c.id === e.target.value);
                  if (cust) {
                    setCurrency(cust.currency);
                    setDueDate(calculateDueDate(issueDate, cust.paymentTermsDays));
                    if (cust.placeOfSupply) setPlaceOfSupply(cust.placeOfSupply);
                  }
                }}
                className="w-full text-xs bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 focus:ring-1 focus:ring-blue-500 font-medium"
              >
                {customers.map(c => (
                  <option key={c.id} value={c.id}>
                    {c.companyName} ({c.name})
                  </option>
                ))}
              </select>
              {currentCustomer && (
                <div className="mt-1 text-[11px] text-slate-500">
                  GSTIN/Tax ID: <span className="font-mono">{currentCustomer.taxId}</span>
                </div>
              )}
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Invoice Number <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                value={invoiceNumber}
                onChange={e => setInvoiceNumber(e.target.value)}
                className="w-full text-xs font-mono font-bold bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-blue-600"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Invoice Currency & Rate
              </label>
              <div className="flex gap-2">
                <select
                  value={currency}
                  onChange={e => setCurrency(e.target.value as CurrencyCode)}
                  className="w-1/2 text-xs bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 font-mono font-semibold"
                >
                  {currencies.map(c => (
                    <option key={c.code} value={c.code}>
                      {c.code} ({c.symbol})
                    </option>
                  ))}
                </select>
                <div className="w-1/2 text-xs bg-slate-100 border border-slate-200 rounded-lg px-3 py-2 text-slate-600 flex items-center font-mono text-[11px] truncate">
                  1 {currency} = {curObj.exchangeRateToBase} {settings.baseCurrency}
                </div>
              </div>
            </div>
          </div>

          {/* Place of Supply & Tax Treatment Indicator */}
          <div className="bg-blue-50/50 border border-blue-200/80 rounded-lg p-3 text-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <Info className="w-4 h-4 text-blue-600 shrink-0" />
              <div className="flex items-center gap-2">
                <span className="font-semibold text-slate-800 shrink-0">Place of Supply:</span>
                <select
                  value={placeOfSupply}
                  onChange={e => setPlaceOfSupply(e.target.value)}
                  className="text-xs bg-white border border-blue-200 rounded-md px-2 py-1 font-mono font-semibold text-slate-800"
                >
                  {INDIAN_GST_STATES.map(st => (
                    <option key={st.code} value={`${st.code}-${st.name}`}>
                      {st.code} - {st.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>
            <div className="font-semibold text-blue-800 shrink-0">
              Tax Rule: {isInterState ? 'Inter-State (IGST 18%)' : 'Intra-State (9% CGST + 9% SGST)'}
            </div>
          </div>


          {/* Dates & Terms */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Issue Date</label>
              <input
                type="date"
                value={issueDate}
                onChange={e => {
                  setIssueDate(e.target.value);
                  setDueDate(calculateDueDate(e.target.value, termsDays));
                }}
                className="w-full text-xs bg-slate-50 border border-slate-200 rounded-lg px-3 py-2"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Payment Terms</label>
              <select
                value={termsDays}
                onChange={e => {
                  const days = Number(e.target.value);
                  setTermsDays(days);
                  setDueDate(calculateDueDate(issueDate, days));
                }}
                className="w-full text-xs bg-slate-50 border border-slate-200 rounded-lg px-3 py-2"
              >
                <option value={0}>Due on Receipt</option>
                <option value={15}>Net 15 Days</option>
                <option value={30}>Net 30 Days</option>
                <option value={45}>Net 45 Days</option>
                <option value={60}>Net 60 Days</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Due Date</label>
              <input
                type="date"
                value={dueDate}
                onChange={e => setDueDate(e.target.value)}
                className="w-full text-xs bg-slate-50 border border-slate-200 rounded-lg px-3 py-2"
              />
            </div>
          </div>

          {/* Line Items Table */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">Item Table</h3>
              <span className="text-[11px] text-slate-400">Includes HSN/SAC & Regional Tax Calculations</span>
            </div>

            <div className="border border-slate-200 rounded-lg overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="bg-slate-100/75 border-b border-slate-200 text-slate-600 font-semibold">
                    <th className="py-2 px-3 w-5/12">Item Description</th>
                    <th className="py-2 px-2 w-20">HSN/SAC</th>
                    <th className="py-2 px-2 w-16 text-right">Qty</th>
                    <th className="py-2 px-2 w-28 text-right">Unit Rate</th>
                    <th className="py-2 px-2 w-16 text-right">Disc %</th>
                    <th className="py-2 px-2 w-32">Tax Rate</th>
                    <th className="py-2 px-3 w-28 text-right">Amount</th>
                    <th className="py-2 px-1 w-10 text-center"></th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {items.map((item, idx) => (
                    <tr key={item.id} className="hover:bg-slate-50/50">
                      <td className="py-2 px-3">
                        <input
                          type="text"
                          value={item.description}
                          onChange={e => updateRow(idx, { description: e.target.value })}
                          placeholder="Service / Product description..."
                          className="w-full text-xs bg-transparent border-0 focus:ring-0 p-0 text-slate-800 font-medium"
                        />
                      </td>
                      <td className="py-2 px-2">
                        <input
                          type="text"
                          value={item.hsnSac}
                          onChange={e => updateRow(idx, { hsnSac: e.target.value })}
                          placeholder="998311"
                          className="w-full text-xs font-mono bg-transparent border-0 focus:ring-0 p-0 text-slate-600"
                        />
                      </td>
                      <td className="py-2 px-2 text-right">
                        <input
                          type="number"
                          min="1"
                          value={item.quantity}
                          onChange={e => updateRow(idx, { quantity: Number(e.target.value) })}
                          className="w-full text-xs font-mono text-right bg-transparent border-0 focus:ring-0 p-0"
                        />
                      </td>
                      <td className="py-2 px-2 text-right">
                        <input
                          type="number"
                          min="0"
                          step="100"
                          value={item.unitRate}
                          onChange={e => updateRow(idx, { unitRate: Number(e.target.value) })}
                          className="w-full text-xs font-mono text-right bg-transparent border-0 focus:ring-0 p-0 font-medium"
                        />
                      </td>
                      <td className="py-2 px-2 text-right">
                        <input
                          type="number"
                          min="0"
                          max="100"
                          value={item.discountPercent}
                          onChange={e => updateRow(idx, { discountPercent: Number(e.target.value) })}
                          className="w-full text-xs font-mono text-right bg-transparent border-0 focus:ring-0 p-0"
                        />
                      </td>
                      <td className="py-2 px-2">
                        <select
                          value={item.taxRateId}
                          onChange={e => updateRow(idx, { taxRateId: e.target.value })}
                          className="w-full text-[11px] bg-slate-50 border border-slate-200 rounded px-1.5 py-1 text-slate-700"
                        >
                          {taxRates.map(r => (
                            <option key={r.id} value={r.id}>
                              {r.name}
                            </option>
                          ))}
                        </select>
                      </td>
                      <td className="py-2 px-3 text-right font-mono font-bold text-slate-900 tabular-nums">
                        {formatMoney(item.totalAmount, currency)}
                      </td>
                      <td className="py-2 px-1 text-center">
                        <button
                          onClick={() => removeRow(idx)}
                          disabled={items.length <= 1}
                          className="text-slate-300 hover:text-rose-500 transition-colors p-1"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <button
              onClick={addRow}
              className="text-xs text-blue-600 hover:text-blue-700 font-semibold flex items-center gap-1 pt-1"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Another Line Item</span>
            </button>
          </div>

          {/* Grand Totals Summary Card */}
          <div className="flex flex-col md:flex-row justify-between items-start gap-6 pt-2">
            <div className="w-full md:w-1/2 space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Customer Notes</label>
                <textarea
                  rows={2}
                  value={notes}
                  onChange={e => setNotes(e.target.value)}
                  className="w-full text-xs bg-slate-50 border border-slate-200 rounded-lg p-2.5"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Terms & Conditions</label>
                <textarea
                  rows={2}
                  value={terms}
                  onChange={e => setTerms(e.target.value)}
                  className="w-full text-xs bg-slate-50 border border-slate-200 rounded-lg p-2.5"
                />
              </div>
            </div>

            <div className="w-full md:w-5/12 bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-2 text-xs">
              <div className="flex justify-between text-slate-600">
                <span>Subtotal</span>
                <span className="font-mono tabular-nums">{formatMoney(subtotal, currency)}</span>
              </div>

              {discountTotal > 0 && (
                <div className="flex justify-between text-emerald-600">
                  <span>Discount</span>
                  <span className="font-mono tabular-nums">-{formatMoney(discountTotal, currency)}</span>
                </div>
              )}

              <div className="flex justify-between text-slate-600">
                <span>Taxable Amount</span>
                <span className="font-mono font-medium tabular-nums">{formatMoney(taxableTotal, currency)}</span>
              </div>

              {isInterState ? (
                <div className="flex justify-between text-slate-700">
                  <span>Integrated GST (IGST 18%)</span>
                  <span className="font-mono tabular-nums">{formatMoney(igstTotal, currency)}</span>
                </div>
              ) : (
                <>
                  <div className="flex justify-between text-slate-700">
                    <span>Central GST (CGST 9%)</span>
                    <span className="font-mono tabular-nums">{formatMoney(cgstTotal, currency)}</span>
                  </div>
                  <div className="flex justify-between text-slate-700">
                    <span>State GST (SGST 9%)</span>
                    <span className="font-mono tabular-nums">{formatMoney(sgstTotal, currency)}</span>
                  </div>
                </>
              )}

              <div className="border-t border-slate-200 pt-2 flex justify-between font-bold text-sm text-slate-900">
                <span>Total ({currency})</span>
                <span className="font-mono tabular-nums">{formatMoney(grandTotal, currency)}</span>
              </div>

              {currency !== settings.baseCurrency && (
                <div className="text-[11px] text-slate-500 pt-1 flex justify-between font-mono">
                  <span>Base Equivalent ({settings.baseCurrency})</span>
                  <span>{formatMoney(baseCurrencyTotal, settings.baseCurrency)}</span>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-medium text-slate-700 hover:bg-slate-200/50 rounded-lg transition-colors"
          >
            Cancel
          </button>

          <div className="flex items-center gap-2">
            <button
              onClick={() => handleSubmit('draft')}
              className="px-4 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-300 hover:bg-slate-50 rounded-lg transition-colors"
            >
              Save as Draft
            </button>
            <button
              onClick={() => handleSubmit('sent')}
              className="px-5 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors shadow-xs"
            >
              Save & Send Invoice
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
