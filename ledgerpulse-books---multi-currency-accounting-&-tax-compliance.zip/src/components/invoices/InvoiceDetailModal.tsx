import React, { useState } from 'react';
import { useAccounting } from '../../context/AccountingContext';
import {
  X,
  Printer,
  Send,
  CreditCard,
  Building,
  CheckCircle2,
  Calendar,
  Clock,
  ShieldCheck,
  FileCheck
} from 'lucide-react';
import { Invoice } from '../../types';

interface InvoiceDetailModalProps {
  invoiceId: string | null;
  onClose: () => void;
  onRecordPayment: (invoiceId: string) => void;
}

export const InvoiceDetailModal: React.FC<InvoiceDetailModalProps> = ({
  invoiceId,
  onClose,
  onRecordPayment,
}) => {
  const { invoices, settings, formatMoney, sendPaymentReminder } = useAccounting();
  const [toastMsg, setToastMsg] = useState<string | null>(null);

  if (!invoiceId) return null;
  const invoice = invoices.find(i => i.id === invoiceId);
  if (!invoice) return null;

  const handlePrint = () => {
    window.print();
  };

  const handleSendReminder = () => {
    sendPaymentReminder(invoice.id, 'email');
    setToastMsg(`Payment reminder dispatched to ${invoice.customerName}`);
    setTimeout(() => setToastMsg(null), 3000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="bg-white w-full max-w-4xl rounded-2xl shadow-2xl border border-slate-200 overflow-hidden my-6 flex flex-col max-h-[90vh]">
        {/* Toast */}
        {toastMsg && (
          <div className="absolute top-4 right-4 z-50 bg-slate-900 text-white text-xs px-3.5 py-2 rounded-lg shadow-xl flex items-center gap-2 border border-slate-700">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <span>{toastMsg}</span>
          </div>
        )}

        {/* Modal Top Action Bar */}
        <div className="px-6 py-3.5 bg-slate-50 border-b border-slate-200 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-slate-800">{invoice.invoiceNumber}</span>
            <span className="text-slate-300">|</span>
            <span className="text-xs text-slate-500">{invoice.customerName}</span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="px-3 py-1.5 text-xs font-medium text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-lg transition-colors flex items-center gap-1.5"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print / PDF</span>
            </button>

            {invoice.balanceDue > 0 && invoice.status !== 'void' && (
              <>
                <button
                  onClick={handleSendReminder}
                  className="px-3 py-1.5 text-xs font-medium text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-lg transition-colors flex items-center gap-1.5"
                >
                  <Send className="w-3.5 h-3.5 text-blue-600" />
                  <span>Send Reminder</span>
                </button>

                <button
                  onClick={() => {
                    onRecordPayment(invoice.id);
                    onClose();
                  }}
                  className="px-3.5 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors shadow-xs flex items-center gap-1.5"
                >
                  <CreditCard className="w-3.5 h-3.5" />
                  <span>Record Payment</span>
                </button>
              </>
            )}

            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-200/50"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Invoice Printable Viewport */}
        <div className="p-8 overflow-y-auto space-y-6 text-slate-800" id="printable-invoice">
          {/* Header Block: Logo & Tax Invoice Title */}
          <div className="flex justify-between items-start border-b border-slate-200 pb-6">
            <div>
              <div className="text-xl font-bold tracking-tight text-blue-700 flex items-center gap-2">
                <div className="w-8 h-8 rounded bg-blue-700 text-white flex items-center justify-center font-bold text-sm">
                  LP
                </div>
                <span>{settings.businessName}</span>
              </div>
              <div className="text-xs text-slate-500 mt-1 space-y-0.5">
                <p>{settings.address}</p>
                <p>Email: {settings.email} | Phone: {settings.phone}</p>
                <p className="font-mono text-slate-700 font-medium">
                  GSTIN: {settings.gstin} | PAN: {settings.pan}
                </p>
              </div>
            </div>

            <div className="text-right">
              <h1 className="text-xl font-extrabold uppercase tracking-wider text-slate-900">
                TAX INVOICE
              </h1>
              <div className="mt-2 text-xs text-slate-600 space-y-1">
                <div>
                  <span className="text-slate-400">Invoice No:</span>{' '}
                  <span className="font-mono font-bold text-slate-900">{invoice.invoiceNumber}</span>
                </div>
                <div>
                  <span className="text-slate-400">Issue Date:</span>{' '}
                  <span className="font-medium">{invoice.issueDate}</span>
                </div>
                <div>
                  <span className="text-slate-400">Due Date:</span>{' '}
                  <span className="font-medium">{invoice.dueDate}</span>
                </div>
                <div>
                  <span className="text-slate-400">Place of Supply:</span>{' '}
                  <span className="font-medium">{invoice.placeOfSupply}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Bill To & Supply Details */}
          <div className="grid grid-cols-2 gap-6 bg-slate-50/50 p-4 rounded-xl border border-slate-200">
            <div>
              <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-1">
                Billed To (Customer Details)
              </div>
              <div className="text-sm font-bold text-slate-900">{invoice.customerName}</div>
              <div className="text-xs text-slate-600 font-mono mt-0.5">
                GSTIN / Tax ID: {invoice.customerTaxId || 'Unregistered'}
              </div>
              <div className="text-xs text-slate-500 mt-1">
                Place of Supply: {invoice.placeOfSupply}
              </div>
            </div>

            <div className="text-right flex flex-col justify-between">
              <div>
                <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-1">
                  Tax Treatment
                </div>
                <div className="text-xs font-semibold text-blue-700">
                  {invoice.isInterState ? 'Inter-State Supply (IGST)' : 'Intra-State Supply (CGST + SGST)'}
                </div>
              </div>

              <div>
                <span className="text-[11px] text-slate-400">Invoice Status:</span>{' '}
                <span className="font-semibold text-xs uppercase tracking-wide">
                  {invoice.status}
                </span>
              </div>
            </div>
          </div>

          {/* Line Items Table */}
          <div className="border border-slate-200 rounded-lg overflow-hidden">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-100 text-slate-700 font-semibold border-b border-slate-200">
                <tr>
                  <th className="py-2.5 px-3">#</th>
                  <th className="py-2.5 px-3">Item & Description</th>
                  <th className="py-2.5 px-3 text-center">HSN/SAC</th>
                  <th className="py-2.5 px-3 text-right">Qty</th>
                  <th className="py-2.5 px-3 text-right">Rate</th>
                  <th className="py-2.5 px-3 text-right">Discount</th>
                  <th className="py-2.5 px-3 text-right">Taxable</th>
                  <th className="py-2.5 px-3 text-right">Amount</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {invoice.items.map((item, index) => (
                  <tr key={item.id}>
                    <td className="py-3 px-3 text-slate-400">{index + 1}</td>
                    <td className="py-3 px-3">
                      <div className="font-medium text-slate-900">{item.description}</div>
                    </td>
                    <td className="py-3 px-3 text-center font-mono text-slate-600">{item.hsnSac || '—'}</td>
                    <td className="py-3 px-3 text-right font-mono tabular-nums">{item.quantity}</td>
                    <td className="py-3 px-3 text-right font-mono tabular-nums">{formatMoney(item.unitRate, invoice.currency)}</td>
                    <td className="py-3 px-3 text-right font-mono tabular-nums">{item.discountPercent}%</td>
                    <td className="py-3 px-3 text-right font-mono tabular-nums">{formatMoney(item.taxableAmount, invoice.currency)}</td>
                    <td className="py-3 px-3 text-right font-mono font-bold text-slate-900 tabular-nums">
                      {formatMoney(item.totalAmount, invoice.currency)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Tax Breakdown & Totals */}
          <div className="flex justify-between items-start gap-8 pt-2">
            {/* Bank details & Terms */}
            <div className="w-1/2 space-y-3 text-xs">
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                <div className="font-bold text-slate-800 mb-1 flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-emerald-600" />
                  <span>Bank Payment Remittance Details</span>
                </div>
                <div className="space-y-0.5 text-slate-600 font-mono text-[11px]">
                  <p>Bank: HDFC Bank Ltd</p>
                  <p>Account Name: {settings.legalEntityName}</p>
                  <p>Account No: 50200049281928</p>
                  <p>IFSC Code: HDFC0000060 (Bandra Kurla Complex)</p>
                  <p>SWIFT: HDFCINBBXXX</p>
                </div>
              </div>

              {invoice.notes && (
                <div className="text-slate-500 text-[11px]">
                  <span className="font-bold text-slate-700">Notes:</span> {invoice.notes}
                </div>
              )}
            </div>

            {/* Calculations Box */}
            <div className="w-5/12 space-y-2 text-xs">
              <div className="flex justify-between text-slate-600">
                <span>Subtotal</span>
                <span className="font-mono tabular-nums">{formatMoney(invoice.subtotal, invoice.currency)}</span>
              </div>

              {invoice.discountTotal > 0 && (
                <div className="flex justify-between text-emerald-600">
                  <span>Discount</span>
                  <span className="font-mono tabular-nums">-{formatMoney(invoice.discountTotal, invoice.currency)}</span>
                </div>
              )}

              {invoice.isInterState ? (
                <div className="flex justify-between text-slate-700">
                  <span>IGST (18%)</span>
                  <span className="font-mono tabular-nums">{formatMoney(invoice.igstTotal, invoice.currency)}</span>
                </div>
              ) : (
                <>
                  <div className="flex justify-between text-slate-700">
                    <span>CGST (9%)</span>
                    <span className="font-mono tabular-nums">{formatMoney(invoice.cgstTotal, invoice.currency)}</span>
                  </div>
                  <div className="flex justify-between text-slate-700">
                    <span>SGST (9%)</span>
                    <span className="font-mono tabular-nums">{formatMoney(invoice.sgstTotal, invoice.currency)}</span>
                  </div>
                </>
              )}

              <div className="border-t border-slate-200 pt-2 flex justify-between font-bold text-sm text-slate-900">
                <span>Total Amount</span>
                <span className="font-mono tabular-nums">{formatMoney(invoice.totalAmount, invoice.currency)}</span>
              </div>

              {invoice.paidAmount > 0 && (
                <div className="flex justify-between text-emerald-600 font-medium">
                  <span>Payments Received</span>
                  <span className="font-mono tabular-nums">-{formatMoney(invoice.paidAmount, invoice.currency)}</span>
                </div>
              )}

              {invoice.tdsDeductedByCustomer > 0 && (
                <div className="flex justify-between text-blue-600 font-medium">
                  <span>TDS Withheld by Client</span>
                  <span className="font-mono tabular-nums">-{formatMoney(invoice.tdsDeductedByCustomer, invoice.currency)}</span>
                </div>
              )}

              <div className="border-t-2 border-slate-900 pt-2 flex justify-between font-extrabold text-sm text-slate-900">
                <span>Balance Due</span>
                <span className="font-mono tabular-nums">{formatMoney(invoice.balanceDue, invoice.currency)}</span>
              </div>
            </div>
          </div>

          {/* Reminder History Log */}
          {invoice.remindersSent && invoice.remindersSent.length > 0 && (
            <div className="border-t border-slate-200 pt-4 mt-6">
              <h3 className="text-xs font-bold text-slate-700 mb-2 flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-blue-600" />
                <span>Automated Payment Reminder Log</span>
              </h3>
              <div className="space-y-1.5 text-[11px] text-slate-600">
                {invoice.remindersSent.map(r => (
                  <div key={r.id} className="p-2 bg-slate-50 rounded border border-slate-200 flex justify-between items-center">
                    <div>
                      <span className="font-semibold text-slate-800 uppercase">{r.channel}:</span> {r.message}
                    </div>
                    <span className="font-mono text-slate-400">{r.date}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
