import React, { useState } from 'react';
import { useAccounting } from '../../context/AccountingContext';
import { X, CheckCircle2, ShieldCheck, Calculator } from 'lucide-react';

interface RecordPaymentModalProps {
  isOpen: boolean;
  invoiceId: string | null;
  onClose: () => void;
}

export const RecordPaymentModal: React.FC<RecordPaymentModalProps> = ({
  isOpen,
  invoiceId,
  onClose,
}) => {
  const {
    invoices,
    bankAccounts,
    formatMoney,
    recordInvoicePayment,
    tdsRates
  } = useAccounting();

  if (!isOpen || !invoiceId) return null;
  const invoice = invoices.find(i => i.id === invoiceId);
  if (!invoice) return null;

  const [hasTdsDeduction, setHasTdsDeduction] = useState(false);
  const [selectedTdsSection, setSelectedTdsSection] = useState('194J_TECH'); // 2%
  const [tdsPercent, setTdsPercent] = useState(2);
  
  // Calculate default values
  const defaultTdsAmount = Math.round(invoice.subtotal * (tdsPercent / 100));
  const [tdsAmount, setTdsAmount] = useState<number>(0);
  const [netReceivedAmount, setNetReceivedAmount] = useState<number>(invoice.balanceDue);
  const [selectedBankId, setSelectedBankId] = useState<string>(bankAccounts[0]?.id || '');
  const [notes, setNotes] = useState('');

  const handleTdsToggle = (enabled: boolean) => {
    setHasTdsDeduction(enabled);
    if (enabled) {
      const calcTds = Math.round(invoice.subtotal * (tdsPercent / 100));
      setTdsAmount(calcTds);
      setNetReceivedAmount(Math.max(0, invoice.balanceDue - calcTds));
    } else {
      setTdsAmount(0);
      setNetReceivedAmount(invoice.balanceDue);
    }
  };

  const handleTdsSectionChange = (section: string) => {
    setSelectedTdsSection(section);
    const rateObj = tdsRates.find(r => r.section === section);
    const pct = rateObj ? rateObj.rate : 2;
    setTdsPercent(pct);
    const calcTds = Math.round(invoice.subtotal * (pct / 100));
    setTdsAmount(calcTds);
    setNetReceivedAmount(Math.max(0, invoice.balanceDue - calcTds));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    recordInvoicePayment(
      invoice.id,
      netReceivedAmount,
      hasTdsDeduction ? tdsAmount : 0,
      selectedBankId,
      notes
    );
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="bg-white w-full max-w-lg rounded-2xl shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95">
        <div className="px-6 py-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
          <div>
            <h2 className="text-sm font-bold text-slate-900">Record Customer Payment</h2>
            <p className="text-xs text-slate-500">{invoice.invoiceNumber} · {invoice.customerName}</p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-200/50 rounded-lg"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs">
          {/* Invoice Balance Summary */}
          <div className="p-3 bg-blue-50/50 border border-blue-200 rounded-lg flex items-center justify-between">
            <div>
              <div className="text-[11px] text-slate-500">Outstanding Balance Due</div>
              <div className="text-base font-bold font-mono text-blue-700 tabular-nums">
                {formatMoney(invoice.balanceDue, invoice.currency)}
              </div>
            </div>
            <div className="text-right text-[11px] text-slate-500">
              <div>Invoice Total: {formatMoney(invoice.totalAmount, invoice.currency)}</div>
              <div>Already Settled: {formatMoney(invoice.paidAmount, invoice.currency)}</div>
            </div>
          </div>

          {/* Deposit Bank Account */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Deposit To Bank Account <span className="text-rose-500">*</span>
            </label>
            <select
              value={selectedBankId}
              onChange={e => setSelectedBankId(e.target.value)}
              className="w-full text-xs bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 font-medium"
            >
              {bankAccounts.map(b => (
                <option key={b.id} value={b.id}>
                  {b.bankName} - {b.name} ({formatMoney(b.balance, b.currency)})
                </option>
              ))}
            </select>
          </div>

          {/* Regional TDS Deduction Option */}
          <div className="p-3.5 bg-slate-50 rounded-lg border border-slate-200 space-y-3">
            <div className="flex items-center justify-between">
              <label className="flex items-center gap-2 cursor-pointer font-semibold text-slate-800">
                <input
                  type="checkbox"
                  checked={hasTdsDeduction}
                  onChange={e => handleTdsToggle(e.target.checked)}
                  className="rounded text-blue-600 focus:ring-blue-500 w-4 h-4"
                />
                <span>Customer deducted TDS on this payment</span>
              </label>
              <span className="text-[10px] text-blue-600 font-mono">Sec 194C / 194J</span>
            </div>

            {hasTdsDeduction && (
              <div className="space-y-3 pt-2 border-t border-slate-200">
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block text-[11px] font-medium text-slate-600 mb-1">
                      TDS Section Code
                    </label>
                    <select
                      value={selectedTdsSection}
                      onChange={e => handleTdsSectionChange(e.target.value)}
                      className="w-full text-xs bg-white border border-slate-200 rounded px-2 py-1.5"
                    >
                      {tdsRates.map(r => (
                        <option key={r.section} value={r.section}>
                          {r.code} ({r.rate}%)
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-[11px] font-medium text-slate-600 mb-1">
                      TDS Deducted Amount
                    </label>
                    <input
                      type="number"
                      value={tdsAmount}
                      onChange={e => {
                        const val = Number(e.target.value);
                        setTdsAmount(val);
                        setNetReceivedAmount(Math.max(0, invoice.balanceDue - val));
                      }}
                      className="w-full text-xs font-mono font-bold bg-white border border-slate-200 rounded px-2 py-1.5"
                    />
                  </div>
                </div>

                <div className="text-[11px] text-slate-500 bg-white p-2 rounded border border-slate-200 flex items-start gap-1.5">
                  <ShieldCheck className="w-3.5 h-3.5 text-blue-600 shrink-0 mt-0.5" />
                  <span>
                    Credited to <strong>TDS Receivable (Account 1200)</strong> to claim against corporate income tax filing via Form 26AS.
                  </span>
                </div>
              </div>
            )}
          </div>

          {/* Net Amount Deposited */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Net Amount Received in Bank ({invoice.currency}) <span className="text-rose-500">*</span>
            </label>
            <input
              type="number"
              step="any"
              value={netReceivedAmount}
              onChange={e => setNetReceivedAmount(Number(e.target.value))}
              className="w-full text-sm font-mono font-bold bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-slate-900"
              required
            />
          </div>

          {/* Notes & Reference */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Payment Reference / Notes
            </label>
            <input
              type="text"
              value={notes}
              onChange={e => setNotes(e.target.value)}
              placeholder="e.g. NEFT Reference, Cheque No, Client UTR..."
              className="w-full text-xs bg-slate-50 border border-slate-200 rounded-lg px-3 py-2"
            />
          </div>

          <div className="pt-2 flex items-center justify-end gap-2 border-t border-slate-200">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-slate-600 hover:bg-slate-100 rounded-lg"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs"
            >
              Confirm Settlement
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
