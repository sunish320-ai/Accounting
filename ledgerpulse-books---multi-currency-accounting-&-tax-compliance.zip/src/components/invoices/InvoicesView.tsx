import React, { useState, useMemo } from 'react';
import { useAccounting } from '../../context/AccountingContext';
import {
  Plus,
  Search,
  Filter,
  FileText,
  CreditCard,
  Send,
  MoreVertical,
  Download,
  AlertCircle,
  CheckCircle2,
  Clock,
  Printer,
  Edit2,
  Copy,
  Trash2,
  AlertTriangle
} from 'lucide-react';
import { InvoiceStatus, Invoice } from '../../types';

interface InvoicesViewProps {
  onOpenCreateModal: () => void;
  onViewInvoice: (invoiceId: string) => void;
  onRecordPayment: (invoiceId: string) => void;
  onEditInvoice?: (invoice: Invoice) => void;
}

export const InvoicesView: React.FC<InvoicesViewProps> = ({
  onOpenCreateModal,
  onViewInvoice,
  onRecordPayment,
  onEditInvoice,
}) => {
  const {
    invoices,
    formatMoney,
    convertAmount,
    settings,
    selectedDisplayCurrency,
    sendPaymentReminder,
    voidInvoice,
    deleteInvoice,
    duplicateInvoice
  } = useAccounting();

  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);

  const handleDuplicate = (id: string, num: string) => {
    duplicateInvoice(id);
    setToastMessage(`Invoice ${num} duplicated as draft.`);
    setTimeout(() => setToastMessage(null), 3000);
  };

  const handleDelete = (id: string, num: string) => {
    deleteInvoice(id);
    setDeleteConfirmId(null);
    setToastMessage(`Invoice ${num} deleted.`);
    setTimeout(() => setToastMessage(null), 3000);
  };

  const filteredInvoices = useMemo(() => {
    return invoices.filter(inv => {
      const matchesSearch =
        inv.invoiceNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
        inv.customerName.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesStatus = statusFilter === 'all' || inv.status === statusFilter;
      return matchesSearch && matchesStatus;
    });
  }, [invoices, searchTerm, statusFilter]);

  const totalReceivables = useMemo(() => {
    return invoices
      .filter(i => i.status !== 'void' && i.balanceDue > 0)
      .reduce((sum, i) => sum + (i.balanceDue * i.exchangeRate), 0);
  }, [invoices]);

  const totalOverdue = useMemo(() => {
    return invoices
      .filter(i => i.status === 'overdue' && i.balanceDue > 0)
      .reduce((sum, i) => sum + (i.balanceDue * i.exchangeRate), 0);
  }, [invoices]);

  const totalPaid = useMemo(() => {
    return invoices
      .filter(i => i.status !== 'void')
      .reduce((sum, i) => sum + (i.paidAmount * i.exchangeRate), 0);
  }, [invoices]);

  const getStatusBadge = (status: InvoiceStatus) => {
    switch (status) {
      case 'paid':
        return <span className="text-[11px] font-semibold text-emerald-700 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded">Paid</span>;
      case 'partially_paid':
        return <span className="text-[11px] font-semibold text-blue-700 bg-blue-50 border border-blue-200 px-2 py-0.5 rounded">Partially Paid</span>;
      case 'overdue':
        return <span className="text-[11px] font-semibold text-rose-700 bg-rose-50 border border-rose-200 px-2 py-0.5 rounded">Overdue</span>;
      case 'sent':
        return <span className="text-[11px] font-semibold text-slate-700 bg-slate-100 border border-slate-200 px-2 py-0.5 rounded">Sent</span>;
      case 'draft':
        return <span className="text-[11px] font-semibold text-amber-700 bg-amber-50 border border-amber-200 px-2 py-0.5 rounded">Draft</span>;
      case 'void':
        return <span className="text-[11px] font-semibold text-slate-400 bg-slate-100 line-through px-2 py-0.5 rounded">Void</span>;
    }
  };

  const handleSendReminder = (inv: Invoice) => {
    sendPaymentReminder(inv.id, 'email');
    setToastMessage(`Automated payment reminder dispatched for ${inv.invoiceNumber} to ${inv.customerName}`);
    setTimeout(() => setToastMessage(null), 3000);
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-5 right-5 z-50 bg-slate-900 text-white text-xs px-4 py-2.5 rounded-lg shadow-xl flex items-center gap-2 border border-slate-700 animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Top Header Summary Strip */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
          <div className="text-xs text-slate-500 font-medium">Total Outstanding Receivables</div>
          <div className="text-xl font-bold font-mono tracking-tight text-slate-900 mt-1 tabular-nums">
            {formatMoney(
              convertAmount(totalReceivables, settings.baseCurrency, selectedDisplayCurrency),
              selectedDisplayCurrency
            )}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">Across all open client invoices</div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
          <div className="text-xs text-amber-600 font-medium">Overdue Amount</div>
          <div className="text-xl font-bold font-mono tracking-tight text-rose-600 mt-1 tabular-nums">
            {formatMoney(
              convertAmount(totalOverdue, settings.baseCurrency, selectedDisplayCurrency),
              selectedDisplayCurrency
            )}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">Past stipulated payment due dates</div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
          <div className="text-xs text-slate-500 font-medium">Collections Received (YTD)</div>
          <div className="text-xl font-bold font-mono tracking-tight text-emerald-600 mt-1 tabular-nums">
            {formatMoney(
              convertAmount(totalPaid, settings.baseCurrency, selectedDisplayCurrency),
              selectedDisplayCurrency
            )}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">Settled into bank accounts</div>
        </div>
      </div>

      {/* Toolbar & Filters */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-2xs p-4">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
          {/* Search Box */}
          <div className="relative w-full sm:w-80">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Search by invoice number or customer..."
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-500"
            />
          </div>

          {/* Status Filters & Action Button */}
          <div className="flex items-center gap-2 w-full sm:w-auto justify-between sm:justify-end">
            <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg text-xs font-medium">
              {[
                { id: 'all', label: 'All' },
                { id: 'sent', label: 'Sent' },
                { id: 'overdue', label: 'Overdue' },
                { id: 'partially_paid', label: 'Partial' },
                { id: 'paid', label: 'Paid' },
              ].map(tab => (
                <button
                  key={tab.id}
                  onClick={() => setStatusFilter(tab.id)}
                  className={`px-2.5 py-1 rounded-md transition-colors ${
                    statusFilter === tab.id
                      ? 'bg-white text-slate-900 shadow-xs font-semibold'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            <button
              onClick={onOpenCreateModal}
              className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 active:bg-blue-800 rounded-md shadow-xs transition-colors shrink-0"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>New Invoice</span>
            </button>
          </div>
        </div>

        {/* Invoices Data Grid */}
        <div className="mt-4 overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-600 border-collapse">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-50/75 text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
                <th className="py-2.5 px-3">Date</th>
                <th className="py-2.5 px-3">Invoice #</th>
                <th className="py-2.5 px-3">Customer Name</th>
                <th className="py-2.5 px-3">Due Date</th>
                <th className="py-2.5 px-3">Status</th>
                <th className="py-2.5 px-3 text-right">Invoice Amount</th>
                <th className="py-2.5 px-3 text-right">Balance Due</th>
                <th className="py-2.5 px-3 text-center">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredInvoices.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-10 text-center text-slate-400">
                    No invoices found matching your criteria.
                  </td>
                </tr>
              ) : (
                filteredInvoices.map(inv => (
                  <tr
                    key={inv.id}
                    className="hover:bg-slate-50/80 transition-colors group cursor-pointer"
                    onClick={() => onViewInvoice(inv.id)}
                  >
                    <td className="py-3 px-3 text-slate-500 whitespace-nowrap">
                      {inv.issueDate}
                    </td>
                    <td className="py-3 px-3 font-semibold text-blue-600 whitespace-nowrap">
                      {inv.invoiceNumber}
                    </td>
                    <td className="py-3 px-3 font-medium text-slate-800 max-w-[200px] truncate">
                      {inv.customerName}
                    </td>
                    <td className="py-3 px-3 text-slate-500 whitespace-nowrap">
                      {inv.dueDate}
                    </td>
                    <td className="py-3 px-3 whitespace-nowrap">
                      {getStatusBadge(inv.status)}
                    </td>
                    <td className="py-3 px-3 text-right font-mono font-medium text-slate-800 whitespace-nowrap tabular-nums">
                      {formatMoney(inv.totalAmount, inv.currency)}
                      {inv.currency !== settings.baseCurrency && (
                        <div className="text-[10px] text-slate-400 font-normal">
                          ({formatMoney(inv.baseCurrencyTotal, settings.baseCurrency)})
                        </div>
                      )}
                    </td>
                    <td className="py-3 px-3 text-right font-mono font-bold text-slate-900 whitespace-nowrap tabular-nums">
                      {inv.balanceDue > 0 ? (
                        <span className={inv.status === 'overdue' ? 'text-rose-600' : 'text-slate-900'}>
                          {formatMoney(inv.balanceDue, inv.currency)}
                        </span>
                      ) : (
                        <span className="text-emerald-600 font-medium">Settled</span>
                      )}
                    </td>
                    <td
                      className="py-3 px-3 text-center whitespace-nowrap"
                      onClick={e => e.stopPropagation()}
                    >
                      <div className="flex items-center justify-center gap-1">
                        <button
                          onClick={() => onViewInvoice(inv.id)}
                          className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded transition-colors"
                          title="View / Print Tax Invoice"
                        >
                          <Printer className="w-3.5 h-3.5" />
                        </button>

                        {onEditInvoice && (
                          <button
                            onClick={() => onEditInvoice(inv)}
                            className="p-1.5 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded transition-colors"
                            title="Edit Invoice"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                        )}

                        <button
                          onClick={() => handleDuplicate(inv.id, inv.invoiceNumber)}
                          className="p-1.5 text-slate-400 hover:text-emerald-600 hover:bg-emerald-50 rounded transition-colors"
                          title="Duplicate Invoice"
                        >
                          <Copy className="w-3.5 h-3.5" />
                        </button>

                        <button
                          onClick={() => setDeleteConfirmId(inv.id)}
                          className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded transition-colors"
                          title="Delete Invoice"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>

                        {inv.balanceDue > 0 && inv.status !== 'void' && (
                          <>
                            <button
                              onClick={() => onRecordPayment(inv.id)}
                              className="px-2 py-1 text-[11px] font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded transition-colors shadow-2xs ml-1"
                              title="Record Customer Payment & TDS deduction"
                            >
                              Payment
                            </button>

                            <button
                              onClick={() => handleSendReminder(inv)}
                              className="p-1.5 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded transition-colors"
                              title="Send Payment Reminder (Email/WhatsApp)"
                            >
                              <Send className="w-3.5 h-3.5" />
                            </button>
                          </>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Delete Confirmation Modal */}
      {deleteConfirmId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-xs p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-sm w-full p-6 text-center border border-slate-200">
            <div className="w-12 h-12 rounded-full bg-rose-50 text-rose-600 mx-auto flex items-center justify-center mb-4">
              <AlertTriangle className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-slate-900 mb-2">Delete Invoice?</h3>
            <p className="text-sm text-slate-600 mb-6">
              Are you sure you want to delete this invoice? This will remove its accounting records permanently.
            </p>
            <div className="flex gap-3 justify-center">
              <button
                onClick={() => setDeleteConfirmId(null)}
                className="px-4 py-2 border border-slate-300 rounded-lg text-sm font-medium text-slate-700 hover:bg-slate-50 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  const inv = invoices.find(i => i.id === deleteConfirmId);
                  handleDelete(deleteConfirmId, inv?.invoiceNumber || '');
                }}
                className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-lg text-sm font-medium transition-colors"
              >
                Delete Invoice
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

