import React, { useState, useMemo } from 'react';
import { useAccounting } from '../../context/AccountingContext';
import {
  ShieldCheck,
  FileText,
  Download,
  Printer,
  Globe,
  Building,
  CheckCircle2,
  Calendar,
  Layers,
  ArrowRight
} from 'lucide-react';
import { TaxJurisdiction } from '../../types';

export const TaxComplianceView: React.FC = () => {
  const {
    settings,
    setJurisdiction,
    invoices,
    bills,
    formatMoney,
    convertAmount
  } = useAccounting();

  const [activeReportTab, setActiveReportTab] = useState<'gstr1' | 'gstr3b' | 'tds' | 'international'>('gstr1');
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Compute India GST Aggregates
  const gstData = useMemo(() => {
    let b2bTaxable = 0;
    let b2cTaxable = 0;
    let exportTaxable = 0;
    let totalCgst = 0;
    let totalSgst = 0;
    let totalIgst = 0;

    const hsnSummary: { [hsn: string]: { description: string; qty: number; taxable: number; cgst: number; sgst: number; igst: number; total: number } } = {};

    invoices.forEach(inv => {
      if (inv.status === 'void') return;

      const isExport = inv.placeOfSupply.includes('Overseas') || inv.items.some(it => it.taxRateId === 'tax-gst-0');
      const isB2b = inv.customerTaxId && inv.customerTaxId.length > 5 && !isExport;

      if (isExport) exportTaxable += inv.subtotal * inv.exchangeRate;
      else if (isB2b) b2bTaxable += inv.subtotal * inv.exchangeRate;
      else b2cTaxable += inv.subtotal * inv.exchangeRate;

      totalCgst += inv.cgstTotal * inv.exchangeRate;
      totalSgst += inv.sgstTotal * inv.exchangeRate;
      totalIgst += inv.igstTotal * inv.exchangeRate;

      // Group by HSN/SAC
      inv.items.forEach(item => {
        const code = item.hsnSac || '998311';
        if (!hsnSummary[code]) {
          hsnSummary[code] = {
            description: item.description,
            qty: 0,
            taxable: 0,
            cgst: 0,
            sgst: 0,
            igst: 0,
            total: 0
          };
        }
        hsnSummary[code].qty += item.quantity || 1;
        hsnSummary[code].taxable += item.taxableAmount * inv.exchangeRate;
        hsnSummary[code].cgst += item.cgstAmount * inv.exchangeRate;
        hsnSummary[code].sgst += item.sgstAmount * inv.exchangeRate;
        hsnSummary[code].igst += item.igstAmount * inv.exchangeRate;
        hsnSummary[code].total += item.totalAmount * inv.exchangeRate;
      });
    });

    // Input Tax Credit (ITC) from Vendor Bills
    let eligibleItcCgst = 0;
    let eligibleItcSgst = 0;
    let eligibleItcIgst = 0;

    bills.forEach(bill => {
      // Split bill GST into ITC
      eligibleItcCgst += (bill.taxAmount / 2) * bill.exchangeRate;
      eligibleItcSgst += (bill.taxAmount / 2) * bill.exchangeRate;
    });

    const totalOutputTax = totalCgst + totalSgst + totalIgst;
    const totalItc = eligibleItcCgst + eligibleItcSgst + eligibleItcIgst;
    const netGstPayable = Math.max(0, totalOutputTax - totalItc);

    return {
      b2bTaxable,
      b2cTaxable,
      exportTaxable,
      totalTaxable: b2bTaxable + b2cTaxable + exportTaxable,
      totalCgst,
      totalSgst,
      totalIgst,
      totalOutputTax,
      eligibleItc: totalItc,
      netGstPayable,
      hsnSummary
    };
  }, [invoices, bills]);

  // Compute TDS Deduction Register
  const tdsRegister = useMemo(() => {
    const list = bills
      .filter(b => b.tdsAmount > 0)
      .map(b => ({
        billNumber: b.billNumber,
        vendorName: b.vendorName,
        vendorPan: b.vendorPan,
        section: b.tdsSection,
        ratePct: b.tdsRatePercent,
        grossAmount: b.subtotal * b.exchangeRate,
        tdsWithheld: b.tdsAmount * b.exchangeRate,
        netPaid: b.netPayable * b.exchangeRate,
        depositDueDate: '07 Nov 2026'
      }));

    const totalWithheld = list.reduce((sum, item) => sum + item.tdsWithheld, 0);
    return { list, totalWithheld };
  }, [bills]);

  // Export JSON for Government Portal
  const handleExportJson = () => {
    const reportPayload = {
      gstin: settings.gstin,
      legalName: settings.legalEntityName,
      fiscalYear: '2026-2027',
      month: '10-2026',
      gstr1: {
        b2b: gstData.b2bTaxable,
        b2c: gstData.b2cTaxable,
        exports: gstData.exportTaxable,
        totalTaxLiability: gstData.totalOutputTax,
        hsn: gstData.hsnSummary
      },
      tdsSummary: {
        totalTaxDeducted: tdsRegister.totalWithheld,
        records: tdsRegister.list
      }
    };

    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(reportPayload, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `Tax_Report_${settings.gstin}_Oct2026.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();

    setToastMessage('Generated official Tax Filing JSON payload for filing portal.');
    setTimeout(() => setToastMessage(null), 3000);
  };

  const handleExportCsv = () => {
    let csvContent = 'data:text/csv;charset=utf-8,';
    csvContent += 'Section,Vendor Name,PAN,Gross Amount (INR),TDS Rate (%),TDS Deducted (INR),Deposit Due Date\n';

    tdsRegister.list.forEach(r => {
      csvContent += `${r.section},"${r.vendorName}",${r.vendorPan},${r.grossAmount},${r.ratePct},${r.tdsWithheld},${r.depositDueDate}\n`;
    });

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `TDS_Form26Q_Register_Oct2026.csv`);
    document.body.appendChild(link);
    link.click();
    link.remove();

    setToastMessage('Downloaded Form 26Q TDS deduction register CSV.');
    setTimeout(() => setToastMessage(null), 3000);
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      {/* Toast */}
      {toastMessage && (
        <div className="fixed bottom-5 right-5 z-50 bg-slate-900 text-white text-xs px-4 py-2.5 rounded-lg shadow-xl flex items-center gap-2 border border-slate-700 animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Top Banner */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-2xs p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-base font-bold text-slate-900 flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-blue-600" />
            <span>Automated Tax Compliance & Regional Filings</span>
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Automatic GSTR-1, GSTR-3B reconciliation, Form 26Q TDS deductions, and international VAT returns
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExportCsv}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 bg-white hover:bg-slate-50 border border-slate-200 rounded-lg shadow-2xs transition-colors"
          >
            <Download className="w-3.5 h-3.5 text-slate-500" />
            <span>Download CSV</span>
          </button>

          <button
            onClick={handleExportJson}
            className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs transition-colors"
          >
            <FileText className="w-3.5 h-3.5" />
            <span>Export Portal JSON</span>
          </button>
        </div>
      </div>

      {/* Tax Report Selection Tabs */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-2xs p-4">
        <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg text-xs font-medium w-full sm:w-auto">
          <button
            onClick={() => setActiveReportTab('gstr1')}
            className={`px-3 py-1.5 rounded-md transition-colors ${
              activeReportTab === 'gstr1'
                ? 'bg-white text-slate-900 shadow-xs font-semibold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            GSTR-1 Outward Supplies
          </button>
          <button
            onClick={() => setActiveReportTab('gstr3b')}
            className={`px-3 py-1.5 rounded-md transition-colors ${
              activeReportTab === 'gstr3b'
                ? 'bg-white text-slate-900 shadow-xs font-semibold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            GSTR-3B Net Tax Summary
          </button>
          <button
            onClick={() => setActiveReportTab('tds')}
            className={`px-3 py-1.5 rounded-md transition-colors ${
              activeReportTab === 'tds'
                ? 'bg-white text-blue-700 shadow-xs font-semibold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            TDS Deduction Register (26Q)
          </button>
          <button
            onClick={() => setActiveReportTab('international')}
            className={`px-3 py-1.5 rounded-md transition-colors ${
              activeReportTab === 'international'
                ? 'bg-white text-slate-900 shadow-xs font-semibold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            US Sales Tax & UK/EU VAT
          </button>
        </div>

        {/* Tab 1: GSTR-1 View */}
        {activeReportTab === 'gstr1' && (
          <div className="mt-5 space-y-5">
            {/* Summary Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
              <div className="p-3.5 bg-slate-50 rounded-lg border border-slate-200">
                <div className="text-[11px] text-slate-500 font-medium">B2B Registered Supplies</div>
                <div className="text-base font-bold font-mono text-slate-900 mt-1 tabular-nums">
                  {formatMoney(gstData.b2bTaxable, 'INR')}
                </div>
                <div className="text-[10px] text-slate-400 mt-0.5">Table 4 Invoice details</div>
              </div>

              <div className="p-3.5 bg-slate-50 rounded-lg border border-slate-200">
                <div className="text-[11px] text-slate-500 font-medium">Exports under LUT / Zero-Rated</div>
                <div className="text-base font-bold font-mono text-blue-700 mt-1 tabular-nums">
                  {formatMoney(gstData.exportTaxable, 'INR')}
                </div>
                <div className="text-[10px] text-slate-400 mt-0.5">Table 6 Zero-rated software</div>
              </div>

              <div className="p-3.5 bg-slate-50 rounded-lg border border-slate-200">
                <div className="text-[11px] text-slate-500 font-medium">Total Taxable Turnover</div>
                <div className="text-base font-bold font-mono text-slate-900 mt-1 tabular-nums">
                  {formatMoney(gstData.totalTaxable, 'INR')}
                </div>
                <div className="text-[10px] text-slate-400 mt-0.5">Aggregate gross supplies</div>
              </div>

              <div className="p-3.5 bg-blue-50/60 rounded-lg border border-blue-200">
                <div className="text-[11px] text-blue-800 font-medium">Total Output Tax Liability</div>
                <div className="text-base font-bold font-mono text-blue-800 mt-1 tabular-nums">
                  {formatMoney(gstData.totalOutputTax, 'INR')}
                </div>
                <div className="text-[10px] text-blue-600 mt-0.5">CGST + SGST + IGST</div>
              </div>
            </div>

            {/* HSN/SAC Summary Table (Mandatory for Indian GST) */}
            <div className="space-y-2">
              <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                Table 12: HSN/SAC Summary of Outward Supplies
              </h3>
              <div className="border border-slate-200 rounded-lg overflow-x-auto">
                <table className="w-full text-left text-xs text-slate-600">
                  <thead className="bg-slate-100 text-slate-700 font-semibold border-b border-slate-200">
                    <tr>
                      <th className="py-2.5 px-3">HSN/SAC</th>
                      <th className="py-2.5 px-3">Description</th>
                      <th className="py-2.5 px-3 text-right">Qty</th>
                      <th className="py-2.5 px-3 text-right">Taxable Value</th>
                      <th className="py-2.5 px-3 text-right">CGST</th>
                      <th className="py-2.5 px-3 text-right">SGST</th>
                      <th className="py-2.5 px-3 text-right">IGST</th>
                      <th className="py-2.5 px-3 text-right">Total Amount</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {Object.entries(gstData.hsnSummary).map(([hsn, val]) => (
                      <tr key={hsn} className="hover:bg-slate-50/60">
                        <td className="py-2.5 px-3 font-mono font-bold text-blue-700">{hsn}</td>
                        <td className="py-2.5 px-3 font-medium text-slate-800">{val.description}</td>
                        <td className="py-2.5 px-3 text-right font-mono tabular-nums">{val.qty}</td>
                        <td className="py-2.5 px-3 text-right font-mono tabular-nums">{formatMoney(val.taxable, 'INR')}</td>
                        <td className="py-2.5 px-3 text-right font-mono tabular-nums">{formatMoney(val.cgst, 'INR')}</td>
                        <td className="py-2.5 px-3 text-right font-mono tabular-nums">{formatMoney(val.sgst, 'INR')}</td>
                        <td className="py-2.5 px-3 text-right font-mono tabular-nums">{formatMoney(val.igst, 'INR')}</td>
                        <td className="py-2.5 px-3 text-right font-mono font-bold text-slate-900 tabular-nums">{formatMoney(val.total, 'INR')}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* Tab 2: GSTR-3B View */}
        {activeReportTab === 'gstr3b' && (
          <div className="mt-5 space-y-5">
            <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-3">
              <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                Monthly Return Computation (GSTR-3B Reconciliation)
              </h3>
              
              <div className="space-y-2 text-xs">
                <div className="flex justify-between py-2 border-b border-slate-200">
                  <span className="text-slate-700 font-medium">3.1 Outward Taxable Supplies (Tax Collected from Clients)</span>
                  <span className="font-mono font-bold text-slate-900 tabular-nums">
                    {formatMoney(gstData.totalOutputTax, 'INR')}
                  </span>
                </div>

                <div className="flex justify-between py-2 border-b border-slate-200 text-emerald-700">
                  <span className="font-medium">4. Eligible Input Tax Credit (ITC Paid on Vendor Purchases & Services)</span>
                  <span className="font-mono font-bold tabular-nums">
                    -{formatMoney(gstData.eligibleItc, 'INR')}
                  </span>
                </div>

                <div className="flex justify-between py-3 border-t-2 border-slate-800 font-extrabold text-sm text-slate-900">
                  <span>5. Net GST Payable in Cash (Electronic Cash Ledger)</span>
                  <span className="font-mono tabular-nums">
                    {formatMoney(gstData.netGstPayable, 'INR')}
                  </span>
                </div>
              </div>
            </div>

            <div className="p-3 bg-blue-50/60 rounded-lg border border-blue-200 text-xs text-blue-900 flex items-center justify-between">
              <span>Filing Deadline for Current Tax Period: <strong>20th November 2026</strong></span>
              <span className="font-mono font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                ITC Reconciled with GSTR-2B
              </span>
            </div>
          </div>
        )}

        {/* Tab 3: TDS Deduction Register (26Q) */}
        {activeReportTab === 'tds' && (
          <div className="mt-5 space-y-5">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                  TDS Withholding Register under Income Tax Act (Form 26Q)
                </h3>
                <p className="text-[11px] text-slate-500">
                  Tax deducted at source from vendors, contractors, and landlords to be paid via Challan 281
                </p>
              </div>
              <div className="text-right">
                <span className="text-[11px] text-slate-400">Total TDS Withheld:</span>{' '}
                <span className="font-mono font-bold text-blue-700 text-sm">
                  {formatMoney(tdsRegister.totalWithheld, 'INR')}
                </span>
              </div>
            </div>

            <div className="border border-slate-200 rounded-lg overflow-x-auto">
              <table className="w-full text-left text-xs text-slate-600">
                <thead className="bg-slate-100 text-slate-700 font-semibold border-b border-slate-200">
                  <tr>
                    <th className="py-2.5 px-3">TDS Section</th>
                    <th className="py-2.5 px-3">Vendor / Deductee</th>
                    <th className="py-2.5 px-3">PAN</th>
                    <th className="py-2.5 px-3 text-right">Gross Amount</th>
                    <th className="py-2.5 px-3 text-right">Rate %</th>
                    <th className="py-2.5 px-3 text-right">TDS Deducted</th>
                    <th className="py-2.5 px-3 text-right">Net Paid</th>
                    <th className="py-2.5 px-3 text-center">Due Date</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {tdsRegister.list.length === 0 ? (
                    <tr>
                      <td colSpan={8} className="py-8 text-center text-slate-400">
                        No TDS deductions recorded yet.
                      </td>
                    </tr>
                  ) : (
                    tdsRegister.list.map((item, idx) => (
                      <tr key={idx} className="hover:bg-slate-50/60">
                        <td className="py-2.5 px-3 font-mono font-semibold text-blue-700">
                          {item.section?.split('_')[0] || '194J'}
                        </td>
                        <td className="py-2.5 px-3 font-medium text-slate-800">
                          {item.vendorName}
                        </td>
                        <td className="py-2.5 px-3 font-mono text-slate-600">
                          {item.vendorPan}
                        </td>
                        <td className="py-2.5 px-3 text-right font-mono tabular-nums">
                          {formatMoney(item.grossAmount, 'INR')}
                        </td>
                        <td className="py-2.5 px-3 text-right font-mono tabular-nums">
                          {item.ratePct}%
                        </td>
                        <td className="py-2.5 px-3 text-right font-mono font-bold text-blue-700 tabular-nums">
                          {formatMoney(item.tdsWithheld, 'INR')}
                        </td>
                        <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-900">
                          {formatMoney(item.netPaid, 'INR')}
                        </td>
                        <td className="py-2.5 px-3 text-center font-mono text-[11px] text-rose-600">
                          {item.depositDueDate}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Tab 4: International Compliance (US Sales Tax, UK/EU VAT, UAE) */}
        {activeReportTab === 'international' && (
          <div className="mt-5 space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* UK / EU VAT Return */}
              <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="font-bold text-slate-900 text-xs">HMRC UK / EU VAT Return (Box 1 - 9)</h4>
                  <span className="text-[10px] font-mono text-blue-600">MTD Ready</span>
                </div>
                <div className="space-y-1.5 text-xs text-slate-600">
                  <div className="flex justify-between py-1 border-b border-slate-200">
                    <span>Box 1: VAT due on sales and other outputs:</span>
                    <span className="font-mono font-bold text-slate-900">£640.00</span>
                  </div>
                  <div className="flex justify-between py-1 border-b border-slate-200">
                    <span>Box 4: VAT reclaimed on purchases and expenses:</span>
                    <span className="font-mono text-emerald-700">-£180.00</span>
                  </div>
                  <div className="flex justify-between py-1.5 font-bold text-slate-900">
                    <span>Box 5: Net VAT to pay to HMRC:</span>
                    <span className="font-mono">£460.00</span>
                  </div>
                </div>
              </div>

              {/* USA Sales Tax & 1099 */}
              <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="font-bold text-slate-900 text-xs">US Form 1099-NEC & State Sales Tax</h4>
                  <span className="text-[10px] font-mono text-emerald-700">IRS Compliant</span>
                </div>
                <div className="space-y-1.5 text-xs text-slate-600">
                  <div className="flex justify-between py-1 border-b border-slate-200">
                    <span>Nonemployee Contractor Compensation (&gt;$600):</span>
                    <span className="font-mono font-bold text-slate-900">$1,425.00</span>
                  </div>
                  <div className="flex justify-between py-1 border-b border-slate-200">
                    <span>California CDTFA Sales Tax Collected:</span>
                    <span className="font-mono font-bold text-slate-900">$396.00</span>
                  </div>
                  <div className="flex justify-between py-1.5 font-bold text-slate-900">
                    <span>1099 Eligible Vendors Count:</span>
                    <span className="font-mono">2 Contractors</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
