import React, { useState } from 'react';
import { useAccounting } from '../../context/AccountingContext';
import {
  BookOpen,
  Plus,
  Search,
  CheckCircle2,
  Scale,
  Calendar,
  X
} from 'lucide-react';
import { ChartOfAccount, JournalEntry } from '../../types';

export const ChartOfAccountsView: React.FC = () => {
  const {
    chartOfAccounts,
    journalEntries,
    formatMoney,
    settings,
    addJournalEntry
  } = useAccounting();

  const [activeTab, setActiveTab] = useState<'accounts' | 'journals'>('journals');
  const [searchTerm, setSearchTerm] = useState('');
  const [isManualJeOpen, setIsManualJeOpen] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Manual JE form
  const [jeDate, setJeDate] = useState(new Date().toISOString().split('T')[0]);
  const [jeRef, setJeRef] = useState('');
  const [jeNarration, setJeNarration] = useState('');
  const [debitAcc, setDebitAcc] = useState('5000');
  const [creditAcc, setCreditAcc] = useState('1010');
  const [jeAmount, setJeAmount] = useState(15000);

  const filteredAccounts = chartOfAccounts.filter(acc =>
    acc.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    acc.code.includes(searchTerm) ||
    acc.type.includes(searchTerm.toLowerCase())
  );

  const filteredJournals = journalEntries.filter(je =>
    je.entryNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
    je.reference.toLowerCase().includes(searchTerm.toLowerCase()) ||
    je.narration.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleCreateJournal = (e: React.FormEvent) => {
    e.preventDefault();
    const dAcc = chartOfAccounts.find(a => a.code === debitAcc);
    const cAcc = chartOfAccounts.find(a => a.code === creditAcc);

    addJournalEntry({
      entryNumber: `JE-2026-${journalEntries.length + 10}`,
      date: jeDate,
      reference: jeRef || 'MANUAL-ADJ',
      narration: jeNarration || 'Manual Journal adjustment',
      lines: [
        {
          accountCode: debitAcc,
          accountName: dAcc ? dAcc.name : 'Account',
          debit: jeAmount,
          credit: 0,
          description: 'Debit adjustment'
        },
        {
          accountCode: creditAcc,
          accountName: cAcc ? cAcc.name : 'Account',
          debit: 0,
          credit: jeAmount,
          description: 'Credit adjustment'
        }
      ],
      totalDebit: jeAmount,
      totalCredit: jeAmount
    });

    setIsManualJeOpen(false);
    setToastMessage('Journal Entry posted successfully. General Ledger balanced.');
    setTimeout(() => setToastMessage(null), 3000);
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      {/* Toast */}
      {toastMessage && (
        <div className="fixed bottom-5 right-5 z-50 bg-slate-900 text-white text-xs px-4 py-2.5 rounded-lg shadow-xl flex items-center gap-2 border border-slate-700 animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Top Banner */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-2xs p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-base font-bold text-slate-900 flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-blue-600" />
            <span>Chart of Accounts & General Ledger</span>
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Double-entry bookkeeping audit trail, ledger balances, and automatic journal entries
          </p>
        </div>

        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg text-xs font-medium">
            <button
              onClick={() => setActiveTab('journals')}
              className={`px-3 py-1.5 rounded-md transition-colors ${
                activeTab === 'journals' ? 'bg-white text-slate-900 shadow-xs font-semibold' : 'text-slate-600'
              }`}
            >
              Journal Audit Trail ({journalEntries.length})
            </button>
            <button
              onClick={() => setActiveTab('accounts')}
              className={`px-3 py-1.5 rounded-md transition-colors ${
                activeTab === 'accounts' ? 'bg-white text-slate-900 shadow-xs font-semibold' : 'text-slate-600'
              }`}
            >
              Chart of Accounts ({chartOfAccounts.length})
            </button>
          </div>

          <button
            onClick={() => setIsManualJeOpen(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs transition-colors"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>New Journal Entry</span>
          </button>
        </div>
      </div>

      {activeTab === 'journals' ? (
        /* Journal Entries Log */
        <div className="space-y-4">
          <div className="bg-white rounded-xl border border-slate-200 shadow-2xs p-4">
            <div className="flex items-center justify-between mb-4">
              <div className="relative w-72">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="text"
                  placeholder="Search journal entries or reference..."
                  value={searchTerm}
                  onChange={e => setSearchTerm(e.target.value)}
                  className="w-full pl-9 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg"
                />
              </div>

              <div className="flex items-center gap-2 text-xs text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-md border border-emerald-200 font-medium">
                <Scale className="w-3.5 h-3.5" />
                <span>All Ledgers Balanced (Total Debits = Total Credits)</span>
              </div>
            </div>

            <div className="space-y-4">
              {filteredJournals.map(je => (
                <div
                  key={je.id}
                  className="p-4 rounded-xl border border-slate-200 bg-white hover:border-slate-300 transition-colors space-y-3"
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1 text-xs border-b border-slate-100 pb-2">
                    <div className="flex items-center gap-2">
                      <span className="font-mono font-bold text-blue-700">{je.entryNumber}</span>
                      <span className="text-slate-300">·</span>
                      <span className="font-semibold text-slate-900">{je.reference}</span>
                      <span className="text-slate-300">·</span>
                      <span className="text-slate-500 font-mono text-[11px]">{je.date}</span>
                    </div>

                    <div className="text-[11px] font-mono text-slate-500">
                      Amount: <span className="font-bold text-slate-900">{formatMoney(je.totalDebit, settings.baseCurrency)}</span>
                    </div>
                  </div>

                  <div className="text-xs text-slate-600 italic">
                    "{je.narration}"
                  </div>

                  {/* Journal Lines Table */}
                  <div className="border border-slate-100 rounded-lg overflow-hidden">
                    <table className="w-full text-left text-xs">
                      <thead className="bg-slate-50 text-[11px] font-semibold text-slate-500 border-b border-slate-100">
                        <tr>
                          <th className="py-1.5 px-3">Account Code & Name</th>
                          <th className="py-1.5 px-3">Description</th>
                          <th className="py-1.5 px-3 text-right">Debit (INR)</th>
                          <th className="py-1.5 px-3 text-right">Credit (INR)</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100 font-mono text-[11px]">
                        {je.lines.map((line, idx) => (
                          <tr key={idx} className="hover:bg-slate-50/50">
                            <td className="py-2 px-3">
                              <span className="font-bold text-slate-800">{line.accountCode}</span> - {line.accountName}
                            </td>
                            <td className="py-2 px-3 text-slate-500 font-sans">{line.description}</td>
                            <td className="py-2 px-3 text-right font-medium text-slate-900 tabular-nums">
                              {line.debit > 0 ? formatMoney(line.debit, settings.baseCurrency) : '—'}
                            </td>
                            <td className="py-2 px-3 text-right font-medium text-slate-900 tabular-nums">
                              {line.credit > 0 ? formatMoney(line.credit, settings.baseCurrency) : '—'}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      ) : (
        /* Chart of Accounts Master */
        <div className="bg-white rounded-xl border border-slate-200 shadow-2xs p-4 overflow-hidden">
          <div className="mb-4 relative w-72">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Search account code or name..."
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg"
            />
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-600">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50/75 text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
                  <th className="py-2.5 px-3">Code</th>
                  <th className="py-2.5 px-3">Account Name</th>
                  <th className="py-2.5 px-3">Type</th>
                  <th className="py-2.5 px-3">Sub-Type</th>
                  <th className="py-2.5 px-3 text-right">Ledger Balance</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredAccounts.map(acc => (
                  <tr key={acc.code} className="hover:bg-slate-50/60">
                    <td className="py-3 px-3 font-mono font-bold text-blue-700">{acc.code}</td>
                    <td className="py-3 px-3 font-semibold text-slate-800">{acc.name}</td>
                    <td className="py-3 px-3 capitalize">
                      <span className={`text-[10px] font-bold uppercase px-1.5 py-0.5 rounded ${
                        acc.type === 'asset' ? 'bg-emerald-50 text-emerald-800' :
                        acc.type === 'liability' ? 'bg-amber-50 text-amber-800' :
                        acc.type === 'income' ? 'bg-blue-50 text-blue-800' :
                        acc.type === 'expense' ? 'bg-rose-50 text-rose-800' : 'bg-purple-50 text-purple-800'
                      }`}>
                        {acc.type}
                      </span>
                    </td>
                    <td className="py-3 px-3 text-slate-500">{acc.subType}</td>
                    <td className="py-3 px-3 text-right font-mono font-bold text-slate-900 tabular-nums">
                      {formatMoney(acc.balance, settings.baseCurrency)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Manual JE Modal */}
      {isManualJeOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-xs p-4">
          <div className="bg-white w-full max-w-lg rounded-2xl shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95">
            <div className="px-6 py-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-slate-900">Post Manual Journal Entry</h3>
                <p className="text-xs text-slate-500">Record adjusting, depreciation or non-cash entries</p>
              </div>
              <button
                onClick={() => setIsManualJeOpen(false)}
                className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateJournal} className="p-6 space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Date</label>
                  <input
                    type="date"
                    value={jeDate}
                    onChange={e => setJeDate(e.target.value)}
                    className="w-full text-xs bg-slate-50 border border-slate-200 rounded-lg px-3 py-2"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Reference</label>
                  <input
                    type="text"
                    value={jeRef}
                    onChange={e => setJeRef(e.target.value)}
                    placeholder="e.g. ADJ-OCT-01"
                    className="w-full text-xs bg-slate-50 border border-slate-200 rounded-lg px-3 py-2"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Debit Account (Dr)</label>
                <select
                  value={debitAcc}
                  onChange={e => setDebitAcc(e.target.value)}
                  className="w-full text-xs bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 font-medium"
                >
                  {chartOfAccounts.map(a => (
                    <option key={a.code} value={a.code}>{a.code} - {a.name} ({a.type})</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Credit Account (Cr)</label>
                <select
                  value={creditAcc}
                  onChange={e => setCreditAcc(e.target.value)}
                  className="w-full text-xs bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 font-medium"
                >
                  {chartOfAccounts.map(a => (
                    <option key={a.code} value={a.code}>{a.code} - {a.name} ({a.type})</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Amount (INR)</label>
                <input
                  type="number"
                  value={jeAmount}
                  onChange={e => setJeAmount(Number(e.target.value))}
                  className="w-full text-sm font-mono font-bold bg-slate-50 border border-slate-200 rounded-lg px-3 py-2"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Narration</label>
                <textarea
                  rows={2}
                  value={jeNarration}
                  onChange={e => setJeNarration(e.target.value)}
                  placeholder="Purpose of this manual adjusting journal entry..."
                  className="w-full text-xs bg-slate-50 border border-slate-200 rounded-lg p-2.5"
                  required
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-2 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setIsManualJeOpen(false)}
                  className="px-4 py-2 text-xs font-medium text-slate-600 hover:bg-slate-100 rounded-lg"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs"
                >
                  Post Journal Entry
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
