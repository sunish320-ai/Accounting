import React, { useState } from 'react';
import { useAccounting } from '../../context/AccountingContext';
import {
  TrendingUp,
  TrendingDown,
  ArrowUpRight,
  ArrowDownRight,
  AlertCircle,
  Building,
  CheckCircle2,
  Calendar,
  Send,
  Eye,
  RefreshCw,
  Clock,
  Landmark
} from 'lucide-react';

interface DashboardViewProps {
  onNavigateToInvoices: () => void;
  onNavigateToBills: () => void;
  onNavigateToBanking: () => void;
  onViewInvoice: (id: string) => void;
  onPayBill: (id: string) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  onNavigateToInvoices,
  onNavigateToBills,
  onNavigateToBanking,
  onViewInvoice,
  onPayBill,
}) => {
  const {
    formatMoney,
    convertAmount,
    selectedDisplayCurrency,
    settings,
    totalCashBalanceBase,
    totalReceivablesBase,
    totalPayablesBase,
    totalTdsPayableBase,
    totalTdsReceivableBase,
    netIncomeBase,
    apAging,
    arAging,
    cashFlowForecast,
    bankAccounts,
    invoices,
    bills,
    isSyncingBank,
    syncBankFeeds,
    sendPaymentReminder
  } = useAccounting();

  const [forecastHorizon, setForecastHorizon] = useState<'30' | '60' | '90'>('60');
  const [reminderSentToast, setReminderSentToast] = useState<string | null>(null);

  // Filter forecast intervals according to horizon
  const displayedForecast = forecastHorizon === '30'
    ? cashFlowForecast.slice(0, 2)
    : forecastHorizon === '60'
    ? cashFlowForecast.slice(0, 4)
    : cashFlowForecast;

  // Find max value in cash flow to normalize visual bars
  const maxForecastFlow = Math.max(
    ...displayedForecast.map(f => Math.max(f.cashIn, f.cashOut, 100000))
  );

  const overdueInvoices = invoices.filter(i => i.status === 'overdue' && i.balanceDue > 0);
  const pendingBills = bills.filter(b => b.balanceDue > 0);

  const handleQuickReminder = (invoiceId: string, customerName: string) => {
    sendPaymentReminder(invoiceId, 'email');
    setReminderSentToast(`Payment reminder dispatched to ${customerName}`);
    setTimeout(() => setReminderSentToast(null), 3000);
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      {/* Toast Notification */}
      {reminderSentToast && (
        <div className="fixed bottom-5 right-5 z-50 bg-slate-900 text-white text-xs px-4 py-2.5 rounded-lg shadow-xl flex items-center gap-2 border border-slate-700 animate-in fade-in slide-in-from-bottom-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span>{reminderSentToast}</span>
        </div>
      )}

      {/* Top Metric Strip (4 High-Level Key Financial Metrics) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Cash in Bank */}
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-xs font-medium">Total Cash in Banks</span>
            <Landmark className="w-4 h-4 text-blue-600" />
          </div>
          <div className="text-xl font-bold font-mono tracking-tight tabular-nums text-slate-900">
            {formatMoney(
              convertAmount(totalCashBalanceBase, settings.baseCurrency, selectedDisplayCurrency),
              selectedDisplayCurrency
            )}
          </div>
          <div className="mt-2 flex items-center justify-between text-[11px] text-slate-500">
            <span>Across {bankAccounts.length} Connected Accounts</span>
            <button
              onClick={onNavigateToBanking}
              className="text-blue-600 hover:text-blue-700 font-medium hover:underline"
            >
              View Feeds
            </button>
          </div>
        </div>

        {/* Real-time Accounts Receivable (AR) */}
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-xs font-medium">Accounts Receivable (AR)</span>
            <TrendingUp className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-xl font-bold font-mono tracking-tight tabular-nums text-slate-900">
            {formatMoney(
              convertAmount(totalReceivablesBase, settings.baseCurrency, selectedDisplayCurrency),
              selectedDisplayCurrency
            )}
          </div>
          <div className="mt-2 flex items-center justify-between text-[11px]">
            <span className="text-amber-600 font-medium">
              {overdueInvoices.length} Overdue Invoices
            </span>
            <button
              onClick={onNavigateToInvoices}
              className="text-blue-600 hover:text-blue-700 font-medium hover:underline"
            >
              Manage Sales
            </button>
          </div>
        </div>

        {/* Real-time Accounts Payable (AP) */}
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-xs font-medium">Accounts Payable (AP)</span>
            <TrendingDown className="w-4 h-4 text-rose-600" />
          </div>
          <div className="text-xl font-bold font-mono tracking-tight tabular-nums text-slate-900">
            {formatMoney(
              convertAmount(totalPayablesBase, settings.baseCurrency, selectedDisplayCurrency),
              selectedDisplayCurrency
            )}
          </div>
          <div className="mt-2 flex items-center justify-between text-[11px]">
            <span className="text-slate-500">
              {pendingBills.length} Bills to settle
            </span>
            <button
              onClick={onNavigateToBills}
              className="text-blue-600 hover:text-blue-700 font-medium hover:underline"
            >
              Pay Bills
            </button>
          </div>
        </div>

        {/* Net Operating Profit / Margin */}
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-xs font-medium">Operating Profit (YTD)</span>
            <ArrowUpRight className="w-4 h-4 text-blue-600" />
          </div>
          <div className={`text-xl font-bold font-mono tracking-tight tabular-nums ${netIncomeBase >= 0 ? 'text-emerald-700' : 'text-rose-700'}`}>
            {formatMoney(
              convertAmount(netIncomeBase, settings.baseCurrency, selectedDisplayCurrency),
              selectedDisplayCurrency
            )}
          </div>
          <div className="mt-2 flex items-center justify-between text-[11px] text-slate-500">
            <span>TDS Payable: {formatMoney(convertAmount(totalTdsPayableBase, settings.baseCurrency, selectedDisplayCurrency))}</span>
            <span className="text-slate-400">·</span>
            <span>TDS Recv: {formatMoney(convertAmount(totalTdsReceivableBase, settings.baseCurrency, selectedDisplayCurrency))}</span>
          </div>
        </div>
      </div>

      {/* Main Grid: Cash Flow Projection & Accounts Payable Aging */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Cash Flow Projection (Span 2 Columns) */}
        <div className="lg:col-span-2 bg-white rounded-xl border border-slate-200 p-5 shadow-2xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <div>
                <h2 className="text-sm font-bold text-slate-900">Real-Time Cash Flow Forecast</h2>
                <p className="text-xs text-slate-500">
                  Projected inflows from receivables vs expected vendor & tax disbursements
                </p>
              </div>

              {/* Time Horizon Segmented Control */}
              <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg text-xs font-medium">
                {(['30', '60', '90'] as const).map(days => (
                  <button
                    key={days}
                    onClick={() => setForecastHorizon(days)}
                    className={`px-2.5 py-1 rounded-md transition-colors ${
                      forecastHorizon === days
                        ? 'bg-white text-slate-900 shadow-xs font-semibold'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    {days} Days
                  </button>
                ))}
              </div>
            </div>

            {/* Visual Projection Chart */}
            <div className="space-y-4 pt-2">
              {displayedForecast.map((item, idx) => {
                const inPercent = Math.min(100, Math.round((item.cashIn / maxForecastFlow) * 100));
                const outPercent = Math.min(100, Math.round((item.cashOut / maxForecastFlow) * 100));

                return (
                  <div key={idx} className="space-y-1.5 border-b border-slate-100 pb-3 last:border-0 last:pb-0">
                    <div className="flex items-center justify-between text-xs font-medium">
                      <div className="flex items-center gap-2">
                        <Calendar className="w-3.5 h-3.5 text-slate-400" />
                        <span className="text-slate-800 font-semibold">{item.period}</span>
                      </div>
                      <div className="flex items-center gap-4 text-xs font-mono tabular-nums">
                        <span className="text-emerald-600">
                          +{formatMoney(convertAmount(item.cashIn, settings.baseCurrency, selectedDisplayCurrency))}
                        </span>
                        <span className="text-rose-600">
                          -{formatMoney(convertAmount(item.cashOut, settings.baseCurrency, selectedDisplayCurrency))}
                        </span>
                        <span className="text-slate-500 font-bold w-24 text-right">
                          {formatMoney(convertAmount(item.runningBalance, settings.baseCurrency, selectedDisplayCurrency))}
                        </span>
                      </div>
                    </div>

                    {/* Dual Comparative Bar */}
                    <div className="space-y-1">
                      <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden flex">
                        <div
                          className="bg-emerald-500 h-full rounded-full transition-all duration-300"
                          style={{ width: `${Math.max(4, inPercent)}%` }}
                          title={`Cash In: ${formatMoney(item.cashIn)}`}
                        />
                      </div>
                      <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden flex">
                        <div
                          className="bg-rose-400 h-full rounded-full transition-all duration-300"
                          style={{ width: `${Math.max(4, outPercent)}%` }}
                          title={`Cash Out: ${formatMoney(item.cashOut)}`}
                        />
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
            <div className="flex items-center gap-4">
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
                <span>Projected Receivables In</span>
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-rose-400" />
                <span>Vendor Bills & Dues Out</span>
              </span>
            </div>
            <span className="font-mono text-[11px] text-slate-400">
              Real-time ledger projection
            </span>
          </div>
        </div>

        {/* Real-time Accounts Payable (AP) Aging Breakdown */}
        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-2xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <div>
                <h2 className="text-sm font-bold text-slate-900">AP Aging Summary</h2>
                <p className="text-xs text-slate-500">Vendor liability aging schedule</p>
              </div>
              <button
                onClick={onNavigateToBills}
                className="text-xs text-blue-600 hover:text-blue-700 font-semibold hover:underline"
              >
                View Bills
              </button>
            </div>

            {/* Total Payables Header */}
            <div className="p-3 bg-slate-50 rounded-lg border border-slate-200/80 mb-4">
              <div className="text-[11px] font-medium text-slate-500">Total Unpaid Vendor Bills</div>
              <div className="text-lg font-bold font-mono tabular-nums text-slate-900">
                {formatMoney(
                  convertAmount(apAging.total, settings.baseCurrency, selectedDisplayCurrency)
                )}
              </div>
            </div>

            {/* Aging Buckets Table */}
            <div className="space-y-2.5 text-xs">
              <div className="flex items-center justify-between py-1 border-b border-slate-100">
                <span className="text-slate-600">Current (Not Due)</span>
                <span className="font-mono font-medium text-slate-900 tabular-nums">
                  {formatMoney(convertAmount(apAging.current, settings.baseCurrency, selectedDisplayCurrency))}
                </span>
              </div>
              <div className="flex items-center justify-between py-1 border-b border-slate-100">
                <span className="text-slate-600">1 - 30 Days Overdue</span>
                <span className="font-mono font-medium text-amber-600 tabular-nums">
                  {formatMoney(convertAmount(apAging.days1_30, settings.baseCurrency, selectedDisplayCurrency))}
                </span>
              </div>
              <div className="flex items-center justify-between py-1 border-b border-slate-100">
                <span className="text-slate-600">31 - 60 Days Overdue</span>
                <span className="font-mono font-medium text-orange-600 tabular-nums">
                  {formatMoney(convertAmount(apAging.days31_60, settings.baseCurrency, selectedDisplayCurrency))}
                </span>
              </div>
              <div className="flex items-center justify-between py-1 border-b border-slate-100">
                <span className="text-slate-600">61 - 90 Days Overdue</span>
                <span className="font-mono font-medium text-rose-600 tabular-nums">
                  {formatMoney(convertAmount(apAging.days61_90, settings.baseCurrency, selectedDisplayCurrency))}
                </span>
              </div>
              <div className="flex items-center justify-between py-1">
                <span className="text-slate-600">90+ Days Overdue</span>
                <span className="font-mono font-bold text-rose-700 tabular-nums">
                  {formatMoney(convertAmount(apAging.days90Plus, settings.baseCurrency, selectedDisplayCurrency))}
                </span>
              </div>
            </div>
          </div>

          {/* Prompt to settle */}
          <div className="mt-4 pt-3 border-t border-slate-100">
            <button
              onClick={onNavigateToBills}
              className="w-full py-2 bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold rounded-lg transition-colors flex items-center justify-center gap-1.5"
            >
              <span>Schedule Vendor Payments</span>
              <ArrowDownRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* Secondary Row: Bank Feed Cards & Overdue Receivables Alert */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Connected Bank Accounts (Span 2) */}
        <div className="lg:col-span-2 bg-white rounded-xl border border-slate-200 p-5 shadow-2xs">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-sm font-bold text-slate-900">Connected Bank Accounts & Open Banking Feeds</h2>
              <p className="text-xs text-slate-500">Real-time balances across domestic & multi-currency clearing banks</p>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={syncBankFeeds}
                disabled={isSyncingBank}
                className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium text-slate-700 bg-slate-50 hover:bg-slate-100 rounded-md border border-slate-200 transition-colors"
              >
                <RefreshCw className={`w-3.5 h-3.5 text-blue-600 ${isSyncingBank ? 'animate-spin' : ''}`} />
                <span>{isSyncingBank ? 'Syncing...' : 'Sync Feeds'}</span>
              </button>
              <button
                onClick={onNavigateToBanking}
                className="text-xs text-blue-600 hover:text-blue-700 font-semibold hover:underline"
              >
                Reconciliation Tool
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
            {bankAccounts.map(account => (
              <div
                key={account.id}
                className="p-3.5 rounded-lg border border-slate-200 bg-slate-50/50 hover:bg-slate-50 transition-colors"
              >
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <div className="w-7 h-7 rounded-md bg-blue-100 text-blue-700 flex items-center justify-center font-bold text-xs">
                      {account.bankName.slice(0, 2).toUpperCase()}
                    </div>
                    <div>
                      <div className="text-xs font-bold text-slate-800">{account.name}</div>
                      <div className="text-[11px] text-slate-400 font-mono">{account.accountNumber}</div>
                    </div>
                  </div>
                  <span className="text-[10px] font-medium text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-200">
                    Live
                  </span>
                </div>

                <div className="flex items-baseline justify-between mt-3">
                  <div>
                    <div className="text-[11px] text-slate-500">Account Balance</div>
                    <div className="text-base font-bold font-mono tabular-nums text-slate-900">
                      {formatMoney(account.balance, account.currency)}
                    </div>
                  </div>
                  {account.currency !== settings.baseCurrency && (
                    <div className="text-right">
                      <div className="text-[10px] text-slate-400">Base Equivalent</div>
                      <div className="text-xs font-mono font-medium text-slate-600 tabular-nums">
                        {formatMoney(
                          convertAmount(account.balance, account.currency, settings.baseCurrency),
                          settings.baseCurrency
                        )}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Actionable Overdue Invoices / Reminders Box */}
        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-2xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-amber-500" />
                <h2 className="text-sm font-bold text-slate-900">Overdue Invoices</h2>
              </div>
              <span className="text-xs text-amber-700 font-medium">
                {overdueInvoices.length} Needing Action
              </span>
            </div>

            <div className="space-y-3">
              {overdueInvoices.length === 0 ? (
                <div className="p-6 text-center text-xs text-slate-400">
                  No overdue customer invoices at this time.
                </div>
              ) : (
                overdueInvoices.map(inv => (
                  <div
                    key={inv.id}
                    className="p-3 rounded-lg border border-amber-200/80 bg-amber-50/40 text-xs space-y-2"
                  >
                    <div className="flex items-center justify-between font-semibold">
                      <span className="text-slate-900">{inv.invoiceNumber}</span>
                      <span className="font-mono text-slate-900 tabular-nums">
                        {formatMoney(inv.balanceDue, inv.currency)}
                      </span>
                    </div>

                    <div className="text-[11px] text-slate-600 truncate">
                      {inv.customerName}
                    </div>

                    <div className="flex items-center justify-between pt-1 border-t border-amber-200/60">
                      <span className="text-[10px] text-amber-700">
                        Due: {inv.dueDate}
                      </span>
                      <div className="flex items-center gap-1.5">
                        <button
                          onClick={() => onViewInvoice(inv.id)}
                          className="px-2 py-1 text-[11px] font-medium text-slate-700 bg-white border border-slate-200 rounded hover:bg-slate-50 transition-colors"
                        >
                          View
                        </button>
                        <button
                          onClick={() => handleQuickReminder(inv.id, inv.customerName)}
                          className="px-2 py-1 text-[11px] font-semibold text-white bg-blue-600 rounded hover:bg-blue-700 transition-colors flex items-center gap-1"
                        >
                          <Send className="w-3 h-3" />
                          <span>Remind</span>
                        </button>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-100 text-center">
            <button
              onClick={onNavigateToInvoices}
              className="text-xs text-blue-600 hover:text-blue-700 font-semibold"
            >
              See All Sales Invoices →
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
