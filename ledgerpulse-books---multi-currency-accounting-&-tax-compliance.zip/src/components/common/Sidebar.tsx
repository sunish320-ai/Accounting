import React, { useState } from 'react';
import {
  LayoutDashboard,
  Users,
  FileCheck2,
  ShoppingCart,
  FileText,
  RotateCcw,
  Building2,
  Package,
  Receipt,
  Wallet,
  CornerUpLeft,
  Landmark,
  Clock,
  ShieldCheck,
  BookOpen,
  Settings,
  Building,
  ChevronDown,
  ChevronRight,
  Scale,
  TrendingUp,
  Activity,
  PieChart,
  FileSpreadsheet
} from 'lucide-react';
import { useAccounting } from '../../context/AccountingContext';

interface SidebarProps {
  activeView: string;
  setActiveView: (view: string) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ activeView, setActiveView }) => {
  const { settings, resetToDemoData, invoices, bills, estimates, salesOrders, purchaseOrders, expenses } = useAccounting();

  // Collapsible accordion sections
  const [isSalesOpen, setIsSalesOpen] = useState(true);
  const [isPurchasesOpen, setIsPurchasesOpen] = useState(true);
  const [isReportsOpen, setIsReportsOpen] = useState(true);

  const overdueInvoicesCount = invoices.filter(i => i.status === 'overdue').length;
  const overdueBillsCount = bills.filter(b => b.status === 'overdue').length;

  const salesItems = [
    { id: 'customers', label: 'Customers', icon: Users, badge: null },
    { id: 'estimates', label: 'Estimates', icon: FileCheck2, badge: `${estimates.length}` },
    { id: 'sales_orders', label: 'Sales Orders', icon: ShoppingCart, badge: `${salesOrders.length}` },
    { id: 'invoices', label: 'Sales Invoices', icon: FileText, badge: overdueInvoicesCount > 0 ? `${overdueInvoicesCount} overdue` : null, badgeColor: 'text-amber-400 bg-amber-950/60' },
    { id: 'sales_returns', label: 'Sales Returns', icon: RotateCcw, badge: 'Credit Notes' },
  ];

  const purchaseItems = [
    { id: 'vendors', label: 'Vendors', icon: Building2, badge: null },
    { id: 'purchase_orders', label: 'Purchase Orders', icon: Package, badge: `${purchaseOrders.length}` },
    { id: 'bills', label: 'Bills', icon: Receipt, badge: overdueBillsCount > 0 ? `${overdueBillsCount} due` : null, badgeColor: 'text-rose-400 bg-rose-950/60' },
    { id: 'expenses', label: 'Expenses', icon: Wallet, badge: `${expenses.length}` },
    { id: 'purchase_returns', label: 'Purchase Returns', icon: CornerUpLeft, badge: 'Debit Notes' },
  ];

  const reportItems = [
    { id: 'reports_balance_sheet', label: 'Balance Sheet', icon: Scale, badge: 'Live' },
    { id: 'reports_profit_loss', label: 'Profit & Loss', icon: TrendingUp, badge: 'P&L' },
    { id: 'reports_cash_flow', label: 'Cash Flow Statement', icon: Activity, badge: null },
    { id: 'reports_accounts_payables', label: 'Accounts Payables', icon: Receipt, badge: 'Aging' },
    { id: 'reports_accounts_receivables', label: 'Accounts Receivables', icon: Users, badge: 'Aging' },
    { id: 'reports_financial_ratios', label: 'Various Ratios', icon: PieChart, badge: 'Metrics' },
  ];

  const generalItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'banking', label: 'Banking & Feeds', icon: Landmark, badge: 'Live' },
    { id: 'recurring', label: 'Recurring & Reminders', icon: Clock, badge: 'Auto' },
    { id: 'taxes', label: 'Tax Compliance', icon: ShieldCheck, badge: 'GST/TDS' },
    { id: 'accounts', label: 'Chart of Accounts', icon: BookOpen },
    { id: 'settings', label: 'Settings', icon: Settings },
  ];

  return (
    <aside className="w-64 bg-[#0d1829] text-slate-300 flex flex-col shrink-0 border-r border-slate-800 select-none">
      {/* Brand & Organization Block */}
      <div className="p-4 border-b border-slate-800/80">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center text-white shadow-md font-bold text-base tracking-wider">
            LP
          </div>
          <div className="min-w-0">
            <h1 className="text-sm font-bold text-white tracking-tight truncate leading-tight">
              LedgerPulse Notes
            </h1>
            <div className="flex items-center gap-1.5 text-[11px] text-slate-400">
              <Building className="w-3 h-3 text-slate-500 shrink-0" />
              <span className="truncate">{settings.businessName}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Navigation Links Grouped by Sales & Purchases */}
      <nav className="flex-1 px-3 py-3 space-y-4 overflow-y-auto">
        {/* Top: Financial Dashboard */}
        <div>
          <button
            onClick={() => setActiveView('dashboard')}
            className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-xs font-medium transition-all group ${
              activeView === 'dashboard'
                ? 'bg-blue-600 text-white font-semibold shadow-xs'
                : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
            }`}
          >
            <div className="flex items-center gap-2.5">
              <LayoutDashboard className={`w-4 h-4 ${activeView === 'dashboard' ? 'text-white' : 'text-slate-400'}`} />
              <span>Dashboard</span>
            </div>
          </button>
        </div>

        {/* Column 1: SALES */}
        <div className="space-y-1">
          <button
            onClick={() => setIsSalesOpen(!isSalesOpen)}
            className="w-full flex items-center justify-between px-2 py-1 text-[11px] font-bold text-slate-400 hover:text-slate-200 uppercase tracking-wider transition-colors"
          >
            <span className="flex items-center gap-1.5 text-blue-400">
              <span>Sales</span>
            </span>
            {isSalesOpen ? <ChevronDown className="w-3 h-3 text-slate-500" /> : <ChevronRight className="w-3 h-3 text-slate-500" />}
          </button>

          {isSalesOpen && (
            <div className="space-y-0.5 pl-1">
              {salesItems.map(item => {
                const Icon = item.icon;
                const isActive = activeView === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => setActiveView(item.id)}
                    className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-lg text-xs font-medium transition-all group ${
                      isActive
                        ? 'bg-blue-600 text-white font-semibold shadow-xs'
                        : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
                    }`}
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <Icon className={`w-3.5 h-3.5 shrink-0 ${isActive ? 'text-white' : 'text-slate-400 group-hover:text-slate-200'}`} />
                      <span className="truncate">{item.label}</span>
                    </div>
                    {item.badge && (
                      <span className={`text-[10px] px-1.5 py-0.2 rounded font-mono font-medium ${
                        item.badgeColor || (isActive ? 'bg-blue-700 text-blue-100' : 'bg-slate-800 text-slate-400')
                      }`}>
                        {item.badge}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          )}
        </div>

        {/* Column 2: PURCHASES */}
        <div className="space-y-1">
          <button
            onClick={() => setIsPurchasesOpen(!isPurchasesOpen)}
            className="w-full flex items-center justify-between px-2 py-1 text-[11px] font-bold text-slate-400 hover:text-slate-200 uppercase tracking-wider transition-colors"
          >
            <span className="flex items-center gap-1.5 text-emerald-400">
              <span>Purchases</span>
            </span>
            {isPurchasesOpen ? <ChevronDown className="w-3 h-3 text-slate-500" /> : <ChevronRight className="w-3 h-3 text-slate-500" />}
          </button>

          {isPurchasesOpen && (
            <div className="space-y-0.5 pl-1">
              {purchaseItems.map(item => {
                const Icon = item.icon;
                const isActive = activeView === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => setActiveView(item.id)}
                    className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-lg text-xs font-medium transition-all group ${
                      isActive
                        ? 'bg-blue-600 text-white font-semibold shadow-xs'
                        : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
                    }`}
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <Icon className={`w-3.5 h-3.5 shrink-0 ${isActive ? 'text-white' : 'text-slate-400 group-hover:text-slate-200'}`} />
                      <span className="truncate">{item.label}</span>
                    </div>
                    {item.badge && (
                      <span className={`text-[10px] px-1.5 py-0.2 rounded font-mono font-medium ${
                        item.badgeColor || (isActive ? 'bg-blue-700 text-blue-100' : 'bg-slate-800 text-slate-400')
                      }`}>
                        {item.badge}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          )}
        </div>

        {/* Column 3: REPORTS */}
        <div className="space-y-1">
          <button
            onClick={() => setIsReportsOpen(!isReportsOpen)}
            className="w-full flex items-center justify-between px-2 py-1 text-[11px] font-bold text-slate-400 hover:text-slate-200 uppercase tracking-wider transition-colors"
          >
            <span className="flex items-center gap-1.5 text-purple-400">
              <span>Reports</span>
            </span>
            {isReportsOpen ? <ChevronDown className="w-3 h-3 text-slate-500" /> : <ChevronRight className="w-3 h-3 text-slate-500" />}
          </button>

          {isReportsOpen && (
            <div className="space-y-0.5 pl-1">
              {reportItems.map(item => {
                const Icon = item.icon;
                const isActive = activeView === item.id || (activeView === 'reports' && item.id === 'reports_balance_sheet');
                return (
                  <button
                    key={item.id}
                    onClick={() => setActiveView(item.id)}
                    className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-lg text-xs font-medium transition-all group ${
                      isActive
                        ? 'bg-purple-600 text-white font-semibold shadow-xs'
                        : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
                    }`}
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <Icon className={`w-3.5 h-3.5 shrink-0 ${isActive ? 'text-white' : 'text-slate-400 group-hover:text-slate-200'}`} />
                      <span className="truncate">{item.label}</span>
                    </div>
                    {item.badge && (
                      <span className={`text-[10px] px-1.5 py-0.2 rounded font-mono font-medium ${
                        isActive ? 'bg-purple-700 text-purple-100' : 'bg-slate-800 text-slate-400'
                      }`}>
                        {item.badge}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          )}
        </div>

        {/* Column 4: GENERAL & COMPLIANCE */}
        <div className="space-y-1 pt-1 border-t border-slate-800/60">
          <div className="px-2 py-1 text-[11px] font-bold text-slate-500 uppercase tracking-wider">
            Accounting & Banking
          </div>
          <div className="space-y-0.5">
            {generalItems.slice(1).map(item => {
              const Icon = item.icon;
              const isActive = activeView === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveView(item.id)}
                  className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-lg text-xs font-medium transition-all group ${
                    isActive
                      ? 'bg-blue-600 text-white font-semibold shadow-xs'
                      : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
                  }`}
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <Icon className={`w-3.5 h-3.5 shrink-0 ${isActive ? 'text-white' : 'text-slate-400 group-hover:text-slate-200'}`} />
                    <span className="truncate">{item.label}</span>
                  </div>
                  {item.badge && (
                    <span className={`text-[10px] px-1.5 py-0.2 rounded font-mono font-medium ${
                      isActive ? 'bg-blue-700 text-blue-100' : 'bg-slate-800 text-slate-400'
                    }`}>
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>
      </nav>

      {/* Footer Info & Demo Reset */}
      <div className="p-3 border-t border-slate-800/80 bg-slate-950/40 text-[11px] space-y-2">
        <div className="flex items-center justify-between text-slate-400 px-1">
          <span>LedgerPulse Notes</span>
          <span className="text-[10px] text-emerald-400 font-mono">v2.5 Full</span>
        </div>
        <button
          onClick={() => {
            if (window.confirm('Reset all sample records across Sales and Purchases?')) {
              resetToDemoData();
            }
          }}
          className="w-full flex items-center justify-center gap-1.5 px-2.5 py-1.5 text-xs text-slate-400 hover:text-slate-200 hover:bg-slate-800/60 rounded-md transition-colors"
          title="Restore standard sample business transactions and accounts"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>Reset Sample Data</span>
        </button>
      </div>
    </aside>
  );
};
