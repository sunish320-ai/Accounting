import React, { useState } from 'react';
import { useAccounting } from '../../context/AccountingContext';
import {
  Building2,
  Plus,
  RefreshCw,
  Search,
  ChevronDown,
  Globe,
  FileText,
  CreditCard,
  UserPlus,
  Receipt,
  Check,
  FileCheck2,
  ShoppingCart,
  Package,
  Wallet
} from 'lucide-react';
import { CurrencyCode, TaxJurisdiction } from '../../types';

interface HeaderProps {
  activeView: string;
  onOpenCreateInvoice: () => void;
  onOpenCreateBill: () => void;
  onOpenAddCustomer: () => void;
  onOpenAddVendor: () => void;
  onOpenCreateEstimate?: () => void;
  onOpenCreateOrder?: () => void;
  onOpenCreatePO?: () => void;
  onOpenCreateExpense?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeView,
  onOpenCreateInvoice,
  onOpenCreateBill,
  onOpenAddCustomer,
  onOpenAddVendor,
  onOpenCreateEstimate,
  onOpenCreateOrder,
  onOpenCreatePO,
  onOpenCreateExpense,
}) => {
  const {
    settings,
    currencies,
    selectedDisplayCurrency,
    setDisplayCurrency,
    syncLiveFxRates,
    setJurisdiction,
    isSyncingBank,
    syncBankFeeds
  } = useAccounting();

  const [isQuickMenuOpen, setIsQuickMenuOpen] = useState(false);
  const [isCurrencyMenuOpen, setIsCurrencyMenuOpen] = useState(false);
  const [isJurisdictionMenuOpen, setIsJurisdictionMenuOpen] = useState(false);
  const [isFxSyncing, setIsFxSyncing] = useState(false);

  const handleSyncFx = async () => {
    setIsFxSyncing(true);
    await syncLiveFxRates();
    setIsFxSyncing(false);
  };

  const getViewTitle = () => {
    switch (activeView) {
      case 'dashboard': return 'Financial Overview & Cash Flow';
      // Sales Column
      case 'customers': return 'Customers & Client Accounts';
      case 'estimates': return 'Sales Estimates & Quotations';
      case 'sales_orders': return 'Sales Orders & Fulfillment';
      case 'invoices': return 'Invoices & Sales (Accounts Receivable)';
      case 'sales_returns': return 'Sales Returns & Credit Notes';
      // Purchases Column
      case 'vendors': return 'Vendors & Supplier Directory';
      case 'purchase_orders': return 'Purchase Orders & Procurement';
      case 'bills': return 'Bills & Accounts Payable (AP)';
      case 'expenses': return 'Direct Expenses & Petty Cash';
      case 'purchase_returns': return 'Purchase Returns & Debit Notes';
      // Accounting & Banking
      case 'recurring': return 'Recurring Invoices & Payment Reminders';
      case 'banking': return 'Banking & Live Transaction Feeds';
      case 'taxes': return 'Tax Compliance & Automated Reports';
      case 'accounts': return 'Chart of Accounts & General Ledger';
      case 'settings': return 'Company Settings & Multi-Currency';
      // Reports Column
      case 'reports':
      case 'reports_balance_sheet': return 'Balance Sheet · Financial Reports';
      case 'reports_profit_loss': return 'Profit & Loss (P&L) · Financial Reports';
      case 'reports_cash_flow': return 'Cash Flow Statement · Financial Reports';
      case 'reports_accounts_payables': return 'Accounts Payables (AP) Aging & Ledger';
      case 'reports_accounts_receivables': return 'Accounts Receivables (AR) Aging & Balances';
      case 'reports_financial_ratios': return 'Financial Ratios & Performance Metrics';
      default: return 'Financial Dashboard';
    }
  };

  const jurisdictions: { id: TaxJurisdiction; label: string; flag: string }[] = [
    { id: 'INDIA', label: 'India (GST & TDS)', flag: '🇮🇳' },
    { id: 'USA', label: 'United States (Sales Tax & 1099)', flag: '🇺🇸' },
    { id: 'UK_EU', label: 'United Kingdom / EU (VAT)', flag: '🇬🇧' },
    { id: 'UAE', label: 'United Arab Emirates (5% VAT)', flag: '🇦🇪' },
  ];

  return (
    <header className="h-16 bg-white border-b border-slate-200 px-6 flex items-center justify-between sticky top-0 z-30 shadow-xs">
      {/* Zone 1: Breadcrumb & View Info */}
      <div className="flex items-center gap-4 min-w-0">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-blue-600 text-white flex items-center justify-center font-bold text-sm shadow-xs">
            LP
          </div>
          <div className="hidden sm:block">
            <div className="flex items-center gap-1.5 text-xs text-slate-500 font-medium">
              <span className="truncate max-w-[160px]">{settings.businessName}</span>
              <span aria-hidden="true">/</span>
              <span className="text-slate-800 font-semibold">{getViewTitle()}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Zone 2: Multi-Currency & Regional Compliance Selector */}
      <div className="flex items-center gap-3">
        {/* Jurisdiction Switcher */}
        <div className="relative">
          <button
            onClick={() => {
              setIsJurisdictionMenuOpen(!isJurisdictionMenuOpen);
              setIsCurrencyMenuOpen(false);
              setIsQuickMenuOpen(false);
            }}
            className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium text-slate-700 bg-slate-50 hover:bg-slate-100 rounded-md border border-slate-200 transition-colors"
            title="Active Tax Jurisdiction"
          >
            <Globe className="w-3.5 h-3.5 text-slate-500" />
            <span className="hidden md:inline">
              {jurisdictions.find(j => j.id === settings.jurisdiction)?.label || 'Tax Compliance'}
            </span>
            <span className="md:hidden">
              {jurisdictions.find(j => j.id === settings.jurisdiction)?.flag}
            </span>
            <ChevronDown className="w-3 h-3 text-slate-400" />
          </button>

          {isJurisdictionMenuOpen && (
            <div className="absolute right-0 mt-1.5 w-64 bg-white rounded-lg shadow-lg border border-slate-200 py-1.5 z-50 text-xs">
              <div className="px-3 py-1 text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                Select Compliance Region
              </div>
              {jurisdictions.map(j => (
                <button
                  key={j.id}
                  onClick={() => {
                    setJurisdiction(j.id);
                    setIsJurisdictionMenuOpen(false);
                  }}
                  className={`w-full flex items-center justify-between px-3 py-2 text-left hover:bg-slate-50 transition-colors ${
                    settings.jurisdiction === j.id ? 'text-blue-600 font-semibold bg-blue-50/50' : 'text-slate-700'
                  }`}
                >
                  <span className="flex items-center gap-2">
                    <span>{j.flag}</span>
                    <span>{j.label}</span>
                  </span>
                  {settings.jurisdiction === j.id && <Check className="w-3.5 h-3.5 text-blue-600" />}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Currency Switcher */}
        <div className="relative">
          <button
            onClick={() => {
              setIsCurrencyMenuOpen(!isCurrencyMenuOpen);
              setIsJurisdictionMenuOpen(false);
              setIsQuickMenuOpen(false);
            }}
            className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium text-slate-700 bg-slate-50 hover:bg-slate-100 rounded-md border border-slate-200 transition-colors"
          >
            <span className="font-mono font-semibold text-blue-600">{selectedDisplayCurrency}</span>
            <ChevronDown className="w-3 h-3 text-slate-400" />
          </button>

          {isCurrencyMenuOpen && (
            <div className="absolute right-0 mt-1.5 w-56 bg-white rounded-lg shadow-lg border border-slate-200 py-1.5 z-50 text-xs">
              <div className="px-3 py-1 flex items-center justify-between border-b border-slate-100 pb-1.5 mb-1">
                <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">Display Currency</span>
                <button
                  onClick={handleSyncFx}
                  disabled={isFxSyncing}
                  className="text-[11px] text-blue-600 hover:text-blue-700 font-medium flex items-center gap-1"
                >
                  <RefreshCw className={`w-3 h-3 ${isFxSyncing ? 'animate-spin' : ''}`} />
                  <span>Sync Rates</span>
                </button>
              </div>
              <div className="max-h-60 overflow-y-auto">
                {currencies.map(cur => (
                  <button
                    key={cur.code}
                    onClick={() => {
                      setDisplayCurrency(cur.code);
                      setIsCurrencyMenuOpen(false);
                    }}
                    className={`w-full flex items-center justify-between px-3 py-2 text-left hover:bg-slate-50 transition-colors ${
                      selectedDisplayCurrency === cur.code ? 'text-blue-600 font-semibold bg-blue-50/50' : 'text-slate-700'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <span className="font-mono font-bold w-6">{cur.symbol}</span>
                      <span>{cur.name} ({cur.code})</span>
                    </div>
                    {selectedDisplayCurrency === cur.code && <Check className="w-3.5 h-3.5 text-blue-600" />}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Bank Live Sync Button */}
        <button
          onClick={syncBankFeeds}
          disabled={isSyncingBank}
          className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-600 bg-white hover:bg-slate-50 border border-slate-200 rounded-md transition-colors"
          title="Simulate Real-time Open Banking Feed Synchronization"
        >
          <RefreshCw className={`w-3.5 h-3.5 text-slate-500 ${isSyncingBank ? 'animate-spin text-blue-600' : ''}`} />
          <span>{isSyncingBank ? 'Syncing...' : 'Sync Bank'}</span>
        </button>

        {/* Zone 3: Quick Action Create (+) Button */}
        <div className="relative">
          <button
            onClick={() => {
              setIsQuickMenuOpen(!isQuickMenuOpen);
              setIsCurrencyMenuOpen(false);
              setIsJurisdictionMenuOpen(false);
            }}
            className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 active:bg-blue-800 rounded-md shadow-xs transition-colors shrink-0"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>New</span>
            <ChevronDown className="w-3 h-3 text-blue-200" />
          </button>

          {isQuickMenuOpen && (
            <div className="absolute right-0 mt-1.5 w-60 bg-white rounded-lg shadow-xl border border-slate-200 py-1.5 z-50 text-xs">
              <div className="px-3.5 py-1 text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                Sales Transactions
              </div>
              <button
                onClick={() => {
                  onOpenCreateInvoice();
                  setIsQuickMenuOpen(false);
                }}
                className="w-full flex items-center gap-2.5 px-3.5 py-1.5 text-left text-slate-700 hover:bg-slate-50 transition-colors"
              >
                <FileText className="w-4 h-4 text-blue-600 shrink-0" />
                <div>
                  <div className="font-medium">New Tax Invoice</div>
                  <div className="text-[10px] text-slate-400">Sales & Accounts Receivable</div>
                </div>
              </button>

              {onOpenCreateEstimate && (
                <button
                  onClick={() => {
                    onOpenCreateEstimate();
                    setIsQuickMenuOpen(false);
                  }}
                  className="w-full flex items-center gap-2.5 px-3.5 py-1.5 text-left text-slate-700 hover:bg-slate-50 transition-colors"
                >
                  <FileCheck2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  <div>
                    <div className="font-medium">New Sales Estimate</div>
                    <div className="text-[10px] text-slate-400">Proposal & Quotation</div>
                  </div>
                </button>
              )}

              {onOpenCreateOrder && (
                <button
                  onClick={() => {
                    onOpenCreateOrder();
                    setIsQuickMenuOpen(false);
                  }}
                  className="w-full flex items-center gap-2.5 px-3.5 py-1.5 text-left text-slate-700 hover:bg-slate-50 transition-colors"
                >
                  <ShoppingCart className="w-4 h-4 text-indigo-600 shrink-0" />
                  <div>
                    <div className="font-medium">New Sales Order</div>
                    <div className="text-[10px] text-slate-400">Confirmed Customer Order</div>
                  </div>
                </button>
              )}

              <div className="h-px bg-slate-100 my-1" />

              <div className="px-3.5 py-1 text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                Purchases & Expenses
              </div>
              <button
                onClick={() => {
                  onOpenCreateBill();
                  setIsQuickMenuOpen(false);
                }}
                className="w-full flex items-center gap-2.5 px-3.5 py-1.5 text-left text-slate-700 hover:bg-slate-50 transition-colors"
              >
                <Receipt className="w-4 h-4 text-amber-600 shrink-0" />
                <div>
                  <div className="font-medium">New Vendor Bill</div>
                  <div className="text-[10px] text-slate-400">Purchases & TDS deduction</div>
                </div>
              </button>

              {onOpenCreatePO && (
                <button
                  onClick={() => {
                    onOpenCreatePO();
                    setIsQuickMenuOpen(false);
                  }}
                  className="w-full flex items-center gap-2.5 px-3.5 py-1.5 text-left text-slate-700 hover:bg-slate-50 transition-colors"
                >
                  <Package className="w-4 h-4 text-violet-600 shrink-0" />
                  <div>
                    <div className="font-medium">New Purchase Order</div>
                    <div className="text-[10px] text-slate-400">Procurement & Supplier PO</div>
                  </div>
                </button>
              )}

              {onOpenCreateExpense && (
                <button
                  onClick={() => {
                    onOpenCreateExpense();
                    setIsQuickMenuOpen(false);
                  }}
                  className="w-full flex items-center gap-2.5 px-3.5 py-1.5 text-left text-slate-700 hover:bg-slate-50 transition-colors"
                >
                  <Wallet className="w-4 h-4 text-teal-600 shrink-0" />
                  <div>
                    <div className="font-medium">Record Direct Expense</div>
                    <div className="text-[10px] text-slate-400">Cash / Card Outflow</div>
                  </div>
                </button>
              )}

              <div className="h-px bg-slate-100 my-1" />

              <div className="px-3.5 py-1 text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                Contacts
              </div>
              <button
                onClick={() => {
                  onOpenAddCustomer();
                  setIsQuickMenuOpen(false);
                }}
                className="w-full flex items-center gap-2.5 px-3.5 py-1.5 text-left text-slate-700 hover:bg-slate-50 transition-colors"
              >
                <UserPlus className="w-4 h-4 text-emerald-600 shrink-0" />
                <span className="font-medium">Add Customer</span>
              </button>

              <button
                onClick={() => {
                  onOpenAddVendor();
                  setIsQuickMenuOpen(false);
                }}
                className="w-full flex items-center gap-2.5 px-3.5 py-1.5 text-left text-slate-700 hover:bg-slate-50 transition-colors"
              >
                <Building2 className="w-4 h-4 text-purple-600 shrink-0" />
                <span className="font-medium">Add Vendor</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};
