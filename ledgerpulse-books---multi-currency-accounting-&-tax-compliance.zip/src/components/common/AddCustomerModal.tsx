import React, { useState, useEffect } from 'react';
import { useAccounting } from '../../context/AccountingContext';
import { X, UserPlus, CheckCircle2, AlertCircle, ShieldCheck } from 'lucide-react';
import { Customer, CurrencyCode } from '../../types';
import { INDIAN_GST_STATES, verifyGSTIN, validateAndDerivePAN } from '../../utils/gstHelper';

interface AddCustomerModalProps {
  isOpen: boolean;
  onClose: () => void;
  customerToEdit?: Customer | null;
}

export const AddCustomerModal: React.FC<AddCustomerModalProps> = ({
  isOpen,
  onClose,
  customerToEdit,
}) => {
  const { addCustomer, updateCustomer, currencies } = useAccounting();

  const [name, setName] = useState('');
  const [companyName, setCompanyName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [currency, setCurrency] = useState<CurrencyCode>('INR');
  const [taxId, setTaxId] = useState('');
  const [pan, setPan] = useState('');
  const [placeOfSupply, setPlaceOfSupply] = useState('27-Maharashtra');
  const [billingAddress, setBillingAddress] = useState('');
  const [pincode, setPincode] = useState('');
  const [paymentTermsDays, setPaymentTermsDays] = useState(30);

  // Sync state if editing
  useEffect(() => {
    if (customerToEdit) {
      setName(customerToEdit.name);
      setCompanyName(customerToEdit.companyName);
      setEmail(customerToEdit.email);
      setPhone(customerToEdit.phone);
      setCurrency(customerToEdit.currency);
      setTaxId(customerToEdit.taxId === 'UNREGISTERED' ? '' : customerToEdit.taxId);
      setPan(customerToEdit.pan || '');
      setPlaceOfSupply(customerToEdit.placeOfSupply || '27-Maharashtra');
      setBillingAddress(customerToEdit.billingAddress);
      setPincode(customerToEdit.pincode || '');
      setPaymentTermsDays(customerToEdit.paymentTermsDays);
    } else {
      setName('');
      setCompanyName('');
      setEmail('');
      setPhone('');
      setCurrency('INR');
      setTaxId('');
      setPan('');
      setPlaceOfSupply('27-Maharashtra');
      setBillingAddress('');
      setPincode('');
      setPaymentTermsDays(30);
    }
  }, [customerToEdit, isOpen]);

  // Automated GST Verification & PAN Linkage
  const gstVerification = verifyGSTIN(taxId);
  const panValidation = validateAndDerivePAN(pan, taxId);

  // Auto-fill Place of Supply and PAN when GST is verified
  const handleTaxIdChange = (val: string) => {
    const uppercaseVal = val.toUpperCase().trim();
    setTaxId(uppercaseVal);

    if (uppercaseVal.length >= 2) {
      const stateCode = uppercaseVal.slice(0, 2);
      const matched = INDIAN_GST_STATES.find(s => s.code === stateCode);
      if (matched) {
        setPlaceOfSupply(matched.label);
      }
    }

    if (uppercaseVal.length >= 12) {
      const extractedPan = uppercaseVal.slice(2, 12);
      setPan(extractedPan);
    }
  };

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const customerData = {
      name,
      companyName,
      email,
      phone,
      currency,
      taxId: taxId || 'UNREGISTERED',
      pan: pan || (taxId.length >= 12 ? taxId.slice(2, 12) : undefined),
      placeOfSupply,
      billingAddress,
      pincode,
      paymentTermsDays
    };

    if (customerToEdit) {
      updateCustomer(customerToEdit.id, customerData);
    } else {
      addCustomer(customerData);
    }

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="bg-white w-full max-w-xl rounded-2xl shadow-2xl border border-slate-200 overflow-hidden my-6 animate-in fade-in zoom-in-95">
        <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-blue-600/30 text-blue-400 flex items-center justify-center font-bold">
              <UserPlus className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold tracking-tight">
                {customerToEdit ? 'Edit Customer Account' : 'Add New Customer'}
              </h3>
              <p className="text-xs text-slate-400">Client details, GSTIN verification, and billing address</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-700 font-semibold mb-1">Company / Entity Name <span className="text-rose-500">*</span></label>
              <input
                type="text"
                value={companyName}
                onChange={e => setCompanyName(e.target.value)}
                placeholder="Apex Technologies Pvt Ltd"
                className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-slate-800 focus:bg-white focus:border-blue-500 focus:outline-none"
                required
              />
            </div>
            <div>
              <label className="block text-slate-700 font-semibold mb-1">Contact Person <span className="text-rose-500">*</span></label>
              <input
                type="text"
                value={name}
                onChange={e => setName(e.target.value)}
                placeholder="Rohan Sharma"
                className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-slate-800 focus:bg-white focus:border-blue-500 focus:outline-none"
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-700 font-semibold mb-1">Email Address <span className="text-rose-500">*</span></label>
              <input
                type="email"
                value={email}
                onChange={e => setEmail(e.target.value)}
                placeholder="billing@company.com"
                className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-slate-800 focus:bg-white focus:border-blue-500 focus:outline-none"
                required
              />
            </div>
            <div>
              <label className="block text-slate-700 font-semibold mb-1">Phone Number</label>
              <input
                type="text"
                value={phone}
                onChange={e => setPhone(e.target.value)}
                placeholder="+91 98200 11223"
                className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-slate-800 focus:bg-white focus:border-blue-500 focus:outline-none font-mono"
              />
            </div>
          </div>

          {/* Place of Supply Dropdown & Currency */}
          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="block text-slate-700 font-semibold mb-1">Currency</label>
              <select
                value={currency}
                onChange={e => setCurrency(e.target.value as CurrencyCode)}
                className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 font-mono text-slate-800 focus:bg-white focus:border-blue-500 focus:outline-none"
              >
                {currencies.map(c => (
                  <option key={c.code} value={c.code}>{c.code} - {c.symbol}</option>
                ))}
              </select>
            </div>
            <div className="col-span-2">
              <label className="block text-slate-700 font-semibold mb-1">
                Place of Supply (State & Code Dropdown) <span className="text-rose-500">*</span>
              </label>
              <select
                value={placeOfSupply}
                onChange={e => setPlaceOfSupply(e.target.value)}
                className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-slate-800 font-medium focus:bg-white focus:border-blue-500 focus:outline-none"
                required
              >
                {INDIAN_GST_STATES.map(s => (
                  <option key={s.code} value={s.label}>
                    {s.label}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* GSTIN and PAN with Automated Verification */}
          <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
            <div className="flex items-center justify-between">
              <span className="font-semibold text-slate-800 flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-blue-600" />
                <span>GST & Tax Registration (Auto-Verified)</span>
              </span>
              <span className="text-[11px] text-slate-500">15-digit Indian GSTIN</span>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-slate-700 font-medium mb-1">
                  GST Number (GSTIN)
                </label>
                <input
                  type="text"
                  maxLength={15}
                  value={taxId}
                  onChange={e => handleTaxIdChange(e.target.value)}
                  placeholder="27AABCA1234F1Z8"
                  className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 font-mono uppercase text-slate-900 tracking-wider focus:border-blue-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-medium mb-1">
                  PAN (Permanent Account Number)
                </label>
                <input
                  type="text"
                  maxLength={10}
                  value={pan}
                  onChange={e => setPan(e.target.value.toUpperCase().trim())}
                  placeholder="AABCA1234F"
                  className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 font-mono uppercase text-slate-900 tracking-wider focus:border-blue-500 focus:outline-none"
                />
              </div>
            </div>

            {/* Verification Status Badges */}
            {taxId && (
              <div className="pt-1">
                {gstVerification.isValid ? (
                  <div className="flex items-center gap-2 p-2 bg-emerald-50 text-emerald-800 border border-emerald-200 rounded-lg text-[11px]">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                    <div>
                      <span className="font-semibold">Active & Valid GSTIN:</span> {gstVerification.message}
                      <span className="ml-1 text-emerald-600 font-mono">({gstVerification.stateName} • State Code {gstVerification.stateCode})</span>
                    </div>
                  </div>
                ) : (
                  <div className="flex items-center gap-2 p-2 bg-amber-50 text-amber-800 border border-amber-200 rounded-lg text-[11px]">
                    <AlertCircle className="w-4 h-4 text-amber-600 shrink-0" />
                    <span>{gstVerification.message}</span>
                  </div>
                )}
              </div>
            )}

            {pan && (
              <div className="text-[11px]">
                {panValidation.isValid ? (
                  <div className="text-emerald-700 flex items-center gap-1.5 font-medium">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>{panValidation.message}</span>
                  </div>
                ) : (
                  <div className="text-rose-600 flex items-center gap-1.5 font-medium">
                    <AlertCircle className="w-3.5 h-3.5" />
                    <span>{panValidation.message}</span>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Billing Address and Pincode Box */}
          <div className="space-y-2">
            <div className="grid grid-cols-3 gap-3">
              <div className="col-span-2">
                <label className="block text-slate-700 font-semibold mb-1">Billing Street Address</label>
                <input
                  type="text"
                  value={billingAddress}
                  onChange={e => setBillingAddress(e.target.value)}
                  placeholder="Plot 14, MIDC Tech Park, Andheri East"
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-slate-800 focus:bg-white focus:border-blue-500 focus:outline-none"
                  required
                />
              </div>
              <div>
                <label className="block text-slate-700 font-semibold mb-1">
                  Pincode (Postal Code) <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  maxLength={6}
                  value={pincode}
                  onChange={e => setPincode(e.target.value.replace(/\D/g, ''))}
                  placeholder="400069"
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 font-mono text-slate-800 focus:bg-white focus:border-blue-500 focus:outline-none"
                  required
                />
              </div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-700 font-semibold mb-1">Payment Credit Terms</label>
              <select
                value={paymentTermsDays}
                onChange={e => setPaymentTermsDays(Number(e.target.value))}
                className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-slate-800 focus:bg-white focus:border-blue-500 focus:outline-none"
              >
                <option value={0}>Immediate / Due on Receipt</option>
                <option value={15}>Net 15 Days</option>
                <option value={30}>Net 30 Days (Standard)</option>
                <option value={45}>Net 45 Days</option>
                <option value={60}>Net 60 Days</option>
              </select>
            </div>
          </div>

          <div className="pt-3 flex items-center justify-end gap-2 border-t border-slate-200">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs transition-colors"
            >
              {customerToEdit ? 'Save Changes' : 'Create Customer'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
