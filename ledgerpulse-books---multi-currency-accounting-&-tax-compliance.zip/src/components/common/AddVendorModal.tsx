import React, { useState, useEffect } from 'react';
import { useAccounting } from '../../context/AccountingContext';
import { X, Building2, CheckCircle2, AlertCircle, ShieldCheck } from 'lucide-react';
import { CurrencyCode, TDSRate, Vendor } from '../../types';
import { INDIAN_GST_STATES, verifyGSTIN, validateAndDerivePAN } from '../../utils/gstHelper';

interface AddVendorModalProps {
  isOpen: boolean;
  onClose: () => void;
  vendorToEdit?: Vendor | null;
}

export const AddVendorModal: React.FC<AddVendorModalProps> = ({
  isOpen,
  onClose,
  vendorToEdit,
}) => {
  const { addVendor, updateVendor, tdsRates, currencies } = useAccounting();

  const [name, setName] = useState('');
  const [companyName, setCompanyName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [currency, setCurrency] = useState<CurrencyCode>('INR');
  const [taxId, setTaxId] = useState('');
  const [pan, setPan] = useState('');
  const [placeOfSupply, setPlaceOfSupply] = useState('27-Maharashtra');
  const [category, setCategory] = useState('Engineering Consultants');
  const [defaultTdsSection, setDefaultTdsSection] = useState<TDSRate['section']>('194J_TECH');
  const [bankName, setBankName] = useState('HDFC Bank');
  const [accountNumber, setAccountNumber] = useState('');
  const [ifsc, setIfsc] = useState('');
  const [address, setAddress] = useState('');
  const [pincode, setPincode] = useState('');

  // Sync state if editing
  useEffect(() => {
    if (vendorToEdit) {
      setName(vendorToEdit.name);
      setCompanyName(vendorToEdit.companyName);
      setEmail(vendorToEdit.email);
      setPhone(vendorToEdit.phone);
      setCurrency(vendorToEdit.currency);
      setTaxId(vendorToEdit.taxId === 'UNREGISTERED' ? '' : vendorToEdit.taxId);
      setPan(vendorToEdit.pan || '');
      setPlaceOfSupply(vendorToEdit.placeOfSupply || '27-Maharashtra');
      setCategory(vendorToEdit.category);
      setDefaultTdsSection(vendorToEdit.defaultTdsSection || '194J_TECH');
      setBankName(vendorToEdit.bankAccount.bankName);
      setAccountNumber(vendorToEdit.bankAccount.accountNumber);
      setIfsc(vendorToEdit.bankAccount.ifscOrRouting);
      setAddress(vendorToEdit.address);
      setPincode(vendorToEdit.pincode || '');
    } else {
      setName('');
      setCompanyName('');
      setEmail('');
      setPhone('');
      setCurrency('INR');
      setTaxId('');
      setPan('');
      setPlaceOfSupply('27-Maharashtra');
      setCategory('Engineering Consultants');
      setDefaultTdsSection('194J_TECH');
      setBankName('HDFC Bank');
      setAccountNumber('');
      setIfsc('');
      setAddress('');
      setPincode('');
    }
  }, [vendorToEdit, isOpen]);

  // Automated GST & PAN verification
  const gstVerification = verifyGSTIN(taxId);
  const panValidation = validateAndDerivePAN(pan, taxId);

  const handleTaxIdChange = (val: string) => {
    const uppercaseVal = val.toUpperCase().trim();
    setTaxId(uppercaseVal);

    if (uppercaseVal.length >= 2) {
      const stateCode = uppercaseVal.slice(0, 2);
      const matched = INDIAN_GST_STATES.find(s => s.code === stateCode);
      if (matched) {
        setPlaceOfSupply(matched.label);
      }
    }

    if (uppercaseVal.length >= 12) {
      const extractedPan = uppercaseVal.slice(2, 12);
      setPan(extractedPan);
    }
  };

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const vendorData = {
      name,
      companyName,
      email,
      phone,
      currency,
      taxId: taxId || 'UNREGISTERED',
      pan: pan || (taxId.length >= 12 ? taxId.slice(2, 12) : 'PANNOTREQ'),
      placeOfSupply,
      category,
      defaultTdsSection,
      bankAccount: {
        bankName,
        accountNumber,
        ifscOrRouting: ifsc
      },
      address,
      pincode
    };

    if (vendorToEdit) {
      updateVendor(vendorToEdit.id, vendorData);
    } else {
      addVendor(vendorData);
    }

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="bg-white w-full max-w-xl rounded-2xl shadow-2xl border border-slate-200 overflow-hidden my-6 animate-in fade-in zoom-in-95">
        <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-purple-600/30 text-purple-400 flex items-center justify-center font-bold">
              <Building2 className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold tracking-tight">
                {vendorToEdit ? 'Edit Vendor / Supplier' : 'Add New Vendor / Supplier'}
              </h3>
              <p className="text-xs text-slate-400">Configure vendor with GSTIN verification and default TDS section</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-700 font-semibold mb-1">Company / Vendor Name <span className="text-rose-500">*</span></label>
              <input
                type="text"
                value={companyName}
                onChange={e => setCompanyName(e.target.value)}
                placeholder="CloudCore Systems LLP"
                className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-slate-800 focus:bg-white focus:border-purple-500 focus:outline-none"
                required
              />
            </div>
            <div>
              <label className="block text-slate-700 font-semibold mb-1">Contact Person <span className="text-rose-500">*</span></label>
              <input
                type="text"
                value={name}
                onChange={e => setName(e.target.value)}
                placeholder="Pooja Mehta"
                className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-slate-800 focus:bg-white focus:border-purple-500 focus:outline-none"
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-700 font-semibold mb-1">Email <span className="text-rose-500">*</span></label>
              <input
                type="email"
                value={email}
                onChange={e => setEmail(e.target.value)}
                placeholder="accounts@cloudcore.com"
                className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-slate-800 focus:bg-white focus:border-purple-500 focus:outline-none"
                required
              />
            </div>
            <div>
              <label className="block text-slate-700 font-semibold mb-1">Expense Category</label>
              <select
                value={category}
                onChange={e => setCategory(e.target.value)}
                className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-slate-800 focus:bg-white focus:border-purple-500 focus:outline-none"
              >
                <option value="Hosting & Cloud Infrastructure">Hosting & Cloud Infrastructure</option>
                <option value="Engineering Consultants">Engineering Consultants</option>
                <option value="Office Rent & Facilities">Office Rent & Facilities</option>
                <option value="Shipping & Freight">Shipping & Freight</option>
                <option value="Legal & Professional Fees">Legal & Professional Fees</option>
                <option value="Raw Materials & Inventory">Raw Materials & Inventory</option>
              </select>
            </div>
          </div>

          {/* Place of Supply Dropdown & Currency */}
          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="block text-slate-700 font-semibold mb-1">Currency</label>
              <select
                value={currency}
                onChange={e => setCurrency(e.target.value as CurrencyCode)}
                className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 font-mono text-slate-800 focus:bg-white focus:border-purple-500 focus:outline-none"
              >
                {currencies.map(c => (
                  <option key={c.code} value={c.code}>{c.code} - {c.symbol}</option>
                ))}
              </select>
            </div>
            <div className="col-span-2">
              <label className="block text-slate-700 font-semibold mb-1">
                Place of Supply (State & Code Dropdown) <span className="text-rose-500">*</span>
              </label>
              <select
                value={placeOfSupply}
                onChange={e => setPlaceOfSupply(e.target.value)}
                className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-slate-800 font-medium focus:bg-white focus:border-purple-500 focus:outline-none"
                required
              >
                {INDIAN_GST_STATES.map(s => (
                  <option key={s.code} value={s.label}>
                    {s.label}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* GSTIN and PAN with Automated Verification */}
          <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
            <div className="flex items-center justify-between">
              <span className="font-semibold text-slate-800 flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-purple-600" />
                <span>GST & PAN Compliance (Auto-Verified)</span>
              </span>
              <span className="text-[11px] text-slate-500">Auto-derives PAN</span>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-slate-700 font-medium mb-1">
                  Vendor GST Number (GSTIN)
                </label>
                <input
                  type="text"
                  maxLength={15}
                  value={taxId}
                  onChange={e => handleTaxIdChange(e.target.value)}
                  placeholder="27AABCP1234F1Z8"
                  className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 font-mono uppercase text-slate-900 tracking-wider focus:border-purple-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-medium mb-1">
                  PAN (Income Tax Permanent Account) <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  maxLength={10}
                  value={pan}
                  onChange={e => setPan(e.target.value.toUpperCase().trim())}
                  placeholder="AABCP1234F"
                  className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 font-mono uppercase text-slate-900 tracking-wider focus:border-purple-500 focus:outline-none"
                  required
                />
              </div>
            </div>

            {/* Verification status feedback */}
            {taxId && (
              <div className="pt-1">
                {gstVerification.isValid ? (
                  <div className="flex items-center gap-2 p-2 bg-emerald-50 text-emerald-800 border border-emerald-200 rounded-lg text-[11px]">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                    <div>
                      <span className="font-semibold">Active & Valid GSTIN:</span> {gstVerification.message}
                      <span className="ml-1 text-emerald-600 font-mono">({gstVerification.stateName} • Code {gstVerification.stateCode})</span>
                    </div>
                  </div>
                ) : (
                  <div className="flex items-center gap-2 p-2 bg-amber-50 text-amber-800 border border-amber-200 rounded-lg text-[11px]">
                    <AlertCircle className="w-4 h-4 text-amber-600 shrink-0" />
                    <span>{gstVerification.message}</span>
                  </div>
                )}
              </div>
            )}

            {pan && (
              <div className="text-[11px]">
                {panValidation.isValid ? (
                  <div className="text-emerald-700 flex items-center gap-1.5 font-medium">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>{panValidation.message}</span>
                  </div>
                ) : (
                  <div className="text-rose-600 flex items-center gap-1.5 font-medium">
                    <AlertCircle className="w-3.5 h-3.5" />
                    <span>{panValidation.message}</span>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Default TDS Section */}
          <div>
            <label className="block text-slate-700 font-semibold mb-1">Default Statutory TDS Section</label>
            <select
              value={defaultTdsSection}
              onChange={e => setDefaultTdsSection(e.target.value as any)}
              className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-slate-800 focus:bg-white focus:border-purple-500 focus:outline-none"
            >
              {tdsRates.map(r => (
                <option key={r.section} value={r.section}>
                  {r.code} - {r.label} ({r.rate}%)
                </option>
              ))}
            </select>
          </div>

          {/* Billing Address and Pincode Box */}
          <div className="space-y-2">
            <div className="grid grid-cols-3 gap-3">
              <div className="col-span-2">
                <label className="block text-slate-700 font-semibold mb-1">Vendor Address</label>
                <input
                  type="text"
                  value={address}
                  onChange={e => setAddress(e.target.value)}
                  placeholder="Plot 45, Industrial Zone, New Delhi"
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-slate-800 focus:bg-white focus:border-purple-500 focus:outline-none"
                  required
                />
              </div>
              <div>
                <label className="block text-slate-700 font-semibold mb-1">
                  Pincode (Postal Code) <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  maxLength={6}
                  value={pincode}
                  onChange={e => setPincode(e.target.value.replace(/\D/g, ''))}
                  placeholder="110020"
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 font-mono text-slate-800 focus:bg-white focus:border-purple-500 focus:outline-none"
                  required
                />
              </div>
            </div>
          </div>

          {/* Bank Account Details */}
          <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-2">
            <div className="font-semibold text-slate-800 text-[11px]">Vendor Bank Details (For Bill Remittance)</div>
            <div className="grid grid-cols-3 gap-3">
              <div>
                <label className="block text-slate-600 text-[10px] uppercase font-semibold mb-1">Bank Name</label>
                <input
                  type="text"
                  value={bankName}
                  onChange={e => setBankName(e.target.value)}
                  placeholder="HDFC Bank"
                  className="w-full bg-white border border-slate-300 rounded-lg px-2.5 py-1.5"
                />
              </div>
              <div>
                <label className="block text-slate-600 text-[10px] uppercase font-semibold mb-1">Account Number</label>
                <input
                  type="text"
                  value={accountNumber}
                  onChange={e => setAccountNumber(e.target.value)}
                  placeholder="5010049281729"
                  className="w-full bg-white border border-slate-300 rounded-lg px-2.5 py-1.5 font-mono"
                />
              </div>
              <div>
                <label className="block text-slate-600 text-[10px] uppercase font-semibold mb-1">IFSC / Code</label>
                <input
                  type="text"
                  value={ifsc}
                  onChange={e => setIfsc(e.target.value.toUpperCase())}
                  placeholder="HDFC0000060"
                  className="w-full bg-white border border-slate-300 rounded-lg px-2.5 py-1.5 font-mono uppercase"
                />
              </div>
            </div>
          </div>

          <div className="pt-2 flex items-center justify-end gap-2 border-t border-slate-200">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 text-xs font-semibold text-white bg-purple-600 hover:bg-purple-700 rounded-lg shadow-xs transition-colors"
            >
              {vendorToEdit ? 'Save Changes' : 'Create Vendor'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
