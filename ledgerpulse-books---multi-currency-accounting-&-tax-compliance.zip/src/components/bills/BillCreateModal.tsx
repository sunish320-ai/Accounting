import React, { useState } from 'react';
import { useAccounting } from '../../context/AccountingContext';
import { X, Plus, Trash2, ShieldCheck, Info } from 'lucide-react';
import { BillLineItem, TDSRate, CurrencyCode } from '../../types';

interface BillCreateModalProps {
  isOpen: boolean;
  onClose: () => void;
  preselectedVendorId?: string;
}

export const BillCreateModal: React.FC<BillCreateModalProps> = ({
  isOpen,
  onClose,
  preselectedVendorId,
}) => {
  const {
    vendors,
    tdsRates,
    taxRates,
    currencies,
    settings,
    createBill,
    formatMoney
  } = useAccounting();

  if (!isOpen) return null;

  const [selectedVendorId, setSelectedVendorId] = useState(
    preselectedVendorId || vendors[0]?.id || ''
  );
  const currentVendor = vendors.find(v => v.id === selectedVendorId) || vendors[0];

  const [billNumber, setBillNumber] = useState(`BILL-${Date.now().toString().slice(-5)}`);
  const [billDate, setBillDate] = useState(new Date().toISOString().split('T')[0]);
  
  const defaultDueDate = new Date();
  defaultDueDate.setDate(defaultDueDate.getDate() + 30);
  const [dueDate, setDueDate] = useState(defaultDueDate.toISOString().split('T')[0]);

  const [category, setCategory] = useState(currentVendor?.category || 'Hosting & Cloud Infrastructure');
  const [currency, setCurrency] = useState<CurrencyCode>(currentVendor?.currency || 'INR');

  // TDS configuration for vendor bill
  const [hasTds, setHasTds] = useState(true);
  const [selectedTdsSection, setSelectedTdsSection] = useState<TDSRate['section']>(
    currentVendor?.defaultTdsSection || '194J_TECH'
  );

  const activeTdsRateObj = tdsRates.find(r => r.section === selectedTdsSection);
  const tdsRatePercent = activeTdsRateObj ? activeTdsRateObj.rate : 2;

  // Line items state
  const [items, setItems] = useState<BillLineItem[]>([
    {
      id: `bitem-${Date.now()}-1`,
      description: 'Monthly Cloud Infrastructure & Server Compute Fees',
      category: 'Hosting & Cloud Infrastructure',
      hsnSac: '998315',
      quantity: 1,
      unitRate: 85000,
      taxRateId: 'tax-gst-18',
      amount: 85000,
      taxAmount: 15300
    }
  ]);

  const updateRow = (index: number, updates: Partial<BillLineItem>) => {
    setItems(prev => {
      const next = [...prev];
      const item = { ...next[index], ...updates };

      const sub = (item.quantity || 0) * (item.unitRate || 0);
      const taxRateObj = taxRates.find(t => t.id === item.taxRateId);
      const taxPct = taxRateObj ? taxRateObj.rate : 0;
      const taxAmount = sub * (taxPct / 100);

      next[index] = {
        ...item,
        amount: sub,
        taxAmount
      };
      return next;
    });
  };

  const addRow = () => {
    setItems([
      ...items,
      {
        id: `bitem-${Date.now()}-${items.length}`,
        description: '',
        category,
        hsnSac: '998311',
        quantity: 1,
        unitRate: 0,
        taxRateId: 'tax-gst-18',
        amount: 0,
        taxAmount: 0
      }
    ]);
  };

  const removeRow = (index: number) => {
    if (items.length <= 1) return;
    setItems(items.filter((_, idx) => idx !== index));
  };

  // Calculations
  const subtotal = items.reduce((sum, item) => sum + item.amount, 0);
  const taxAmount = items.reduce((sum, item) => sum + item.taxAmount, 0);
  const grossAmount = subtotal + taxAmount;

  // TDS is deducted on Subtotal (exclusive of GST under Indian CBDT circulars)
  const tdsAmount = hasTds ? Math.round(subtotal * (tdsRatePercent / 100)) : 0;
  const netPayable = grossAmount - tdsAmount;

  const curObj = currencies.find(c => c.code === currency) || { exchangeRateToBase: 1 };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentVendor) return;

    createBill({
      billNumber,
      vendorId: currentVendor.id,
      vendorName: currentVendor.companyName,
      vendorTaxId: currentVendor.taxId,
      vendorPan: currentVendor.pan,
      billDate,
      dueDate,
      status: 'approved',
      currency,
      exchangeRate: curObj.exchangeRateToBase,
      items,
      subtotal,
      taxAmount,
      grossAmount,
      tdsSection: hasTds ? selectedTdsSection : undefined,
      tdsRatePercent: hasTds ? tdsRatePercent : 0,
      tdsAmount,
      paidAmount: 0,
      notes: `Booked bill for ${category} with Sec ${selectedTdsSection} withholding.`,
      category
    });

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="bg-white w-full max-w-3xl rounded-2xl shadow-2xl border border-slate-200 overflow-hidden my-6 animate-in fade-in zoom-in-95">
        <div className="px-6 py-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
          <div>
            <h2 className="text-sm font-bold text-slate-900">Record Vendor Bill & TDS Deduction</h2>
            <p className="text-xs text-slate-500">
              Calculate Input Tax Credit (ITC) and automatic Section 194C/194J/194I tax withholding
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-200/50"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-6 max-h-[75vh] overflow-y-auto">
          {/* Vendor Details Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Vendor / Supplier <span className="text-rose-500">*</span>
              </label>
              <select
                value={selectedVendorId}
                onChange={e => {
                  setSelectedVendorId(e.target.value);
                  const v = vendors.find(vend => vend.id === e.target.value);
                  if (v) {
                    setCategory(v.category);
                    if (v.defaultTdsSection) setSelectedTdsSection(v.defaultTdsSection);
                  }
                }}
                className="w-full text-xs bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 font-medium"
              >
                {vendors.map(v => (
                  <option key={v.id} value={v.id}>
                    {v.companyName}
                  </option>
                ))}
              </select>
              {currentVendor && (
                <div className="mt-1 text-[11px] text-slate-500 font-mono">
                  PAN: {currentVendor.pan} · GSTIN: {currentVendor.taxId}
                </div>
              )}
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Vendor Bill Number <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                value={billNumber}
                onChange={e => setBillNumber(e.target.value)}
                className="w-full text-xs font-mono font-semibold bg-slate-50 border border-slate-200 rounded-lg px-3 py-2"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Expense Category
              </label>
              <select
                value={category}
                onChange={e => setCategory(e.target.value)}
                className="w-full text-xs bg-slate-50 border border-slate-200 rounded-lg px-3 py-2"
              >
                <option value="Hosting & Cloud Infrastructure">Hosting & Cloud Infrastructure</option>
                <option value="Engineering Consultants">Engineering Consultants</option>
                <option value="Office Rent & Facilities">Office Rent & Facilities</option>
                <option value="Shipping & Freight">Shipping & Freight</option>
                <option value="Payment Processing Fees">Payment Processing Fees</option>
                <option value="Legal & Professional Fees">Legal & Professional Fees</option>
              </select>
            </div>
          </div>

          {/* Dates */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Bill Date</label>
              <input
                type="date"
                value={billDate}
                onChange={e => setBillDate(e.target.value)}
                className="w-full text-xs bg-slate-50 border border-slate-200 rounded-lg px-3 py-2"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Due Date</label>
              <input
                type="date"
                value={dueDate}
                onChange={e => setDueDate(e.target.value)}
                className="w-full text-xs bg-slate-50 border border-slate-200 rounded-lg px-3 py-2"
              />
            </div>
          </div>

          {/* Line Items Table */}
          <div className="space-y-2">
            <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">Bill Items</h3>

            <div className="border border-slate-200 rounded-lg overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="bg-slate-100/75 border-b border-slate-200 text-slate-600 font-semibold">
                    <th className="py-2 px-3 w-5/12">Description</th>
                    <th className="py-2 px-2 w-20">HSN/SAC</th>
                    <th className="py-2 px-2 w-16 text-right">Qty</th>
                    <th className="py-2 px-2 w-28 text-right">Unit Rate</th>
                    <th className="py-2 px-2 w-28">GST Rate (ITC)</th>
                    <th className="py-2 px-3 w-28 text-right">Amount</th>
                    <th className="py-2 px-1 w-10 text-center"></th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {items.map((item, idx) => (
                    <tr key={item.id}>
                      <td className="py-2 px-3">
                        <input
                          type="text"
                          value={item.description}
                          onChange={e => updateRow(idx, { description: e.target.value })}
                          placeholder="Expense item description..."
                          className="w-full text-xs bg-transparent border-0 focus:ring-0 p-0 text-slate-800 font-medium"
                          required
                        />
                      </td>
                      <td className="py-2 px-2">
                        <input
                          type="text"
                          value={item.hsnSac}
                          onChange={e => updateRow(idx, { hsnSac: e.target.value })}
                          className="w-full text-xs font-mono bg-transparent border-0 focus:ring-0 p-0 text-slate-600"
                        />
                      </td>
                      <td className="py-2 px-2 text-right">
                        <input
                          type="number"
                          min="1"
                          value={item.quantity}
                          onChange={e => updateRow(idx, { quantity: Number(e.target.value) })}
                          className="w-full text-xs font-mono text-right bg-transparent border-0 focus:ring-0 p-0"
                        />
                      </td>
                      <td className="py-2 px-2 text-right">
                        <input
                          type="number"
                          min="0"
                          value={item.unitRate}
                          onChange={e => updateRow(idx, { unitRate: Number(e.target.value) })}
                          className="w-full text-xs font-mono text-right bg-transparent border-0 focus:ring-0 p-0 font-medium"
                        />
                      </td>
                      <td className="py-2 px-2">
                        <select
                          value={item.taxRateId}
                          onChange={e => updateRow(idx, { taxRateId: e.target.value })}
                          className="w-full text-[11px] bg-slate-50 border border-slate-200 rounded px-1.5 py-1 text-slate-700"
                        >
                          {taxRates.map(r => (
                            <option key={r.id} value={r.id}>
                              {r.name}
                            </option>
                          ))}
                        </select>
                      </td>
                      <td className="py-2 px-3 text-right font-mono font-bold text-slate-900 tabular-nums">
                        {formatMoney(item.amount + item.taxAmount, currency)}
                      </td>
                      <td className="py-2 px-1 text-center">
                        <button
                          type="button"
                          onClick={() => removeRow(idx)}
                          disabled={items.length <= 1}
                          className="text-slate-300 hover:text-rose-500 p-1"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <button
              type="button"
              onClick={addRow}
              className="text-xs text-blue-600 hover:text-blue-700 font-semibold flex items-center gap-1 pt-1"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Bill Item</span>
            </button>
          </div>

          {/* Regional TDS Withholding Selector */}
          <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-3">
            <div className="flex items-center justify-between">
              <label className="flex items-center gap-2 cursor-pointer font-semibold text-slate-800 text-xs">
                <input
                  type="checkbox"
                  checked={hasTds}
                  onChange={e => setHasTds(e.target.checked)}
                  className="rounded text-blue-600 focus:ring-blue-500 w-4 h-4"
                />
                <span>Withhold Regional Tax (TDS Deduction under Income Tax Act)</span>
              </label>
              <span className="text-[11px] font-mono text-blue-600 font-semibold">
                Compliance Mandatory
              </span>
            </div>

            {hasTds && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-2 border-t border-slate-200">
                <div>
                  <label className="block text-[11px] font-medium text-slate-600 mb-1">
                    Select TDS Section Code
                  </label>
                  <select
                    value={selectedTdsSection}
                    onChange={e => setSelectedTdsSection(e.target.value as any)}
                    className="w-full text-xs bg-white border border-slate-200 rounded-lg px-2.5 py-1.5 font-medium"
                  >
                    {tdsRates.map(r => (
                      <option key={r.section} value={r.section}>
                        {r.label} ({r.rate}%)
                      </option>
                    ))}
                  </select>
                </div>

                <div className="p-2.5 bg-blue-50/60 rounded-lg border border-blue-200/80 text-[11px] text-blue-900 flex items-start gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
                  <span>
                    Deducted TDS of <strong>{formatMoney(tdsAmount, currency)}</strong> will be credited to <strong>Account 2200 (TDS Payable)</strong> and remitted via Challan 281 by the 7th of next month.
                  </span>
                </div>
              </div>
            )}
          </div>

          {/* Grand Totals Summary */}
          <div className="flex justify-end pt-2">
            <div className="w-full md:w-5/12 bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-2 text-xs">
              <div className="flex justify-between text-slate-600">
                <span>Subtotal (Base Expense)</span>
                <span className="font-mono tabular-nums">{formatMoney(subtotal, currency)}</span>
              </div>

              <div className="flex justify-between text-slate-600">
                <span>GST Input Tax Credit (ITC Claimable)</span>
                <span className="font-mono tabular-nums">+{formatMoney(taxAmount, currency)}</span>
              </div>

              <div className="flex justify-between text-slate-800 font-semibold border-t border-slate-200 pt-1.5">
                <span>Gross Bill Amount</span>
                <span className="font-mono tabular-nums">{formatMoney(grossAmount, currency)}</span>
              </div>

              {hasTds && (
                <div className="flex justify-between text-blue-700 font-semibold">
                  <span>Less: TDS Deducted ({tdsRatePercent}%)</span>
                  <span className="font-mono tabular-nums">-{formatMoney(tdsAmount, currency)}</span>
                </div>
              )}

              <div className="border-t-2 border-slate-900 pt-2 flex justify-between font-extrabold text-sm text-slate-900">
                <span>Net Payable to Vendor</span>
                <span className="font-mono tabular-nums">{formatMoney(netPayable, currency)}</span>
              </div>
            </div>
          </div>

          {/* Footer Actions */}
          <div className="pt-2 flex items-center justify-end gap-2 border-t border-slate-200">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-slate-600 hover:bg-slate-100 rounded-lg"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs"
            >
              Approve & Book Bill
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
