import React, { useState, useMemo } from 'react';
import { useAccounting } from '../../context/AccountingContext';
import {
  Plus,
  Search,
  Filter,
  Receipt,
  CreditCard,
  Building,
  CheckCircle2,
  AlertCircle,
  ShieldCheck,
  Calendar,
  X,
  Edit2,
  Copy,
  Trash2,
  AlertTriangle
} from 'lucide-react';
import { BillStatus, Bill } from '../../types';

interface BillsPayableViewProps {
  onOpenCreateBill: () => void;
  selectedBillIdForPayment?: string | null;
  onEditBill?: (bill: Bill) => void;
}

export const BillsPayableView: React.FC<BillsPayableViewProps> = ({
  onOpenCreateBill,
  selectedBillIdForPayment,
  onEditBill,
}) => {
  const {
    bills,
    apAging,
    bankAccounts,
    formatMoney,
    convertAmount,
    settings,
    selectedDisplayCurrency,
    recordBillPayment,
    deleteBill,
    duplicateBill
  } = useAccounting();

  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [payModalBill, setPayModalBill] = useState<Bill | null>(null);
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);

  // Quick open if selectedBillIdForPayment was passed
  React.useEffect(() => {
    if (selectedBillIdForPayment) {
      const target = bills.find(b => b.id === selectedBillIdForPayment);
      if (target) setPayModalBill(target);
    }
  }, [selectedBillIdForPayment, bills]);

  // Payment Form state
  const [paymentAmount, setPaymentAmount] = useState<number>(0);
  const [selectedBankId, setSelectedBankId] = useState<string>(bankAccounts[0]?.id || '');
  const [refNumber, setRefNumber] = useState('');
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const filteredBills = useMemo(() => {
    return bills.filter(b => {
      const matchesSearch =
        b.billNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
        b.vendorName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        b.category.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesStatus = statusFilter === 'all' || b.status === statusFilter;
      return matchesSearch && matchesStatus;
    });
  }, [bills, searchTerm, statusFilter]);

  const totalPayables = useMemo(() => {
    return bills
      .filter(b => b.balanceDue > 0)
      .reduce((sum, b) => sum + (b.balanceDue * b.exchangeRate), 0);
  }, [bills]);

  const totalTdsWithheld = useMemo(() => {
    return bills.reduce((sum, b) => sum + (b.tdsAmount * b.exchangeRate), 0);
  }, [bills]);

  const openPaymentModal = (bill: Bill) => {
    setPayModalBill(bill);
    setPaymentAmount(bill.balanceDue);
    setRefNumber(`RTGS-${Date.now().toString().slice(-6)}`);
  };

  const handleConfirmPayment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!payModalBill) return;

    recordBillPayment(payModalBill.id, paymentAmount, selectedBankId, refNumber);
    setToastMessage(`Disbursed payment of ${formatMoney(paymentAmount, payModalBill.currency)} to ${payModalBill.vendorName}`);
    setPayModalBill(null);
    setTimeout(() => setToastMessage(null), 3000);
  };

  const handleDuplicate = (id: string, num: string) => {
    duplicateBill(id);
    setToastMessage(`Vendor Bill ${num} duplicated as draft.`);
    setTimeout(() => setToastMessage(null), 3000);
  };

  const handleDelete = (id: string, num: string) => {
    deleteBill(id);
    setDeleteConfirmId(null);
    setToastMessage(`Vendor Bill ${num} deleted.`);
    setTimeout(() => setToastMessage(null), 3000);
  };

  const getStatusBadge = (status: BillStatus) => {
    switch (status) {
      case 'paid':
        return <span className="text-[11px] font-semibold text-emerald-700 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded">Paid</span>;
      case 'partially_paid':
        return <span className="text-[11px] font-semibold text-blue-700 bg-blue-50 border border-blue-200 px-2 py-0.5 rounded">Partially Paid</span>;
      case 'overdue':
        return <span className="text-[11px] font-semibold text-rose-700 bg-rose-50 border border-rose-200 px-2 py-0.5 rounded">Overdue</span>;
      case 'approved':
        return <span className="text-[11px] font-semibold text-slate-700 bg-slate-100 border border-slate-200 px-2 py-0.5 rounded">Approved</span>;
      case 'draft':
        return <span className="text-[11px] font-semibold text-amber-700 bg-amber-50 border border-amber-200 px-2 py-0.5 rounded">Draft</span>;
    }
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      {/* Toast */}
      {toastMessage && (
        <div className="fixed bottom-5 right-5 z-50 bg-slate-900 text-white text-xs px-4 py-2.5 rounded-lg shadow-xl flex items-center gap-2 border border-slate-700 animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* AP Header Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
          <div className="text-xs text-slate-500 font-medium">Total Accounts Payable (AP)</div>
          <div className="text-xl font-bold font-mono tracking-tight text-slate-900 mt-1 tabular-nums">
            {formatMoney(
              convertAmount(totalPayables, settings.baseCurrency, selectedDisplayCurrency),
              selectedDisplayCurrency
            )}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">Pending net disbursements to vendors</div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
          <div className="text-xs text-blue-600 font-medium">TDS Withheld on Vendor Bills</div>
          <div className="text-xl font-bold font-mono tracking-tight text-blue-700 mt-1 tabular-nums">
            {formatMoney(
              convertAmount(totalTdsWithheld, settings.baseCurrency, selectedDisplayCurrency),
              selectedDisplayCurrency
            )}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">Payable to Income Tax Dept (Challan 281)</div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
          <div className="text-xs text-rose-600 font-medium">Overdue Bills (Past Due)</div>
          <div className="text-xl font-bold font-mono tracking-tight text-rose-600 mt-1 tabular-nums">
            {formatMoney(
              convertAmount(apAging.days1_30 + apAging.days31_60 + apAging.days61_90 + apAging.days90Plus, settings.baseCurrency, selectedDisplayCurrency),
              selectedDisplayCurrency
            )}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">Urgent liabilities needing immediate payment</div>
        </div>
      </div>

      {/* AP Aging Breakdown Strip */}
      <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-2xs">
        <div className="text-xs font-bold text-slate-800 uppercase tracking-wider mb-2">
          Accounts Payable Aging Schedule
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 text-xs">
          <div className="p-2.5 bg-slate-50 rounded-lg border border-slate-200">
            <div className="text-[10px] text-slate-500">Current (Not Due)</div>
            <div className="font-mono font-bold text-slate-900 tabular-nums">
              {formatMoney(convertAmount(apAging.current, settings.baseCurrency, selectedDisplayCurrency))}
            </div>
          </div>
          <div className="p-2.5 bg-amber-50/60 rounded-lg border border-amber-200">
            <div className="text-[10px] text-amber-700">1 - 30 Days</div>
            <div className="font-mono font-bold text-amber-800 tabular-nums">
              {formatMoney(convertAmount(apAging.days1_30, settings.baseCurrency, selectedDisplayCurrency))}
            </div>
          </div>
          <div className="p-2.5 bg-orange-50/60 rounded-lg border border-orange-200">
            <div className="text-[10px] text-orange-700">31 - 60 Days</div>
            <div className="font-mono font-bold text-orange-800 tabular-nums">
              {formatMoney(convertAmount(apAging.days31_60, settings.baseCurrency, selectedDisplayCurrency))}
            </div>
          </div>
          <div className="p-2.5 bg-rose-50/60 rounded-lg border border-rose-200">
            <div className="text-[10px] text-rose-700">61 - 90 Days</div>
            <div className="font-mono font-bold text-rose-800 tabular-nums">
              {formatMoney(convertAmount(apAging.days61_90, settings.baseCurrency, selectedDisplayCurrency))}
            </div>
          </div>
          <div className="p-2.5 bg-rose-100/60 rounded-lg border border-rose-300">
            <div className="text-[10px] text-rose-800">90+ Days</div>
            <div className="font-mono font-bold text-rose-900 tabular-nums">
              {formatMoney(convertAmount(apAging.days90Plus, settings.baseCurrency, selectedDisplayCurrency))}
            </div>
          </div>
        </div>
      </div>

      {/* Bills Data Grid & Filters */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-2xs p-4">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="relative w-full sm:w-80">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Search vendor bills, category or PAN..."
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-500"
            />
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto justify-between sm:justify-end">
            <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg text-xs font-medium">
              {[
                { id: 'all', label: 'All Bills' },
                { id: 'approved', label: 'Approved' },
                { id: 'overdue', label: 'Overdue' },
                { id: 'paid', label: 'Paid' },
              ].map(tab => (
                <button
                  key={tab.id}
                  onClick={() => setStatusFilter(tab.id)}
                  className={`px-2.5 py-1 rounded-md transition-colors ${
                    statusFilter === tab.id
                      ? 'bg-white text-slate-900 shadow-xs font-semibold'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            <button
              onClick={onOpenCreateBill}
              className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-md shadow-xs transition-colors shrink-0"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Record Bill</span>
            </button>
          </div>
        </div>

        <div className="mt-4 overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-600 border-collapse">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-50/75 text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
                <th className="py-2.5 px-3">Date</th>
                <th className="py-2.5 px-3">Bill #</th>
                <th className="py-2.5 px-3">Vendor Name</th>
                <th className="py-2.5 px-3">Due Date</th>
                <th className="py-2.5 px-3">Status</th>
                <th className="py-2.5 px-3 text-right">Gross Bill</th>
                <th className="py-2.5 px-3 text-right">TDS Withheld</th>
                <th className="py-2.5 px-3 text-right">Net Payable</th>
                <th className="py-2.5 px-3 text-right">Balance Due</th>
                <th className="py-2.5 px-3 text-center">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredBills.length === 0 ? (
                <tr>
                  <td colSpan={10} className="py-12 text-center text-slate-400">
                    <Receipt className="w-8 h-8 text-slate-300 mx-auto mb-2 opacity-50" />
                    <p className="text-sm font-medium text-slate-600">No vendor bills recorded</p>
                    <p className="text-xs text-slate-400 mt-1">Click "Record Bill" to log incoming supplier invoices and TDS.</p>
                  </td>
                </tr>
              ) : (
                filteredBills.map(bill => (
                  <tr key={bill.id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="py-3 px-3 text-slate-500 whitespace-nowrap">
                      {bill.billDate}
                    </td>
                    <td className="py-3 px-3 font-semibold text-slate-900 whitespace-nowrap">
                      {bill.billNumber}
                    </td>
                    <td className="py-3 px-3 font-medium text-slate-800">
                      <div>{bill.vendorName}</div>
                      <div className="text-[10px] text-slate-400 font-mono">PAN: {bill.vendorPan || '—'}</div>
                    </td>
                    <td className="py-3 px-3 text-slate-500 whitespace-nowrap">
                      {bill.dueDate}
                    </td>
                    <td className="py-3 px-3 whitespace-nowrap">
                      {getStatusBadge(bill.status)}
                    </td>
                    <td className="py-3 px-3 text-right font-mono font-medium text-slate-800 tabular-nums whitespace-nowrap">
                      {formatMoney(bill.grossAmount, bill.currency)}
                    </td>
                    <td className="py-3 px-3 text-right font-mono text-blue-600 tabular-nums whitespace-nowrap">
                      {bill.tdsAmount > 0 ? (
                        <div>
                          <span>-{formatMoney(bill.tdsAmount, bill.currency)}</span>
                          <div className="text-[10px] text-slate-400 font-sans">
                            {bill.tdsSection?.split('_')[0]} ({bill.tdsRatePercent}%)
                          </div>
                        </div>
                      ) : (
                        <span className="text-slate-400">None</span>
                      )}
                    </td>
                    <td className="py-3 px-3 text-right font-mono font-bold text-slate-900 tabular-nums whitespace-nowrap">
                      {formatMoney(bill.netPayable, bill.currency)}
                    </td>
                    <td className="py-3 px-3 text-right font-mono font-bold tabular-nums whitespace-nowrap">
                      {bill.balanceDue > 0 ? (
                        <span className={bill.status === 'overdue' ? 'text-rose-600' : 'text-slate-900'}>
                          {formatMoney(bill.balanceDue, bill.currency)}
                        </span>
                      ) : (
                        <span className="text-emerald-600 font-medium">Settled</span>
                      )}
                    </td>
                    <td className="py-3 px-3 text-center whitespace-nowrap">
                      <div className="flex items-center justify-center gap-1">
                        {bill.balanceDue > 0 && (
                          <button
                            onClick={() => openPaymentModal(bill)}
                            className="px-2 py-1 text-[11px] font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded transition-colors shadow-2xs mr-0.5"
                            title="Disburse Vendor Payment"
                          >
                            Pay
                          </button>
                        )}
                        {onEditBill && (
                          <button
                            onClick={() => onEditBill(bill)}
                            className="p-1.5 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded transition-colors"
                            title="Edit Bill"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                        <button
                          onClick={() => handleDuplicate(bill.id, bill.billNumber)}
                          className="p-1.5 text-slate-400 hover:text-emerald-600 hover:bg-emerald-50 rounded transition-colors"
                          title="Duplicate Bill"
                        >
                          <Copy className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => setDeleteConfirmId(bill.id)}
                          className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded transition-colors"
                          title="Delete Bill"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Delete Confirmation Modal */}
      {deleteConfirmId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-xs p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-sm w-full p-6 text-center border border-slate-200">
            <div className="w-12 h-12 rounded-full bg-rose-50 text-rose-600 mx-auto flex items-center justify-center mb-4">
              <AlertTriangle className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-slate-900 mb-2">Delete Vendor Bill?</h3>
            <p className="text-sm text-slate-600 mb-6">
              Are you sure you want to delete this bill? This will reverse any accounts payable balances.
            </p>
            <div className="flex gap-3 justify-center">
              <button
                onClick={() => setDeleteConfirmId(null)}
                className="px-4 py-2 border border-slate-300 rounded-lg text-sm font-medium text-slate-700 hover:bg-slate-50 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  const bill = bills.find(b => b.id === deleteConfirmId);
                  handleDelete(deleteConfirmId, bill?.billNumber || '');
                }}
                className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-lg text-sm font-medium transition-colors"
              >
                Delete Bill
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Settle Vendor Bill Payment Modal */}
      {payModalBill && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-xs p-4">
          <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95">
            <div className="px-6 py-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-slate-900">Disburse Vendor Payment</h3>
                <p className="text-xs text-slate-500">{payModalBill.billNumber} · {payModalBill.vendorName}</p>
              </div>
              <button
                onClick={() => setPayModalBill(null)}
                className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleConfirmPayment} className="p-6 space-y-4 text-xs">
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 space-y-1.5">
                <div className="flex justify-between">
                  <span className="text-slate-500">Gross Bill Amount:</span>
                  <span className="font-mono font-medium">{formatMoney(payModalBill.grossAmount, payModalBill.currency)}</span>
                </div>
                {payModalBill.tdsAmount > 0 && (
                  <div className="flex justify-between text-blue-700">
                    <span>TDS Deducted ({payModalBill.tdsRatePercent}% under Sec {payModalBill.tdsSection}):</span>
                    <span className="font-mono">-{formatMoney(payModalBill.tdsAmount, payModalBill.currency)}</span>
                  </div>
                )}
                <div className="border-t border-slate-200 pt-1.5 flex justify-between font-bold text-slate-900">
                  <span>Net Payable:</span>
                  <span className="font-mono">{formatMoney(payModalBill.netPayable, payModalBill.currency)}</span>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Disburse From Bank Account <span className="text-rose-500">*</span>
                </label>
                <select
                  value={selectedBankId}
                  onChange={e => setSelectedBankId(e.target.value)}
                  className="w-full text-xs bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 font-medium"
                >
                  {bankAccounts.map(b => (
                    <option key={b.id} value={b.id}>
                      {b.bankName} - {b.name} (Balance: {formatMoney(b.balance, b.currency)})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Payment Amount ({payModalBill.currency}) <span className="text-rose-500">*</span>
                </label>
                <input
                  type="number"
                  step="any"
                  value={paymentAmount}
                  onChange={e => setPaymentAmount(Number(e.target.value))}
                  className="w-full text-sm font-mono font-bold bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-slate-900"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Bank Reference / UTR Number
                </label>
                <input
                  type="text"
                  value={refNumber}
                  onChange={e => setRefNumber(e.target.value)}
                  placeholder="e.g. RTGS26102844192"
                  className="w-full text-xs font-mono bg-slate-50 border border-slate-200 rounded-lg px-3 py-2"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-2 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setPayModalBill(null)}
                  className="px-4 py-2 text-xs font-medium text-slate-600 hover:bg-slate-100 rounded-lg"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg shadow-xs"
                >
                  Confirm Disbursement
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

