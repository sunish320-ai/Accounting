import React, { useState, useMemo } from 'react';
import { useAccounting } from '../../context/AccountingContext';
import {
  Landmark,
  RefreshCw,
  Upload,
  Plus,
  CheckCircle2,
  AlertCircle,
  ArrowUpRight,
  ArrowDownLeft,
  Search,
  Check,
  X,
  FileSpreadsheet,
  Link2,
  Edit2,
  Copy,
  Trash2,
  AlertTriangle
} from 'lucide-react';
import { BankAccount, BankTransaction, CurrencyCode } from '../../types';

export const BankingView: React.FC = () => {
  const {
    bankAccounts,
    bankTransactions,
    isSyncingBank,
    syncBankFeeds,
    reconcileTransaction,
    excludeTransaction,
    importBankStatement,
    connectNewBankAccount,
    updateBankAccount,
    deleteBankAccount,
    duplicateBankAccount,
    currencies,
    formatMoney,
    invoices,
    bills
  } = useAccounting();

  const [selectedAccountId, setSelectedAccountId] = useState<string>('all');
  const [matchFilter, setMatchFilter] = useState<'all' | 'unmatched' | 'matched'>('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Bank Account Edit / Delete State
  const [editingBankAccount, setEditingBankAccount] = useState<BankAccount | null>(null);
  const [deleteConfirmBankId, setDeleteConfirmBankId] = useState<string | null>(null);

  // Connect Account Modal
  const [isConnectModalOpen, setIsConnectModalOpen] = useState(false);
  const [newBankName, setNewBankName] = useState('Barclays Bank');
  const [newAccName, setNewAccName] = useState('Barclays Corporate Clearing');
  const [newAccNumber, setNewAccNumber] = useState('•••• •••• 5590');
  const [newAccCurrency, setNewAccCurrency] = useState<CurrencyCode>('GBP');
  const [newAccBalance, setNewAccBalance] = useState<number>(15000);

  const handleStartEditBank = (acc: BankAccount) => {
    setEditingBankAccount({ ...acc });
  };

  const handleSaveEditBank = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingBankAccount) return;
    updateBankAccount(editingBankAccount.id, {
      name: editingBankAccount.name,
      bankName: editingBankAccount.bankName,
      accountNumber: editingBankAccount.accountNumber,
      currency: editingBankAccount.currency,
      balance: editingBankAccount.balance
    });
    setEditingBankAccount(null);
    setToastMessage(`Updated ${editingBankAccount.bankName} successfully.`);
    setTimeout(() => setToastMessage(null), 3000);
  };

  const handleDuplicateBank = (id: string, name: string) => {
    duplicateBankAccount(id);
    setToastMessage(`Duplicated bank account ${name}.`);
    setTimeout(() => setToastMessage(null), 3000);
  };

  const handleDeleteBank = (id: string, name: string) => {
    deleteBankAccount(id);
    if (selectedAccountId === id) setSelectedAccountId('all');
    setDeleteConfirmBankId(null);
    setToastMessage(`Deleted bank account ${name}.`);
    setTimeout(() => setToastMessage(null), 3000);
  };


  // Upload Statement Modal
  const [isUploadModalOpen, setIsUploadModalOpen] = useState(false);
  const [uploadBankId, setUploadBankId] = useState(bankAccounts[0]?.id || '');
  const [sampleCsvText, setSampleCsvText] = useState(
`2026-10-31,STRIPE PAYOUT MERCHANT REF 9901,145000,credit
2026-10-31,GOOGLE WORKSPACE SUBSCRIPTION OCT,-3400,debit
2026-10-30,DIRECT CLIENT RTGS ZENITH LOGISTICS,52720,credit`
  );

  const activeAccount = bankAccounts.find(b => b.id === selectedAccountId);

  const filteredTransactions = useMemo(() => {
    return bankTransactions.filter(txn => {
      const matchesAccount = selectedAccountId === 'all' || txn.bankAccountId === selectedAccountId;
      const matchesStatus =
        matchFilter === 'all' ||
        (matchFilter === 'unmatched' && txn.matchStatus === 'unmatched') ||
        (matchFilter === 'matched' && txn.matchStatus === 'matched');
      const matchesSearch =
        txn.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
        txn.referenceNumber.toLowerCase().includes(searchTerm.toLowerCase());
      return matchesAccount && matchesStatus && matchesSearch;
    });
  }, [bankTransactions, selectedAccountId, matchFilter, searchTerm]);

  const unmatchedCount = bankTransactions.filter(t => t.matchStatus === 'unmatched').length;

  const handleSyncFeeds = async () => {
    await syncBankFeeds();
    setToastMessage('Live Open Banking feeds synchronized. New transactions retrieved.');
    setTimeout(() => setToastMessage(null), 3000);
  };

  const handleMatchInvoice = (txnId: string, invoiceId: string, desc: string) => {
    reconcileTransaction(txnId, 'invoice', invoiceId, desc);
    setToastMessage('Transaction reconciled and matched to sales invoice!');
    setTimeout(() => setToastMessage(null), 3000);
  };

  const handleMatchBill = (txnId: string, billId: string, desc: string) => {
    reconcileTransaction(txnId, 'bill', billId, desc);
    setToastMessage('Transaction reconciled and matched to vendor bill!');
    setTimeout(() => setToastMessage(null), 3000);
  };

  const handleConnectAccount = (e: React.FormEvent) => {
    e.preventDefault();
    connectNewBankAccount({
      name: newAccName,
      accountNumber: newAccNumber,
      bankName: newBankName,
      accountType: 'checking',
      currency: newAccCurrency,
      balance: newAccBalance,
      status: 'connected',
      institutionCode: 'OPEN_BANKING_API'
    });
    setIsConnectModalOpen(false);
    setToastMessage(`Connected ${newBankName} via Open Banking API!`);
    setTimeout(() => setToastMessage(null), 3000);
  };

  const handleImportCsv = (e: React.FormEvent) => {
    e.preventDefault();
    const lines = sampleCsvText.trim().split('\n');
    const parsedTxns: Partial<BankTransaction>[] = [];

    lines.forEach(line => {
      const parts = line.split(',');
      if (parts.length >= 3) {
        const date = parts[0].trim();
        const description = parts[1].trim();
        const amount = Number(parts[2].trim());
        parsedTxns.push({
          date,
          description,
          amount,
          currency: 'INR'
        });
      }
    });

    importBankStatement(uploadBankId, parsedTxns);
    setIsUploadModalOpen(false);
    setToastMessage(`Imported ${parsedTxns.length} statement rows successfully!`);
    setTimeout(() => setToastMessage(null), 3000);
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      {/* Toast */}
      {toastMessage && (
        <div className="fixed bottom-5 right-5 z-50 bg-slate-900 text-white text-xs px-4 py-2.5 rounded-lg shadow-xl flex items-center gap-2 border border-slate-700 animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Top Banner & Banking Action Bar */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-2xs p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-base font-bold text-slate-900 flex items-center gap-2">
            <Landmark className="w-5 h-5 text-blue-600" />
            <span>Banking & Live Transaction Feeds</span>
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Automated Open Banking sync, multi-currency statement import, and 1-click reconciliation engine
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsUploadModalOpen(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 bg-white hover:bg-slate-50 border border-slate-200 rounded-lg shadow-2xs transition-colors"
          >
            <Upload className="w-3.5 h-3.5 text-slate-500" />
            <span>Upload Statement</span>
          </button>

          <button
            onClick={handleSyncFeeds}
            disabled={isSyncingBank}
            className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs transition-colors"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isSyncingBank ? 'animate-spin' : ''}`} />
            <span>{isSyncingBank ? 'Connecting API...' : 'Sync Live Feeds'}</span>
          </button>

          <button
            onClick={() => setIsConnectModalOpen(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-800 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Bank</span>
          </button>
        </div>
      </div>

      {/* Connected Accounts Strip */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
        <button
          onClick={() => setSelectedAccountId('all')}
          className={`p-4 rounded-xl border text-left transition-all ${
            selectedAccountId === 'all'
              ? 'border-blue-600 bg-blue-50/30 shadow-xs'
              : 'border-slate-200 bg-white hover:bg-slate-50'
          }`}
        >
          <div className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">All Accounts</div>
          <div className="text-lg font-bold font-mono text-slate-900 mt-1 tabular-nums">
            {bankAccounts.length} Connected
          </div>
          <div className="text-[11px] text-blue-600 font-medium mt-1">
            {unmatchedCount} Unreconciled Transactions
          </div>
        </button>

        {bankAccounts.map(acc => (
          <div
            key={acc.id}
            onClick={() => setSelectedAccountId(acc.id)}
            className={`p-4 rounded-xl border text-left transition-all cursor-pointer relative group ${
              selectedAccountId === acc.id
                ? 'border-blue-600 bg-blue-50/30 shadow-xs'
                : 'border-slate-200 bg-white hover:bg-slate-50'
            }`}
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-800 truncate">{acc.bankName}</span>
              <span className="text-[10px] text-emerald-700 bg-emerald-50 px-1.5 py-0.2 rounded font-mono">
                API Live
              </span>
            </div>
            <div className="text-base font-bold font-mono text-slate-900 mt-1 tabular-nums">
              {formatMoney(acc.balance, acc.currency)}
            </div>
            <div className="text-[10px] text-slate-400 font-mono mt-1">
              {acc.name} · {acc.currency}
            </div>

            {/* Edit / Duplicate / Delete actions */}
            <div
              className="mt-2 pt-2 border-t border-slate-100 flex items-center justify-end gap-1.5"
              onClick={e => e.stopPropagation()}
            >
              <button
                onClick={() => handleStartEditBank(acc)}
                className="p-1 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded transition-colors"
                title="Edit Bank Account"
              >
                <Edit2 className="w-3 h-3" />
              </button>
              <button
                onClick={() => handleDuplicateBank(acc.id, acc.bankName)}
                className="p-1 text-slate-400 hover:text-emerald-600 hover:bg-emerald-50 rounded transition-colors"
                title="Duplicate Bank Account"
              >
                <Copy className="w-3 h-3" />
              </button>
              <button
                onClick={() => setDeleteConfirmBankId(acc.id)}
                className="p-1 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded transition-colors"
                title="Delete Bank Account"
              >
                <Trash2 className="w-3 h-3" />
              </button>
            </div>
          </div>
        ))}
      </div>


      {/* Reconciliation Feed Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-2xs p-4 space-y-4">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="relative w-full sm:w-80">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Filter bank statement lines..."
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-500"
            />
          </div>

          <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg text-xs font-medium">
            <button
              onClick={() => setMatchFilter('all')}
              className={`px-3 py-1 rounded-md transition-colors ${
                matchFilter === 'all' ? 'bg-white text-slate-900 shadow-xs font-semibold' : 'text-slate-600'
              }`}
            >
              All Activity
            </button>
            <button
              onClick={() => setMatchFilter('unmatched')}
              className={`px-3 py-1 rounded-md transition-colors ${
                matchFilter === 'unmatched' ? 'bg-white text-amber-700 shadow-xs font-semibold' : 'text-slate-600'
              }`}
            >
              Unmatched ({unmatchedCount})
            </button>
            <button
              onClick={() => setMatchFilter('matched')}
              className={`px-3 py-1 rounded-md transition-colors ${
                matchFilter === 'matched' ? 'bg-white text-emerald-700 shadow-xs font-semibold' : 'text-slate-600'
              }`}
            >
              Reconciled
            </button>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-600 border-collapse">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-50/75 text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
                <th className="py-2.5 px-3">Date</th>
                <th className="py-2.5 px-3">Transaction Narrative</th>
                <th className="py-2.5 px-3">Reference / UTR</th>
                <th className="py-2.5 px-3 text-right">Inflow / Outflow</th>
                <th className="py-2.5 px-3 text-center">Status</th>
                <th className="py-2.5 px-3">Match Details / Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredTransactions.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-10 text-center text-slate-400">
                    No bank feed transactions found.
                  </td>
                </tr>
              ) : (
                filteredTransactions.map(txn => {
                  const isCredit = txn.amount > 0;
                  const matchingInvoice = txn.suggestedMatchId ? invoices.find(i => i.id === txn.suggestedMatchId) : null;
                  const matchingBill = txn.suggestedMatchId ? bills.find(b => b.id === txn.suggestedMatchId) : null;

                  return (
                    <tr key={txn.id} className="hover:bg-slate-50/70 transition-colors">
                      <td className="py-3 px-3 text-slate-500 whitespace-nowrap font-mono">
                        {txn.date}
                      </td>
                      <td className="py-3 px-3 font-medium text-slate-800 max-w-xs">
                        <div className="truncate">{txn.description}</div>
                      </td>
                      <td className="py-3 px-3 text-slate-500 font-mono text-[11px] whitespace-nowrap">
                        {txn.referenceNumber}
                      </td>
                      <td className="py-3 px-3 text-right font-mono font-bold tabular-nums whitespace-nowrap">
                        <span className={isCredit ? 'text-emerald-600' : 'text-slate-900'}>
                          {isCredit ? '+' : ''}{formatMoney(txn.amount, txn.currency)}
                        </span>
                      </td>
                      <td className="py-3 px-3 text-center whitespace-nowrap">
                        {txn.matchStatus === 'matched' ? (
                          <span className="text-[10px] font-semibold text-emerald-700 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded flex items-center justify-center gap-1">
                            <Check className="w-3 h-3" />
                            <span>Matched</span>
                          </span>
                        ) : txn.matchStatus === 'excluded' ? (
                          <span className="text-[10px] font-semibold text-slate-400 bg-slate-100 px-2 py-0.5 rounded">
                            Excluded
                          </span>
                        ) : (
                          <span className="text-[10px] font-semibold text-amber-700 bg-amber-50 border border-amber-200 px-2 py-0.5 rounded">
                            Needs Match
                          </span>
                        )}
                      </td>
                      <td className="py-3 px-3">
                        {txn.matchStatus === 'matched' ? (
                          <div className="text-[11px] text-slate-600">
                            Reconciled against: <span className="font-semibold">{txn.matchedEntityDescription || 'Ledger'}</span>
                          </div>
                        ) : (
                          <div className="flex items-center gap-2">
                            {txn.suggestedMatchReason && (
                              <div className="text-[11px] text-blue-700 max-w-xs truncate" title={txn.suggestedMatchReason}>
                                💡 {txn.suggestedMatchReason}
                              </div>
                            )}

                            {isCredit && matchingInvoice && (
                              <button
                                onClick={() => handleMatchInvoice(txn.id, matchingInvoice.id, `${matchingInvoice.invoiceNumber} (${matchingInvoice.customerName})`)}
                                className="px-2 py-1 text-[11px] font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded transition-colors whitespace-nowrap shadow-2xs"
                              >
                                Match Invoice
                              </button>
                            )}

                            {!isCredit && matchingBill && (
                              <button
                                onClick={() => handleMatchBill(txn.id, matchingBill.id, `${matchingBill.billNumber} (${matchingBill.vendorName})`)}
                                className="px-2 py-1 text-[11px] font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded transition-colors whitespace-nowrap shadow-2xs"
                              >
                                Match Bill
                              </button>
                            )}

                            <button
                              onClick={() => reconcileTransaction(txn.id, 'manual', undefined, 'Manually categorized')}
                              className="px-2 py-1 text-[11px] font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded transition-colors whitespace-nowrap"
                            >
                              Auto-Post
                            </button>

                            <button
                              onClick={() => excludeTransaction(txn.id)}
                              className="p-1 text-slate-400 hover:text-rose-500 rounded"
                              title="Exclude from reconciliation"
                            >
                              <X className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        )}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Connect New Bank Modal */}
      {isConnectModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-xs p-4">
          <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95">
            <div className="px-6 py-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-slate-900">Connect Open Banking Account</h3>
                <p className="text-xs text-slate-500">Live webhook integration with institutional banking APIs</p>
              </div>
              <button
                onClick={() => setIsConnectModalOpen(false)}
                className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleConnectAccount} className="p-6 space-y-4 text-xs">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Bank / Institution
                </label>
                <input
                  type="text"
                  value={newBankName}
                  onChange={e => setNewBankName(e.target.value)}
                  className="w-full text-xs bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 font-medium"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Account Display Name
                </label>
                <input
                  type="text"
                  value={newAccName}
                  onChange={e => setNewAccName(e.target.value)}
                  className="w-full text-xs bg-slate-50 border border-slate-200 rounded-lg px-3 py-2"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Currency
                  </label>
                  <select
                    value={newAccCurrency}
                    onChange={e => setNewAccCurrency(e.target.value as any)}
                    className="w-full text-xs bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 font-mono font-semibold"
                  >
                    {currencies.map(c => (
                      <option key={c.code} value={c.code}>{c.code} ({c.symbol})</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Opening Balance
                  </label>
                  <input
                    type="number"
                    value={newAccBalance}
                    onChange={e => setNewAccBalance(Number(e.target.value))}
                    className="w-full text-xs font-mono font-bold bg-slate-50 border border-slate-200 rounded-lg px-3 py-2"
                  />
                </div>
              </div>

              <div className="p-3 bg-blue-50/50 rounded-lg border border-blue-200 text-[11px] text-blue-800 flex items-center gap-2">
                <Link2 className="w-4 h-4 text-blue-600 shrink-0" />
                <span>Simulates automated OAuth token exchange with banking provider API.</span>
              </div>

              <div className="pt-2 flex items-center justify-end gap-2 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setIsConnectModalOpen(false)}
                  className="px-4 py-2 text-xs font-medium text-slate-600 hover:bg-slate-100 rounded-lg"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs"
                >
                  Connect API Feed
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Upload Statement Modal */}
      {isUploadModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-xs p-4">
          <div className="bg-white w-full max-w-lg rounded-2xl shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95">
            <div className="px-6 py-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-slate-900">Upload Bank Statement (.CSV / .OFX)</h3>
                <p className="text-xs text-slate-500">Import historical transactions directly into reconciliation queue</p>
              </div>
              <button
                onClick={() => setIsUploadModalOpen(false)}
                className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleImportCsv} className="p-6 space-y-4 text-xs">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Target Bank Account
                </label>
                <select
                  value={uploadBankId}
                  onChange={e => setUploadBankId(e.target.value)}
                  className="w-full text-xs bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 font-medium"
                >
                  {bankAccounts.map(b => (
                    <option key={b.id} value={b.id}>{b.bankName} - {b.name}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Statement Data (CSV Format: Date, Narrative, Amount, Type)
                </label>
                <textarea
                  rows={5}
                  value={sampleCsvText}
                  onChange={e => setSampleCsvText(e.target.value)}
                  className="w-full font-mono text-xs bg-slate-50 border border-slate-200 rounded-lg p-2.5"
                  required
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-2 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setIsUploadModalOpen(false)}
                  className="px-4 py-2 text-xs font-medium text-slate-600 hover:bg-slate-100 rounded-lg"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs"
                >
                  Parse & Import Transactions
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Edit Bank Account Modal */}
      {editingBankAccount && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-xs p-4">
          <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95">
            <div className="px-6 py-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-slate-900">Edit Bank Account</h3>
                <p className="text-xs text-slate-500">Update account labels, currency, and balance</p>
              </div>
              <button
                onClick={() => setEditingBankAccount(null)}
                className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveEditBank} className="p-6 space-y-4 text-xs">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Bank / Institution Name
                </label>
                <input
                  type="text"
                  value={editingBankAccount.bankName}
                  onChange={e => setEditingBankAccount({ ...editingBankAccount, bankName: e.target.value })}
                  className="w-full text-xs bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 font-medium"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Account Display Name
                </label>
                <input
                  type="text"
                  value={editingBankAccount.name}
                  onChange={e => setEditingBankAccount({ ...editingBankAccount, name: e.target.value })}
                  className="w-full text-xs bg-slate-50 border border-slate-200 rounded-lg px-3 py-2"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Account Number / Identifier
                </label>
                <input
                  type="text"
                  value={editingBankAccount.accountNumber}
                  onChange={e => setEditingBankAccount({ ...editingBankAccount, accountNumber: e.target.value })}
                  className="w-full text-xs font-mono bg-slate-50 border border-slate-200 rounded-lg px-3 py-2"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Currency
                  </label>
                  <select
                    value={editingBankAccount.currency}
                    onChange={e => setEditingBankAccount({ ...editingBankAccount, currency: e.target.value as any })}
                    className="w-full text-xs bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 font-mono font-semibold"
                  >
                    {currencies.map(c => (
                      <option key={c.code} value={c.code}>{c.code} ({c.symbol})</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Current Balance
                  </label>
                  <input
                    type="number"
                    value={editingBankAccount.balance}
                    onChange={e => setEditingBankAccount({ ...editingBankAccount, balance: Number(e.target.value) })}
                    className="w-full text-xs font-mono font-bold bg-slate-50 border border-slate-200 rounded-lg px-3 py-2"
                  />
                </div>
              </div>

              <div className="pt-2 flex items-center justify-end gap-2 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setEditingBankAccount(null)}
                  className="px-4 py-2 text-xs font-medium text-slate-600 hover:bg-slate-100 rounded-lg"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs"
                >
                  Save Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Bank Account Confirmation */}
      {deleteConfirmBankId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-xs p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-sm w-full p-6 text-center border border-slate-200">
            <div className="w-12 h-12 rounded-full bg-rose-50 text-rose-600 mx-auto flex items-center justify-center mb-4">
              <AlertTriangle className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-slate-900 mb-2">Delete Bank Account?</h3>
            <p className="text-sm text-slate-600 mb-6">
              Are you sure you want to delete this bank account? All its linked transactions will be removed from feeds.
            </p>
            <div className="flex gap-3 justify-center">
              <button
                onClick={() => setDeleteConfirmBankId(null)}
                className="px-4 py-2 border border-slate-300 rounded-lg text-sm font-medium text-slate-700 hover:bg-slate-50 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  const b = bankAccounts.find(x => x.id === deleteConfirmBankId);
                  handleDeleteBank(deleteConfirmBankId, b?.bankName || '');
                }}
                className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-lg text-sm font-medium transition-colors"
              >
                Delete Account
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

