import React, { useState, useRef } from 'react';
import { useAccounting } from '../../context/AccountingContext';
import {
  Settings,
  Building,
  Globe,
  RefreshCw,
  Save,
  CheckCircle2,
  RotateCcw,
  Download,
  Upload,
  FileSpreadsheet,
  FileCode,
  FileText,
  Database,
  Trash2,
  AlertTriangle,
  HelpCircle,
  FileCheck
} from 'lucide-react';
import { CurrencyCode, TaxJurisdiction } from '../../types';
import {
  exportToXLSX,
  exportToCSV,
  exportToHTML,
  exportToJSON
} from '../../utils/exportHelper';

export const SettingsView: React.FC = () => {
  const {
    settings,
    updateSettings,
    currencies,
    updateExchangeRate,
    syncLiveFxRates,
    setJurisdiction,
    resetToDemoData,
    resetToFreshBlank,
    clearAllTransactions,
    loadDemoSampleData,
    restoreFromJson,
    getBackupPayload,
    customers,
    vendors,
    invoices,
    bills,
    expenses,
    bankAccounts
  } = useAccounting();

  const [formData, setFormData] = useState({ ...settings });
  const [toastMessage, setToastMessage] = useState<{ text: string; type: 'success' | 'error' | 'info' } | null>(null);
  const [isSyncingFx, setIsSyncingFx] = useState(false);
  const [confirmModal, setConfirmModal] = useState<{
    isOpen: boolean;
    title: string;
    description: string;
    actionType: 'fresh_blank' | 'clear_txns' | 'load_demo' | 'default_reset';
    confirmLabel: string;
  }>({
    isOpen: false,
    title: '',
    description: '',
    actionType: 'fresh_blank',
    confirmLabel: ''
  });

  const fileInputRef = useRef<HTMLInputElement>(null);

  const showToast = (text: string, type: 'success' | 'error' | 'info' = 'success') => {
    setToastMessage({ text, type });
    setTimeout(() => setToastMessage(null), 3500);
  };

  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    updateSettings(formData);
    showToast('Organization settings and tax configuration saved.');
  };

  const handleLiveFxSync = async () => {
    setIsSyncingFx(true);
    await syncLiveFxRates();
    setIsSyncingFx(false);
    showToast('Live foreign exchange rates updated from international feeds.');
  };

  // Export Handlers
  const handleExportXLSX = () => {
    const payload = getBackupPayload();
    exportToXLSX(payload);
    showToast('Exported multi-sheet Excel workbook (.xlsx) successfully.');
  };

  const handleExportCSV = (section: 'all' | 'invoices' | 'bills' | 'customers' | 'vendors' = 'all') => {
    const payload = getBackupPayload();
    exportToCSV(payload, section);
    showToast(`Exported ${section === 'all' ? 'complete ledger' : section} as CSV (.csv).`);
  };

  const handleExportHTML = () => {
    const payload = getBackupPayload();
    exportToHTML(payload);
    showToast('Exported formatted audit report (.html) for printing.');
  };

  const handleExportJSON = () => {
    const payload = getBackupPayload();
    exportToJSON(payload);
    showToast('Full system backup archive (.json) downloaded.');
  };

  // Restore Handler
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const text = event.target?.result as string;
        const success = restoreFromJson(text);
        if (success) {
          showToast('Data backup restored successfully! All tables updated.', 'success');
        } else {
          showToast('Failed to restore backup: Invalid JSON schema.', 'error');
        }
      } catch (err) {
        showToast('Error reading file. Ensure it is a valid LedgerPulse JSON backup.', 'error');
      }
    };
    reader.readAsText(file);
    // Reset file input
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  // Execute Reset
  const handleExecuteReset = () => {
    const { actionType } = confirmModal;
    if (actionType === 'fresh_blank') {
      resetToFreshBlank();
      showToast('All data cleared. System reset to fresh blank slate.', 'info');
    } else if (actionType === 'clear_txns') {
      clearAllTransactions();
      showToast('Transactions wiped. Master directories (customers, vendors) preserved.', 'info');
    } else if (actionType === 'load_demo') {
      loadDemoSampleData();
      showToast('Standard demo dataset loaded successfully with GST/TDS records.', 'success');
    } else if (actionType === 'default_reset') {
      resetToDemoData();
      showToast('Reset to default initial system state.', 'info');
    }
    setConfirmModal(prev => ({ ...prev, isOpen: false }));
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      {/* Toast */}
      {toastMessage && (
        <div className={`fixed bottom-5 right-5 z-50 text-white text-xs px-4 py-2.5 rounded-lg shadow-xl flex items-center gap-2 border animate-in fade-in ${
          toastMessage.type === 'error'
            ? 'bg-rose-900 border-rose-700 text-rose-100'
            : toastMessage.type === 'info'
            ? 'bg-blue-900 border-blue-700 text-blue-100'
            : 'bg-slate-900 border-slate-700 text-slate-100'
        }`}>
          {toastMessage.type === 'error' ? (
            <AlertTriangle className="w-4 h-4 text-rose-400" />
          ) : (
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          )}
          <span>{toastMessage.text}</span>
        </div>
      )}

      {/* Confirmation Modal for Reset Actions */}
      {confirmModal.isOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl max-w-md w-full p-6 shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95 space-y-4">
            <div className="w-10 h-10 rounded-full bg-rose-100 text-rose-600 flex items-center justify-center mx-auto">
              <AlertTriangle className="w-5 h-5" />
            </div>
            <div className="text-center space-y-1">
              <h3 className="text-base font-bold text-slate-900">{confirmModal.title}</h3>
              <p className="text-xs text-slate-500 leading-relaxed">{confirmModal.description}</p>
            </div>

            <div className="p-3 bg-amber-50 border border-amber-200 rounded-lg text-[11px] text-amber-800 flex items-start gap-2">
              <HelpCircle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
              <span>
                Tip: You can download a full backup (.json or .xlsx) before proceeding so you can restore your data at any time.
              </span>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setConfirmModal(prev => ({ ...prev, isOpen: false }))}
                className="px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-100 rounded-lg transition-colors"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleExecuteReset}
                className="px-4 py-2 text-xs font-semibold text-white bg-rose-600 hover:bg-rose-700 rounded-lg shadow-sm transition-colors"
              >
                {confirmModal.confirmLabel}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Top Banner */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-2xs p-5 flex items-center justify-between">
        <div>
          <h1 className="text-base font-bold text-slate-900 flex items-center gap-2">
            <Settings className="w-5 h-5 text-blue-600" />
            <span>Organization Settings, Data Backup & System Maintenance</span>
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Manage legal business credentials, localized tax compliance, multi-currency rates, data backups (CSV, XLSX, HTML, JSON), and reset options.
          </p>
        </div>

        <div className="hidden sm:flex items-center gap-2 text-xs text-slate-500 bg-slate-50 px-3 py-1.5 rounded-lg border border-slate-200">
          <Database className="w-3.5 h-3.5 text-blue-600" />
          <span>
            {invoices.length} Invoices · {bills.length} Bills · {customers.length} Customers · {vendors.length} Vendors
          </span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Organization Profile & Tax Settings (Span 2) */}
        <div className="lg:col-span-2 space-y-6">
          <form onSubmit={handleSaveSettings} className="bg-white rounded-xl border border-slate-200 shadow-2xs p-6 space-y-5">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h2 className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
                <Building className="w-4 h-4 text-blue-600" />
                <span>Business & Legal Entity Profile</span>
              </h2>
              <button
                type="submit"
                className="px-3.5 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs flex items-center gap-1.5"
              >
                <Save className="w-3.5 h-3.5" />
                <span>Save Changes</span>
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div>
                <label className="block text-slate-700 font-semibold mb-1">Brand / Trade Name</label>
                <input
                  type="text"
                  value={formData.businessName}
                  onChange={e => setFormData({ ...formData, businessName: e.target.value })}
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-xs"
                  required
                />
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">Legal Registered Entity Name</label>
                <input
                  type="text"
                  value={formData.legalEntityName}
                  onChange={e => setFormData({ ...formData, legalEntityName: e.target.value })}
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-xs font-medium"
                  required
                />
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">GSTIN (India GST Registration)</label>
                <input
                  type="text"
                  value={formData.gstin}
                  onChange={e => setFormData({ ...formData, gstin: e.target.value })}
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-xs font-mono font-semibold text-blue-700"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">Permanent Account Number (PAN)</label>
                <input
                  type="text"
                  value={formData.pan}
                  onChange={e => setFormData({ ...formData, pan: e.target.value })}
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-xs font-mono text-slate-800"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">UK/EU VAT Registration Number</label>
                <input
                  type="text"
                  value={formData.vatNumber}
                  onChange={e => setFormData({ ...formData, vatNumber: e.target.value })}
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-xs font-mono text-slate-800"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">US Employer Identification No (EIN)</label>
                <input
                  type="text"
                  value={formData.ein}
                  onChange={e => setFormData({ ...formData, ein: e.target.value })}
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-xs font-mono text-slate-800"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">Finance Contact Email</label>
                <input
                  type="email"
                  value={formData.email}
                  onChange={e => setFormData({ ...formData, email: e.target.value })}
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-xs"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">Finance Phone</label>
                <input
                  type="text"
                  value={formData.phone}
                  onChange={e => setFormData({ ...formData, phone: e.target.value })}
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-xs"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="block text-slate-700 font-semibold mb-1">Registered Business Address</label>
                <textarea
                  rows={2}
                  value={formData.address}
                  onChange={e => setFormData({ ...formData, address: e.target.value })}
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-xs"
                />
              </div>
            </div>

            {/* Compliance Presets */}
            <div className="pt-4 border-t border-slate-100">
              <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider mb-3">
                Regional Compliance Jurisdiction
              </h3>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
                {[
                  { id: 'INDIA' as TaxJurisdiction, label: 'India (GST & TDS)', flag: '🇮🇳' },
                  { id: 'USA' as TaxJurisdiction, label: 'United States', flag: '🇺🇸' },
                  { id: 'UK_EU' as TaxJurisdiction, label: 'UK & EU (VAT)', flag: '🇬🇧' },
                  { id: 'UAE' as TaxJurisdiction, label: 'UAE (5% VAT)', flag: '🇦🇪' },
                ].map(item => (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => {
                      setJurisdiction(item.id);
                      setFormData({ ...formData, jurisdiction: item.id });
                    }}
                    className={`p-2.5 rounded-lg border text-left flex items-center gap-2 transition-colors ${
                      formData.jurisdiction === item.id
                        ? 'border-blue-600 bg-blue-50/40 text-blue-900 font-semibold'
                        : 'border-slate-200 bg-white hover:bg-slate-50 text-slate-700'
                    }`}
                  >
                    <span>{item.flag}</span>
                    <span className="truncate">{item.label}</span>
                  </button>
                ))}
              </div>
            </div>
          </form>

          {/* Data Backup & Export Center */}
          <div className="bg-white rounded-xl border border-slate-200 shadow-2xs p-6 space-y-5">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div>
                <h2 className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
                  <Database className="w-4 h-4 text-emerald-600" />
                  <span>Data Backup & Export Center</span>
                </h2>
                <p className="text-[11px] text-slate-500 mt-0.5">
                  Download complete copies of your financial records in industry standard formats
                </p>
              </div>

              {/* Restore JSON Button */}
              <div>
                <input
                  type="file"
                  ref={fileInputRef}
                  accept=".json"
                  onChange={handleFileUpload}
                  className="hidden"
                />
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="px-3 py-1.5 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors flex items-center gap-1.5"
                >
                  <Upload className="w-3.5 h-3.5 text-slate-600" />
                  <span>Restore from JSON</span>
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {/* XLSX Excel Export */}
              <div className="p-4 rounded-xl border border-emerald-100 bg-emerald-50/40 hover:bg-emerald-50/80 transition-colors flex flex-col justify-between">
                <div>
                  <div className="flex items-center gap-2 text-emerald-800 font-bold text-xs">
                    <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
                    <span>Microsoft Excel Workbook (.xlsx)</span>
                  </div>
                  <p className="text-[11px] text-emerald-700/80 mt-1 leading-relaxed">
                    Formatted multi-tab workbook with separate sheets for Sales Invoices, Vendor Bills, Expenses, Customers, Vendors, and Bank Accounts.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={handleExportXLSX}
                  className="mt-3.5 w-full py-2 px-3 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg shadow-xs flex items-center justify-center gap-1.5 transition-colors"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download .XLSX Workbook</span>
                </button>
              </div>

              {/* CSV Master Export */}
              <div className="p-4 rounded-xl border border-blue-100 bg-blue-50/40 hover:bg-blue-50/80 transition-colors flex flex-col justify-between">
                <div>
                  <div className="flex items-center gap-2 text-blue-800 font-bold text-xs">
                    <FileCode className="w-4 h-4 text-blue-600" />
                    <span>Comma-Separated Values (.csv)</span>
                  </div>
                  <p className="text-[11px] text-blue-700/80 mt-1 leading-relaxed">
                    Universal CSV table for seamless import into spreadsheets, external tax audit tools, or third-party CRM platforms.
                  </p>
                </div>
                <div className="mt-3.5 flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={() => handleExportCSV('all')}
                    className="flex-1 py-2 px-3 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs flex items-center justify-center gap-1.5 transition-colors"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Download Complete CSV</span>
                  </button>
                </div>
              </div>

              {/* HTML Printable Audit Report */}
              <div className="p-4 rounded-xl border border-purple-100 bg-purple-50/40 hover:bg-purple-50/80 transition-colors flex flex-col justify-between">
                <div>
                  <div className="flex items-center gap-2 text-purple-800 font-bold text-xs">
                    <FileText className="w-4 h-4 text-purple-600" />
                    <span>Printable Audit Report (.html)</span>
                  </div>
                  <p className="text-[11px] text-purple-700/80 mt-1 leading-relaxed">
                    Standalone executive ledger report with embedded CSS styling. Ideal for offline audits, client records, and instant Print-to-PDF.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={handleExportHTML}
                  className="mt-3.5 w-full py-2 px-3 text-xs font-semibold text-white bg-purple-600 hover:bg-purple-700 rounded-lg shadow-xs flex items-center justify-center gap-1.5 transition-colors"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download .HTML Report</span>
                </button>
              </div>

              {/* JSON Database Backup */}
              <div className="p-4 rounded-xl border border-slate-200 bg-slate-50 hover:bg-slate-100/70 transition-colors flex flex-col justify-between">
                <div>
                  <div className="flex items-center gap-2 text-slate-800 font-bold text-xs">
                    <Database className="w-4 h-4 text-slate-700" />
                    <span>Complete System Archive (.json)</span>
                  </div>
                  <p className="text-[11px] text-slate-600 mt-1 leading-relaxed">
                    Full lossless database image containing all configurations, invoices, bills, expenses, contacts, and journal entries for complete restoration.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={handleExportJSON}
                  className="mt-3.5 w-full py-2 px-3 text-xs font-semibold text-slate-800 bg-white hover:bg-slate-100 border border-slate-300 rounded-lg shadow-2xs flex items-center justify-center gap-1.5 transition-colors"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download .JSON Backup</span>
                </button>
              </div>
            </div>

            {/* Quick CSV Section Selector */}
            <div className="pt-2 border-t border-slate-100 flex flex-wrap items-center gap-2 text-xs">
              <span className="text-[11px] text-slate-500 font-medium">Export individual section as CSV:</span>
              <button
                type="button"
                onClick={() => handleExportCSV('invoices')}
                className="px-2.5 py-1 text-[11px] font-medium bg-slate-100 hover:bg-slate-200 text-slate-700 rounded border border-slate-200"
              >
                Invoices CSV
              </button>
              <button
                type="button"
                onClick={() => handleExportCSV('bills')}
                className="px-2.5 py-1 text-[11px] font-medium bg-slate-100 hover:bg-slate-200 text-slate-700 rounded border border-slate-200"
              >
                Bills (AP) CSV
              </button>
              <button
                type="button"
                onClick={() => handleExportCSV('customers')}
                className="px-2.5 py-1 text-[11px] font-medium bg-slate-100 hover:bg-slate-200 text-slate-700 rounded border border-slate-200"
              >
                Customers CSV
              </button>
              <button
                type="button"
                onClick={() => handleExportCSV('vendors')}
                className="px-2.5 py-1 text-[11px] font-medium bg-slate-100 hover:bg-slate-200 text-slate-700 rounded border border-slate-200"
              >
                Vendors CSV
              </button>
            </div>
          </div>
        </div>

        {/* Right Column: Multi-Currency Rates & Data Reset Options */}
        <div className="space-y-6">
          {/* Multi-Currency Manager */}
          <div className="bg-white rounded-xl border border-slate-200 shadow-2xs p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div>
                <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
                  <Globe className="w-4 h-4 text-blue-600" />
                  <span>Exchange Rates</span>
                </h3>
                <p className="text-[11px] text-slate-400">Base Currency: {settings.baseCurrency}</p>
              </div>

              <button
                type="button"
                onClick={handleLiveFxSync}
                disabled={isSyncingFx}
                className="text-xs text-blue-600 hover:text-blue-700 font-semibold flex items-center gap-1"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isSyncingFx ? 'animate-spin' : ''}`} />
                <span>Sync FX</span>
              </button>
            </div>

            <div className="space-y-2 max-h-[300px] overflow-y-auto text-xs">
              {currencies.map(cur => (
                <div
                  key={cur.code}
                  className="p-2.5 bg-slate-50 rounded-lg border border-slate-200 flex items-center justify-between"
                >
                  <div>
                    <div className="font-bold text-slate-800">
                      {cur.code} ({cur.symbol})
                    </div>
                    <div className="text-[10px] text-slate-400 truncate max-w-[130px]">{cur.name}</div>
                  </div>

                  <div className="flex items-center gap-1.5">
                    <span className="text-[11px] text-slate-500 font-mono">1 {cur.code} =</span>
                    <input
                      type="number"
                      step="0.01"
                      disabled={cur.code === settings.baseCurrency}
                      value={cur.exchangeRateToBase}
                      onChange={e => updateExchangeRate(cur.code, Number(e.target.value))}
                      className="w-20 text-xs font-mono font-bold text-right bg-white border border-slate-200 rounded px-2 py-1 disabled:bg-slate-100 disabled:text-slate-400"
                    />
                    <span className="text-[10px] text-slate-500 font-mono">{settings.baseCurrency}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* System Data Reset Options Card */}
          <div className="bg-white rounded-xl border border-slate-200 shadow-2xs p-5 space-y-4">
            <div className="border-b border-slate-100 pb-2.5">
              <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
                <RotateCcw className="w-4 h-4 text-rose-600" />
                <span>Data Reset & Maintenance</span>
              </h3>
              <p className="text-[11px] text-slate-500 mt-0.5">
                Choose a targeted reset option depending on your operational needs.
              </p>
            </div>

            <div className="space-y-3">
              {/* Option 1: Fresh Blank Slate */}
              <div className="p-3 rounded-lg border border-slate-200 bg-slate-50 hover:bg-slate-100/50 transition-colors">
                <div className="flex items-center justify-between">
                  <div className="font-semibold text-xs text-slate-800">Fresh Blank Slate (Zero Data)</div>
                  <span className="text-[10px] uppercase font-bold text-rose-600 bg-rose-50 px-1.5 py-0.5 rounded border border-rose-200">
                    Empty App
                  </span>
                </div>
                <p className="text-[11px] text-slate-500 mt-1">
                  Wipes all pre-listed customers, vendors, invoices, bills, and bank accounts so you can input fresh live business records.
                </p>
                <button
                  type="button"
                  onClick={() => setConfirmModal({
                    isOpen: true,
                    title: 'Reset to Fresh Blank Slate?',
                    description: 'This will completely erase all customers, vendors, invoices, bills, expenses, and bank accounts. The system will start empty with zero records. Are you sure?',
                    actionType: 'fresh_blank',
                    confirmLabel: 'Confirm Wipe & Blank Slate'
                  })}
                  className="mt-2.5 w-full py-1.5 text-xs font-semibold text-rose-700 bg-rose-50 hover:bg-rose-100 border border-rose-200 rounded-md transition-colors flex items-center justify-center gap-1.5"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Wipe All & Start Blank</span>
                </button>
              </div>

              {/* Option 2: Clear Transactions Only */}
              <div className="p-3 rounded-lg border border-slate-200 bg-slate-50 hover:bg-slate-100/50 transition-colors">
                <div className="flex items-center justify-between">
                  <div className="font-semibold text-xs text-slate-800">Clear Transactions Only</div>
                  <span className="text-[10px] uppercase font-bold text-amber-700 bg-amber-50 px-1.5 py-0.5 rounded border border-amber-200">
                    Keep Contacts
                  </span>
                </div>
                <p className="text-[11px] text-slate-500 mt-1">
                  Removes all sales invoices, estimates, orders, vendor bills, and expenses, but retains your customer and vendor directory.
                </p>
                <button
                  type="button"
                  onClick={() => setConfirmModal({
                    isOpen: true,
                    title: 'Clear All Transactions?',
                    description: 'This will remove all invoices, estimates, sales orders, bills, and direct expenses. Your customer and vendor contact lists will remain intact.',
                    actionType: 'clear_txns',
                    confirmLabel: 'Clear All Transactions'
                  })}
                  className="mt-2.5 w-full py-1.5 text-xs font-semibold text-amber-800 bg-amber-50 hover:bg-amber-100 border border-amber-200 rounded-md transition-colors flex items-center justify-center gap-1.5"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Clear Transactions</span>
                </button>
              </div>

              {/* Option 3: Load Standard Demo Data */}
              <div className="p-3 rounded-lg border border-slate-200 bg-slate-50 hover:bg-slate-100/50 transition-colors">
                <div className="flex items-center justify-between">
                  <div className="font-semibold text-xs text-slate-800">Load Standard Demo Dataset</div>
                  <span className="text-[10px] uppercase font-bold text-blue-700 bg-blue-50 px-1.5 py-0.5 rounded border border-blue-200">
                    Sample Data
                  </span>
                </div>
                <p className="text-[11px] text-slate-500 mt-1">
                  Loads compliant demo customers, vendors, invoices, and bills with verified GSTIN, PAN, and TDS deductions for evaluation.
                </p>
                <button
                  type="button"
                  onClick={() => setConfirmModal({
                    isOpen: true,
                    title: 'Load Standard Demo Dataset?',
                    description: 'This will load sample customers, vendors, bills with TDS, and invoices for testing calculations and tax reporting.',
                    actionType: 'load_demo',
                    confirmLabel: 'Load Demo Dataset'
                  })}
                  className="mt-2.5 w-full py-1.5 text-xs font-semibold text-blue-700 bg-blue-50 hover:bg-blue-100 border border-blue-200 rounded-md transition-colors flex items-center justify-center gap-1.5"
                >
                  <FileCheck className="w-3.5 h-3.5" />
                  <span>Load Sample Demo Data</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

