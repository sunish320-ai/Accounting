import React, { useState } from 'react';
import { useAccounting } from '../../context/AccountingContext';
import {
  Clock,
  Send,
  Plus,
  Play,
  CheckCircle2,
  AlertCircle,
  Mail,
  MessageSquare,
  Repeat,
  Sparkles,
  ToggleLeft,
  ToggleRight,
  X
} from 'lucide-react';
import { RecurringInvoiceConfig, PaymentReminderRule, CurrencyCode } from '../../types';

export const RecurringAndRemindersView: React.FC = () => {
  const {
    recurringConfigs,
    toggleRecurringConfig,
    triggerRecurringRunNow,
    createRecurringConfig,
    reminderRules,
    updateReminderRule,
    runAutomatedRemindersCheck,
    customers,
    currencies,
    formatMoney,
    invoices
  } = useAccounting();

  const [activeTab, setActiveTab] = useState<'recurring' | 'reminders'>('recurring');
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);

  // Form state for new recurring profile
  const [customerId, setCustomerId] = useState(customers[0]?.id || '');
  const [frequency, setFrequency] = useState<'weekly' | 'monthly' | 'quarterly' | 'annually'>('monthly');
  const [amount, setAmount] = useState(50000);
  const [currency, setCurrency] = useState<CurrencyCode>('INR');
  const [description, setDescription] = useState('Monthly Cloud DevOps & Security SLA Retainer');
  const [autoSend, setAutoSend] = useState(true);

  // Automated cron execution result state
  const [cronResult, setCronResult] = useState<{ count: number; messages: string[] } | null>(null);

  const handleRunNow = (id: string, name: string) => {
    const inv = triggerRecurringRunNow(id);
    setToastMessage(`Generated invoice ${inv.invoiceNumber} for ${name} (${formatMoney(inv.totalAmount, inv.currency)})`);
    setTimeout(() => setToastMessage(null), 4000);
  };

  const handleRunCronReminders = () => {
    const res = runAutomatedRemindersCheck();
    setCronResult(res);
    setToastMessage(`Executed automated reminder scheduler: ${res.count} reminders processed.`);
    setTimeout(() => setToastMessage(null), 4000);
  };

  const handleCreateRecurring = (e: React.FormEvent) => {
    e.preventDefault();
    const cust = customers.find(c => c.id === customerId);
    if (!cust) return;

    const nextDateObj = new Date();
    nextDateObj.setDate(nextDateObj.getDate() + (frequency === 'weekly' ? 7 : frequency === 'monthly' ? 30 : 90));
    const nextRunDate = nextDateObj.toISOString().split('T')[0];

    createRecurringConfig({
      customerId: cust.id,
      customerName: cust.companyName,
      frequency,
      nextRunDate,
      autoSendEmail: autoSend,
      active: true,
      amount,
      currency,
      description
    });

    setIsCreateModalOpen(false);
    setToastMessage(`Created recurring schedule for ${cust.companyName}`);
    setTimeout(() => setToastMessage(null), 3000);
  };

  // Aggregated reminder logs from all invoices
  const allLogs = invoices.flatMap(inv => (inv.remindersSent || []).map(r => ({ ...r, invoiceNumber: inv.invoiceNumber })))
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      {/* Toast */}
      {toastMessage && (
        <div className="fixed bottom-5 right-5 z-50 bg-slate-900 text-white text-xs px-4 py-2.5 rounded-lg shadow-xl flex items-center gap-2 border border-slate-700 animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Top Banner & Tab Controls */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-2xs p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-base font-bold text-slate-900 flex items-center gap-2">
            <Repeat className="w-5 h-5 text-blue-600" />
            <span>Automated Invoicing & Payment Reminders</span>
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Configure automated recurring billing schedules and multi-tier email/WhatsApp payment chase rules
          </p>
        </div>

        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg text-xs font-medium">
            <button
              onClick={() => setActiveTab('recurring')}
              className={`px-3 py-1.5 rounded-md transition-colors ${
                activeTab === 'recurring'
                  ? 'bg-white text-slate-900 shadow-xs font-semibold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Recurring Profiles ({recurringConfigs.length})
            </button>
            <button
              onClick={() => setActiveTab('reminders')}
              className={`px-3 py-1.5 rounded-md transition-colors ${
                activeTab === 'reminders'
                  ? 'bg-white text-slate-900 shadow-xs font-semibold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Payment Reminders Engine
            </button>
          </div>

          {activeTab === 'recurring' ? (
            <button
              onClick={() => setIsCreateModalOpen(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs transition-colors shrink-0"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>New Schedule</span>
            </button>
          ) : (
            <button
              onClick={handleRunCronReminders}
              className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs transition-colors shrink-0"
            >
              <Play className="w-3.5 h-3.5" />
              <span>Run Automated Chase Now</span>
            </button>
          )}
        </div>
      </div>

      {activeTab === 'recurring' ? (
        /* Recurring Invoices Tab */
        <div className="space-y-4">
          <div className="bg-white rounded-xl border border-slate-200 shadow-2xs overflow-hidden">
            <div className="p-4 border-b border-slate-200 bg-slate-50/50 flex items-center justify-between">
              <div>
                <h2 className="text-xs font-bold text-slate-800 uppercase tracking-wider">Active Recurring Profiles</h2>
                <p className="text-[11px] text-slate-500">Automates regular client subscriptions and retainers</p>
              </div>
              <span className="text-xs text-slate-500 font-mono">
                {recurringConfigs.filter(c => c.active).length} of {recurringConfigs.length} Active
              </span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-slate-600">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50/75 text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
                    <th className="py-2.5 px-4">Customer</th>
                    <th className="py-2.5 px-3">Description</th>
                    <th className="py-2.5 px-3">Frequency</th>
                    <th className="py-2.5 px-3">Next Schedule</th>
                    <th className="py-2.5 px-3">Auto-Email</th>
                    <th className="py-2.5 px-3 text-right">Amount</th>
                    <th className="py-2.5 px-3 text-center">Status</th>
                    <th className="py-2.5 px-4 text-center">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {recurringConfigs.map(cfg => (
                    <tr key={cfg.id} className="hover:bg-slate-50/60 transition-colors">
                      <td className="py-3 px-4 font-semibold text-slate-800">
                        {cfg.customerName}
                      </td>
                      <td className="py-3 px-3 text-slate-600 max-w-xs truncate">
                        {cfg.description}
                      </td>
                      <td className="py-3 px-3 capitalize font-medium text-slate-700">
                        {cfg.frequency}
                      </td>
                      <td className="py-3 px-3 text-slate-600 font-mono">
                        {cfg.nextRunDate}
                      </td>
                      <td className="py-3 px-3">
                        <span className={`text-[10px] font-medium px-2 py-0.5 rounded ${
                          cfg.autoSendEmail ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' : 'bg-slate-100 text-slate-600'
                        }`}>
                          {cfg.autoSendEmail ? 'Auto-Sent' : 'Draft Only'}
                        </span>
                      </td>
                      <td className="py-3 px-3 text-right font-mono font-bold text-slate-900 tabular-nums">
                        {formatMoney(cfg.amount, cfg.currency)}
                      </td>
                      <td className="py-3 px-3 text-center">
                        <button
                          onClick={() => toggleRecurringConfig(cfg.id)}
                          className="text-xs focus:outline-none"
                          title="Toggle active status"
                        >
                          {cfg.active ? (
                            <span className="text-emerald-700 font-medium bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded text-[10px]">
                              Active
                            </span>
                          ) : (
                            <span className="text-slate-400 font-medium bg-slate-100 px-2 py-0.5 rounded text-[10px]">
                              Paused
                            </span>
                          )}
                        </button>
                      </td>
                      <td className="py-3 px-4 text-center">
                        <button
                          onClick={() => handleRunNow(cfg.id, cfg.customerName)}
                          className="px-2.5 py-1 text-[11px] font-semibold text-blue-600 hover:text-white hover:bg-blue-600 border border-blue-200 rounded-md transition-colors flex items-center gap-1 mx-auto"
                          title="Simulate immediate cron trigger: creates invoice & journals"
                        >
                          <Play className="w-3 h-3" />
                          <span>Generate Now</span>
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      ) : (
        /* Automated Payment Reminders Tab */
        <div className="space-y-6">
          {/* Cron Trigger Feedback Banner */}
          {cronResult && (
            <div className="p-4 bg-blue-50 border border-blue-200 rounded-xl space-y-2 text-xs animate-in fade-in">
              <div className="font-bold text-blue-900 flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-blue-600" />
                <span>Automated Reminder Cycle Complete ({cronResult.count} Reminders Dispatched)</span>
              </div>
              <div className="space-y-1 text-slate-700 pl-5">
                {cronResult.messages.length === 0 ? (
                  <p className="text-slate-500 italic">All pending invoices are outside the active trigger day thresholds.</p>
                ) : (
                  cronResult.messages.map((m, idx) => (
                    <div key={idx} className="font-mono text-[11px]">· {m}</div>
                  ))
                )}
              </div>
            </div>
          )}

          {/* Rules Configurator */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {reminderRules.map(rule => (
              <div
                key={rule.id}
                className="bg-white rounded-xl border border-slate-200 p-5 shadow-2xs space-y-3"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    {rule.channel === 'email' ? (
                      <Mail className="w-4 h-4 text-blue-600" />
                    ) : (
                      <MessageSquare className="w-4 h-4 text-emerald-600" />
                    )}
                    <h3 className="text-xs font-bold text-slate-900">{rule.title}</h3>
                  </div>

                  <button
                    onClick={() => updateReminderRule(rule.id, { enabled: !rule.enabled })}
                    className="focus:outline-none"
                  >
                    {rule.enabled ? (
                      <ToggleRight className="w-6 h-6 text-blue-600" />
                    ) : (
                      <ToggleLeft className="w-6 h-6 text-slate-300" />
                    )}
                  </button>
                </div>

                <div className="text-[11px] text-slate-500 font-mono">
                  Trigger: {rule.triggerDays < 0 ? `${Math.abs(rule.triggerDays)} days before due date` : rule.triggerDays === 0 ? 'On due date' : `${rule.triggerDays} days overdue`}
                </div>

                <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 text-xs space-y-1.5">
                  <div className="font-semibold text-slate-800 text-[11px]">
                    Subject: {rule.subject}
                  </div>
                  <pre className="text-[11px] text-slate-600 whitespace-pre-wrap font-sans">
                    {rule.bodyTemplate}
                  </pre>
                </div>
              </div>
            ))}
          </div>

          {/* Live Reminder Audit Log */}
          <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-2xs space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                  Dispatched Payment Reminders Audit Trail
                </h3>
                <p className="text-[11px] text-slate-500">
                  Real-time record of all automated and manual debtor chase communications
                </p>
              </div>
              <span className="text-xs text-slate-500 font-mono">{allLogs.length} Records</span>
            </div>

            <div className="space-y-2">
              {allLogs.length === 0 ? (
                <div className="text-center py-6 text-slate-400 text-xs">
                  No reminder logs yet. Click "Run Automated Chase Now" or send a reminder from Invoices view.
                </div>
              ) : (
                allLogs.map(log => (
                  <div
                    key={log.id}
                    className="p-3 bg-slate-50/80 rounded-lg border border-slate-200/80 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-slate-800">{log.invoiceNumber}</span>
                        <span className="text-slate-300">·</span>
                        <span className="font-medium text-slate-700">{log.recipient}</span>
                        <span className={`text-[10px] font-bold uppercase px-1.5 py-0.5 rounded ${
                          log.channel === 'whatsapp' ? 'bg-emerald-100 text-emerald-800' : 'bg-blue-100 text-blue-800'
                        }`}>
                          {log.channel}
                        </span>
                      </div>
                      <div className="text-[11px] text-slate-600 mt-1 line-clamp-1">
                        {log.message}
                      </div>
                    </div>
                    <div className="text-[11px] text-slate-400 font-mono whitespace-nowrap">
                      {log.date}
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}

      {/* Create Recurring Schedule Modal */}
      {isCreateModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-xs p-4">
          <div className="bg-white w-full max-w-lg rounded-2xl shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95">
            <div className="px-6 py-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-slate-900">New Recurring Invoice Profile</h3>
                <p className="text-xs text-slate-500">Auto-generates sales invoices at scheduled cadences</p>
              </div>
              <button
                onClick={() => setIsCreateModalOpen(false)}
                className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateRecurring} className="p-6 space-y-4 text-xs">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Customer <span className="text-rose-500">*</span>
                </label>
                <select
                  value={customerId}
                  onChange={e => setCustomerId(e.target.value)}
                  className="w-full text-xs bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 font-medium"
                >
                  {customers.map(c => (
                    <option key={c.id} value={c.id}>{c.companyName} ({c.name})</option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Cadence / Frequency
                  </label>
                  <select
                    value={frequency}
                    onChange={e => setFrequency(e.target.value as any)}
                    className="w-full text-xs bg-slate-50 border border-slate-200 rounded-lg px-3 py-2"
                  >
                    <option value="weekly">Weekly</option>
                    <option value="monthly">Monthly</option>
                    <option value="quarterly">Quarterly</option>
                    <option value="annually">Annually</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Currency
                  </label>
                  <select
                    value={currency}
                    onChange={e => setCurrency(e.target.value as CurrencyCode)}
                    className="w-full text-xs bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 font-mono font-semibold"
                  >
                    {currencies.map(c => (
                      <option key={c.code} value={c.code}>{c.code} ({c.symbol})</option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Billing Amount ({currency}) <span className="text-rose-500">*</span>
                </label>
                <input
                  type="number"
                  min="1"
                  value={amount}
                  onChange={e => setAmount(Number(e.target.value))}
                  className="w-full text-sm font-mono font-bold bg-slate-50 border border-slate-200 rounded-lg px-3 py-2"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Description / Service Line
                </label>
                <input
                  type="text"
                  value={description}
                  onChange={e => setDescription(e.target.value)}
                  className="w-full text-xs bg-slate-50 border border-slate-200 rounded-lg px-3 py-2"
                  required
                />
              </div>

              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                <label className="flex items-center gap-2 cursor-pointer font-semibold text-slate-800">
                  <input
                    type="checkbox"
                    checked={autoSend}
                    onChange={e => setAutoSend(e.target.checked)}
                    className="rounded text-blue-600 focus:ring-blue-500 w-4 h-4"
                  />
                  <span>Automatically email invoice to client when generated</span>
                </label>
              </div>

              <div className="pt-2 flex items-center justify-end gap-2 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setIsCreateModalOpen(false)}
                  className="px-4 py-2 text-xs font-medium text-slate-600 hover:bg-slate-100 rounded-lg"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs"
                >
                  Create Schedule
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
