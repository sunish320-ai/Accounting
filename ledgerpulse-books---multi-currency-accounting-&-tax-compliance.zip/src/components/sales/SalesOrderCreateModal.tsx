import React, { useState } from 'react';
import { useAccounting } from '../../context/AccountingContext';
import { X, Plus, Trash2, ShoppingCart } from 'lucide-react';
import { InvoiceItem, CurrencyCode } from '../../types';

interface SalesOrderCreateModalProps {
  isOpen: boolean;
  onClose: () => void;
  preSelectedCustomerId?: string;
  preselectedCustomerId?: string;
}

export const SalesOrderCreateModal: React.FC<SalesOrderCreateModalProps> = ({
  isOpen,
  onClose,
  preSelectedCustomerId,
  preselectedCustomerId,
}) => {
  const { customers, currencies, taxRates, createSalesOrder, salesOrders } = useAccounting();

  if (!isOpen) return null;

  const [selectedCustomerId, setSelectedCustomerId] = useState(
    preselectedCustomerId || preSelectedCustomerId || customers[0]?.id || ''
  );
  const currentCustomer = customers.find(c => c.id === selectedCustomerId) || customers[0];

  const [orderNumber, setOrderNumber] = useState(`SO-2026-00${salesOrders.length + 25}`);
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);

  const defaultDelivery = new Date();
  defaultDelivery.setDate(defaultDelivery.getDate() + 20);
  const [expectedDeliveryDate, setExpectedDeliveryDate] = useState(defaultDelivery.toISOString().split('T')[0]);

  const [currency, setCurrency] = useState<CurrencyCode>(currentCustomer?.currency || 'INR');
  const isInterState = currentCustomer ? !currentCustomer.placeOfSupply.includes('Maharashtra') : false;

  const [items, setItems] = useState<InvoiceItem[]>([
    {
      id: `so-item-${Date.now()}`,
      description: 'Production Microservices Architecture & DevOps Deployment',
      hsnSac: '998313',
      quantity: 1,
      unitRate: 140000,
      discountPercent: 0,
      taxRateId: 'tax-gst-18',
      taxableAmount: 140000,
      cgstAmount: 12600,
      sgstAmount: 12600,
      igstAmount: 0,
      totalAmount: 165200
    }
  ]);

  const updateRow = (index: number, updates: Partial<InvoiceItem>) => {
    setItems(prev => {
      const next = [...prev];
      const item = { ...next[index], ...updates };

      const raw = (item.quantity || 0) * (item.unitRate || 0);
      const discount = raw * ((item.discountPercent || 0) / 100);
      const taxable = raw - discount;

      const rateObj = taxRates.find(t => t.id === item.taxRateId);
      const ratePct = rateObj ? rateObj.rate : 0;

      let cgst = 0;
      let sgst = 0;
      let igst = 0;

      if (isInterState) {
        igst = taxable * (ratePct / 100);
      } else {
        cgst = taxable * (ratePct / 200);
        sgst = taxable * (ratePct / 200);
      }

      next[index] = {
        ...item,
        taxableAmount: taxable,
        cgstAmount: cgst,
        sgstAmount: sgst,
        igstAmount: igst,
        totalAmount: taxable + (isInterState ? igst : cgst + sgst)
      };
      return next;
    });
  };

  const addRow = () => {
    setItems([
      ...items,
      {
        id: `so-item-${Date.now()}-${items.length}`,
        description: '',
        hsnSac: '998311',
        quantity: 1,
        unitRate: 0,
        discountPercent: 0,
        taxRateId: 'tax-gst-18',
        taxableAmount: 0,
        cgstAmount: 0,
        sgstAmount: 0,
        igstAmount: 0,
        totalAmount: 0
      }
    ]);
  };

  const removeRow = (index: number) => {
    if (items.length <= 1) return;
    setItems(items.filter((_, idx) => idx !== index));
  };

  const subtotal = items.reduce((sum, i) => sum + i.taxableAmount, 0);
  const totalTax = items.reduce((sum, i) => sum + (i.cgstAmount + i.sgstAmount + i.igstAmount), 0);
  const grandTotal = subtotal + totalTax;

  const curObj = currencies.find(c => c.code === currency) || { exchangeRateToBase: 1 };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentCustomer) return;

    createSalesOrder({
      orderNumber,
      customerId: currentCustomer.id,
      customerName: currentCustomer.companyName,
      customerTaxId: currentCustomer.taxId,
      placeOfSupply: currentCustomer.placeOfSupply,
      date,
      expectedDeliveryDate,
      status: 'confirmed',
      currency,
      exchangeRate: curObj.exchangeRateToBase,
      items,
      subtotal,
      totalTax,
      totalAmount: grandTotal,
      notes: 'Customer order booked. Delivery SLA tracking initiated.'
    });

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="bg-white w-full max-w-3xl rounded-2xl shadow-2xl border border-slate-200 overflow-hidden my-6 animate-in fade-in zoom-in-95">
        <div className="px-6 py-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
          <div>
            <h2 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <ShoppingCart className="w-4 h-4 text-blue-600" />
              <span>Create Sales Order</span>
            </h2>
            <p className="text-xs text-slate-500">Record formal customer commitment prior to invoicing</p>
          </div>
          <button onClick={onClose} className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4 max-h-[75vh] overflow-y-auto text-xs">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-slate-700 font-semibold mb-1">Customer <span className="text-rose-500">*</span></label>
              <select
                value={selectedCustomerId}
                onChange={e => setSelectedCustomerId(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 font-medium"
              >
                {customers.map(c => (
                  <option key={c.id} value={c.id}>{c.companyName}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-slate-700 font-semibold mb-1">Sales Order # <span className="text-rose-500">*</span></label>
              <input
                type="text"
                value={orderNumber}
                onChange={e => setOrderNumber(e.target.value)}
                className="w-full font-mono font-semibold text-blue-600 bg-slate-50 border border-slate-200 rounded-lg px-3 py-2"
                required
              />
            </div>

            <div>
              <label className="block text-slate-700 font-semibold mb-1">Currency</label>
              <select
                value={currency}
                onChange={e => setCurrency(e.target.value as CurrencyCode)}
                className="w-full font-mono font-semibold bg-slate-50 border border-slate-200 rounded-lg px-3 py-2"
              >
                {currencies.map(c => (
                  <option key={c.code} value={c.code}>{c.code} ({c.symbol})</option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-slate-700 font-semibold mb-1">Order Date</label>
              <input
                type="date"
                value={date}
                onChange={e => setDate(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2"
              />
            </div>
            <div>
              <label className="block text-slate-700 font-semibold mb-1">Expected Delivery Date</label>
              <input
                type="date"
                value={expectedDeliveryDate}
                onChange={e => setExpectedDeliveryDate(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2"
              />
            </div>
          </div>

          {/* Line items */}
          <div className="space-y-2">
            <h3 className="font-bold text-slate-800 uppercase tracking-wider text-[11px]">Deliverables & Items</h3>
            <div className="border border-slate-200 rounded-lg overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="bg-slate-100 text-slate-600 font-semibold border-b border-slate-200">
                    <th className="py-2 px-3 w-5/12">Item Description</th>
                    <th className="py-2 px-2 w-20">HSN/SAC</th>
                    <th className="py-2 px-2 w-16 text-right">Qty</th>
                    <th className="py-2 px-2 w-28 text-right">Unit Rate</th>
                    <th className="py-2 px-2 w-28">GST Rate</th>
                    <th className="py-2 px-3 w-28 text-right">Total</th>
                    <th className="py-2 px-1 w-8 text-center"></th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {items.map((item, idx) => (
                    <tr key={item.id}>
                      <td className="py-2 px-3">
                        <input
                          type="text"
                          value={item.description}
                          onChange={e => updateRow(idx, { description: e.target.value })}
                          className="w-full bg-transparent border-0 focus:ring-0 p-0 text-slate-800 font-medium"
                          required
                        />
                      </td>
                      <td className="py-2 px-2">
                        <input
                          type="text"
                          value={item.hsnSac}
                          onChange={e => updateRow(idx, { hsnSac: e.target.value })}
                          className="w-full font-mono bg-transparent border-0 focus:ring-0 p-0 text-slate-600"
                        />
                      </td>
                      <td className="py-2 px-2 text-right">
                        <input
                          type="number"
                          min="1"
                          value={item.quantity}
                          onChange={e => updateRow(idx, { quantity: Number(e.target.value) })}
                          className="w-full font-mono text-right bg-transparent border-0 focus:ring-0 p-0"
                        />
                      </td>
                      <td className="py-2 px-2 text-right">
                        <input
                          type="number"
                          min="0"
                          value={item.unitRate}
                          onChange={e => updateRow(idx, { unitRate: Number(e.target.value) })}
                          className="w-full font-mono text-right bg-transparent border-0 focus:ring-0 p-0 font-medium"
                        />
                      </td>
                      <td className="py-2 px-2">
                        <select
                          value={item.taxRateId}
                          onChange={e => updateRow(idx, { taxRateId: e.target.value })}
                          className="w-full text-[11px] bg-slate-50 border border-slate-200 rounded px-1 py-1"
                        >
                          {taxRates.map(r => (
                            <option key={r.id} value={r.id}>{r.name}</option>
                          ))}
                        </select>
                      </td>
                      <td className="py-2 px-3 text-right font-mono font-bold text-slate-900 tabular-nums">
                        {item.totalAmount.toLocaleString()}
                      </td>
                      <td className="py-2 px-1 text-center">
                        <button
                          type="button"
                          onClick={() => removeRow(idx)}
                          disabled={items.length <= 1}
                          className="text-slate-300 hover:text-rose-500"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <button
              type="button"
              onClick={addRow}
              className="text-xs text-blue-600 hover:text-blue-700 font-semibold flex items-center gap-1 pt-1"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Line Item</span>
            </button>
          </div>

          <div className="flex justify-end pt-2">
            <div className="w-full md:w-5/12 bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-1.5 text-xs">
              <div className="flex justify-between text-slate-600">
                <span>Taxable Subtotal:</span>
                <span className="font-mono">{subtotal.toLocaleString()}</span>
              </div>
              <div className="flex justify-between text-slate-600">
                <span>GST Tax:</span>
                <span className="font-mono">{totalTax.toLocaleString()}</span>
              </div>
              <div className="flex justify-between font-bold text-sm text-slate-900 border-t border-slate-200 pt-1.5">
                <span>Order Total:</span>
                <span className="font-mono">{currency} {grandTotal.toLocaleString()}</span>
              </div>
            </div>
          </div>

          <div className="pt-2 flex items-center justify-end gap-2 border-t border-slate-200">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-slate-600 hover:bg-slate-100 rounded-lg"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs"
            >
              Confirm Sales Order
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
