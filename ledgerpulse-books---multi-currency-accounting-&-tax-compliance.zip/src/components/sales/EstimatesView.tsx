import React, { useState } from 'react';
import { useAccounting } from '../../context/AccountingContext';
import {
  FileCheck2,
  Plus,
  Search,
  CheckCircle2,
  ShoppingCart,
  FileText,
  Clock,
  Edit2,
  Copy,
  Trash2,
  AlertTriangle
} from 'lucide-react';
import { Estimate, EstimateStatus } from '../../types';

interface EstimatesViewProps {
  onOpenCreateEstimate: () => void;
  onEditEstimate?: (est: Estimate) => void;
  onNavigateToInvoices: () => void;
  onNavigateToSalesOrders: () => void;
}

export const EstimatesView: React.FC<EstimatesViewProps> = ({
  onOpenCreateEstimate,
  onEditEstimate,
  onNavigateToInvoices,
  onNavigateToSalesOrders,
}) => {
  const {
    estimates,
    formatMoney,
    convertEstimateToSalesOrder,
    convertEstimateToInvoice,
    deleteEstimate,
    duplicateEstimate
  } = useAccounting();

  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);

  const filteredEstimates = estimates.filter(est => {
    const matchesSearch =
      est.estimateNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      est.customerName.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || est.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const handleConvertToOrder = (id: string, num: string) => {
    convertEstimateToSalesOrder(id);
    setToastMessage(`Estimate ${num} converted to Sales Order.`);
    setTimeout(() => {
      setToastMessage(null);
      onNavigateToSalesOrders();
    }, 1500);
  };

  const handleConvertToInvoice = (id: string, num: string) => {
    convertEstimateToInvoice(id);
    setToastMessage(`Estimate ${num} converted to Tax Invoice.`);
    setTimeout(() => {
      setToastMessage(null);
      onNavigateToInvoices();
    }, 1500);
  };

  const handleDuplicate = (id: string, num: string) => {
    duplicateEstimate(id);
    setToastMessage(`Estimate ${num} duplicated successfully.`);
    setTimeout(() => setToastMessage(null), 3000);
  };

  const handleDelete = (id: string, num: string) => {
    deleteEstimate(id);
    setDeleteConfirmId(null);
    setToastMessage(`Estimate ${num} deleted.`);
    setTimeout(() => setToastMessage(null), 3000);
  };

  const getStatusBadge = (status: EstimateStatus) => {
    switch (status) {
      case 'accepted':
        return <span className="bg-emerald-50 text-emerald-700 border border-emerald-200 text-[10px] font-bold px-2 py-0.5 rounded uppercase">Accepted</span>;
      case 'sent':
        return <span className="bg-blue-50 text-blue-700 border border-blue-200 text-[10px] font-bold px-2 py-0.5 rounded uppercase">Sent</span>;
      case 'invoiced':
        return <span className="bg-purple-50 text-purple-700 border border-purple-200 text-[10px] font-bold px-2 py-0.5 rounded uppercase">Invoiced</span>;
      case 'declined':
        return <span className="bg-rose-50 text-rose-700 border border-rose-200 text-[10px] font-bold px-2 py-0.5 rounded uppercase">Declined</span>;
      default:
        return <span className="bg-slate-100 text-slate-700 border border-slate-200 text-[10px] font-bold px-2 py-0.5 rounded uppercase">Draft</span>;
    }
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-5 right-5 z-50 bg-slate-900 text-white text-xs px-4 py-2.5 rounded-lg shadow-xl flex items-center gap-2 border border-slate-700 animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Top Banner */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-2xs p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-base font-bold text-slate-900 flex items-center gap-2">
            <FileCheck2 className="w-5 h-5 text-blue-600" />
            <span>Sales Estimates & Quotes</span>
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Prepare proposals, send estimates with expiry terms, and convert to orders or invoices in 1-click
          </p>
        </div>

        <button
          onClick={onOpenCreateEstimate}
          className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs transition-colors shrink-0"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>New Estimate</span>
        </button>
      </div>

      {/* Estimates Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-2xs p-4 space-y-4">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="relative w-full sm:w-80">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Search by estimate number or customer..."
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-500"
            />
          </div>

          <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg text-xs font-medium self-start sm:self-auto">
            {['all', 'draft', 'sent', 'accepted', 'invoiced'].map(st => (
              <button
                key={st}
                onClick={() => setStatusFilter(st)}
                className={`px-2.5 py-1 rounded-md transition-colors capitalize ${
                  statusFilter === st ? 'bg-white text-slate-900 shadow-xs font-semibold' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {st}
              </button>
            ))}
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-600 border-collapse">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-50/75 text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
                <th className="py-2.5 px-3">Date</th>
                <th className="py-2.5 px-3">Estimate #</th>
                <th className="py-2.5 px-3">Customer Name</th>
                <th className="py-2.5 px-3">Valid Until</th>
                <th className="py-2.5 px-3">Status</th>
                <th className="py-2.5 px-3 text-right">Quoted Amount</th>
                <th className="py-2.5 px-3 text-center">Actions (Edit / Duplicate / Delete / Convert)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredEstimates.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-slate-400">
                    <Clock className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                    <p className="font-medium text-slate-600">No estimates found</p>
                    <p className="text-[11px] text-slate-400 mt-1">Create an estimate or quote to present pricing to your clients</p>
                    <button
                      onClick={onOpenCreateEstimate}
                      className="mt-3 inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs"
                    >
                      <Plus className="w-3.5 h-3.5" /> Create Estimate
                    </button>
                  </td>
                </tr>
              ) : (
                filteredEstimates.map(est => (
                  <tr key={est.id} className="hover:bg-slate-50/70 transition-colors">
                    <td className="py-3 px-3 text-slate-500 font-mono whitespace-nowrap">{est.date}</td>
                    <td className="py-3 px-3 font-semibold text-blue-600 font-mono whitespace-nowrap">
                      {est.estimateNumber}
                    </td>
                    <td className="py-3 px-3 font-medium text-slate-800 max-w-xs truncate">
                      {est.customerName}
                    </td>
                    <td className="py-3 px-3 text-slate-500 font-mono whitespace-nowrap">
                      {est.expiryDate}
                    </td>
                    <td className="py-3 px-3 whitespace-nowrap">
                      {getStatusBadge(est.status)}
                    </td>
                    <td className="py-3 px-3 text-right font-mono font-bold text-slate-900 tabular-nums whitespace-nowrap">
                      {formatMoney(est.totalAmount, est.currency)}
                    </td>
                    <td className="py-3 px-3 text-center whitespace-nowrap">
                      <div className="flex items-center justify-center gap-1">
                        {/* 1. Edit */}
                        {onEditEstimate && (
                          <button
                            onClick={() => onEditEstimate(est)}
                            className="p-1.5 text-slate-500 hover:text-blue-600 hover:bg-blue-50 rounded transition-colors"
                            title="Edit estimate"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                        )}

                        {/* 2. Duplicate */}
                        <button
                          onClick={() => handleDuplicate(est.id, est.estimateNumber)}
                          className="p-1.5 text-slate-500 hover:text-emerald-600 hover:bg-emerald-50 rounded transition-colors"
                          title="Duplicate estimate"
                        >
                          <Copy className="w-3.5 h-3.5" />
                        </button>

                        {/* 3. Delete */}
                        <button
                          onClick={() => setDeleteConfirmId(est.id)}
                          className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded transition-colors"
                          title="Delete estimate"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>

                        <div className="w-px h-3.5 bg-slate-200 mx-0.5" />

                        {/* Conversions */}
                        {est.status !== 'invoiced' ? (
                          <>
                            <button
                              onClick={() => handleConvertToOrder(est.id, est.estimateNumber)}
                              className="px-2 py-1 text-[10px] font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded transition-colors flex items-center gap-1"
                              title="Generate Sales Order"
                            >
                              <ShoppingCart className="w-3 h-3 text-blue-600" />
                              <span>To Order</span>
                            </button>

                            <button
                              onClick={() => handleConvertToInvoice(est.id, est.estimateNumber)}
                              className="px-2 py-1 text-[10px] font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded transition-colors shadow-2xs flex items-center gap-1"
                              title="Convert to Final Tax Invoice"
                            >
                              <FileText className="w-3 h-3" />
                              <span>To Invoice</span>
                            </button>
                          </>
                        ) : (
                          <span className="text-purple-700 text-[11px] font-medium px-2">Invoiced</span>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Delete Confirmation Modal */}
      {deleteConfirmId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4">
          <div className="bg-white w-full max-w-sm rounded-xl p-5 shadow-2xl border border-slate-200 space-y-3">
            <div className="flex items-center gap-2 text-rose-600 font-bold text-sm">
              <AlertTriangle className="w-4 h-4" />
              <span>Confirm Delete Estimate</span>
            </div>
            <p className="text-xs text-slate-600">
              Are you sure you want to delete this estimate? This will remove the quotation.
            </p>
            <div className="flex justify-end gap-2 pt-2">
              <button
                onClick={() => setDeleteConfirmId(null)}
                className="px-3 py-1.5 text-xs text-slate-600 hover:bg-slate-100 rounded-lg"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  const est = estimates.find(e => e.id === deleteConfirmId);
                  if (est) handleDelete(est.id, est.estimateNumber);
                }}
                className="px-4 py-1.5 text-xs font-semibold text-white bg-rose-600 hover:bg-rose-700 rounded-lg"
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
