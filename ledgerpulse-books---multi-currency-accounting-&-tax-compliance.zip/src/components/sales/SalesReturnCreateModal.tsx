import React, { useState } from 'react';
import { useAccounting } from '../../context/AccountingContext';
import { X, RotateCcw, AlertCircle } from 'lucide-react';
import { InvoiceItem, CurrencyCode } from '../../types';

interface SalesReturnCreateModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SalesReturnCreateModal: React.FC<SalesReturnCreateModalProps> = ({ isOpen, onClose }) => {
  const { customers, invoices, taxRates, createCreditNote, creditNotes } = useAccounting();

  if (!isOpen) return null;

  const [selectedCustomerId, setSelectedCustomerId] = useState(customers[0]?.id || '');
  const currentCustomer = customers.find(c => c.id === selectedCustomerId) || customers[0];

  const eligibleInvoices = invoices.filter(i => i.customerId === selectedCustomerId && i.status !== 'void');
  const [selectedInvoiceId, setSelectedInvoiceId] = useState<string>(eligibleInvoices[0]?.id || '');

  const [creditNoteNumber, setCreditNoteNumber] = useState(`CN-2026-000${creditNotes.length + 5}`);
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [reason, setReason] = useState('SLA downtime rebate or service scope reduction');
  const [returnAmount, setReturnAmount] = useState<number>(10000);
  const [gstRateId, setGstRateId] = useState('tax-gst-18');

  const selectedTax = taxRates.find(t => t.id === gstRateId);
  const taxPct = selectedTax ? selectedTax.rate : 18;
  const taxAmount = Math.round(returnAmount * (taxPct / 100));
  const totalAmount = returnAmount + taxAmount;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentCustomer) return;

    createCreditNote({
      creditNoteNumber,
      invoiceId: selectedInvoiceId || undefined,
      customerId: currentCustomer.id,
      customerName: currentCustomer.companyName,
      customerTaxId: currentCustomer.taxId,
      date,
      status: 'open',
      currency: currentCustomer.currency,
      exchangeRate: 1.0,
      items: [
        {
          id: `item-${Date.now()}`,
          description: reason,
          hsnSac: '998311',
          quantity: 1,
          unitRate: returnAmount,
          discountPercent: 0,
          taxRateId: gstRateId,
          taxableAmount: returnAmount,
          cgstAmount: taxAmount / 2,
          sgstAmount: taxAmount / 2,
          igstAmount: 0,
          totalAmount
        }
      ],
      subtotal: returnAmount,
      totalTax: taxAmount,
      totalAmount,
      reason,
      notes: 'GST Section 34(1) compliant credit note. Adjusts output tax liability.'
    });

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-xs p-4">
      <div className="bg-white w-full max-w-lg rounded-2xl shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95">
        <div className="px-6 py-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
          <div>
            <h2 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <RotateCcw className="w-4 h-4 text-blue-600" />
              <span>Issue Sales Return / Credit Note</span>
            </h2>
            <p className="text-xs text-slate-500">Reduces client receivable and reverses GST liability under Sec 34(1)</p>
          </div>
          <button onClick={onClose} className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-700 font-semibold mb-1">Customer <span className="text-rose-500">*</span></label>
              <select
                value={selectedCustomerId}
                onChange={e => {
                  setSelectedCustomerId(e.target.value);
                  const matching = invoices.filter(i => i.customerId === e.target.value);
                  setSelectedInvoiceId(matching[0]?.id || '');
                }}
                className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 font-medium"
              >
                {customers.map(c => (
                  <option key={c.id} value={c.id}>{c.companyName}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-slate-700 font-semibold mb-1">Credit Note # <span className="text-rose-500">*</span></label>
              <input
                type="text"
                value={creditNoteNumber}
                onChange={e => setCreditNoteNumber(e.target.value)}
                className="w-full font-mono font-semibold text-blue-600 bg-slate-50 border border-slate-200 rounded-lg px-3 py-2"
                required
              />
            </div>
          </div>

          <div>
            <label className="block text-slate-700 font-semibold mb-1">Against Invoice (Optional)</label>
            <select
              value={selectedInvoiceId}
              onChange={e => setSelectedInvoiceId(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 font-mono"
            >
              <option value="">No invoice linked (General Credit Note)</option>
              {eligibleInvoices.map(i => (
                <option key={i.id} value={i.id}>
                  {i.invoiceNumber} - Balance: {i.currency} {i.balanceDue.toLocaleString()}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-slate-700 font-semibold mb-1">Reason for Return / Credit</label>
            <input
              type="text"
              value={reason}
              onChange={e => setReason(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2"
              required
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-700 font-semibold mb-1">Credit Amount (Taxable)</label>
              <input
                type="number"
                min="1"
                value={returnAmount}
                onChange={e => setReturnAmount(Number(e.target.value))}
                className="w-full font-mono font-bold bg-slate-50 border border-slate-200 rounded-lg px-3 py-2"
                required
              />
            </div>

            <div>
              <label className="block text-slate-700 font-semibold mb-1">Applicable GST Rate</label>
              <select
                value={gstRateId}
                onChange={e => setGstRateId(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2"
              >
                {taxRates.map(r => (
                  <option key={r.id} value={r.id}>{r.name}</option>
                ))}
              </select>
            </div>
          </div>

          <div className="p-3 bg-blue-50/50 rounded-lg border border-blue-200 text-[11px] text-blue-900 flex justify-between">
            <span>Reversal Tax: ₹{taxAmount.toLocaleString()}</span>
            <span className="font-bold">Total Credit Issued: ₹{totalAmount.toLocaleString()}</span>
          </div>

          <div className="pt-2 flex items-center justify-end gap-2 border-t border-slate-200">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-slate-600 hover:bg-slate-100 rounded-lg"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs"
            >
              Issue Credit Note
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
