import React, { useState } from 'react';
import { useAccounting } from '../../context/AccountingContext';
import {
  ShoppingCart,
  Plus,
  Search,
  CheckCircle2,
  FileText,
  Calendar,
  Check,
  Edit2,
  Copy,
  Trash2,
  AlertTriangle
} from 'lucide-react';
import { SalesOrder, SalesOrderStatus } from '../../types';

interface SalesOrdersViewProps {
  onOpenCreateOrder: () => void;
  onEditOrder?: (order: SalesOrder) => void;
  onNavigateToInvoices: () => void;
}

export const SalesOrdersView: React.FC<SalesOrdersViewProps> = ({
  onOpenCreateOrder,
  onEditOrder,
  onNavigateToInvoices,
}) => {
  const {
    salesOrders,
    formatMoney,
    convertSalesOrderToInvoice,
    updateSalesOrder,
    deleteSalesOrder,
    duplicateSalesOrder
  } = useAccounting();

  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);

  const filteredOrders = salesOrders.filter(so => {
    const matchesSearch =
      so.orderNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      so.customerName.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || so.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const handleConvertToInvoice = (id: string, num: string) => {
    convertSalesOrderToInvoice(id);
    setToastMessage(`Sales Order ${num} converted to Tax Invoice.`);
    setTimeout(() => {
      setToastMessage(null);
      onNavigateToInvoices();
    }, 1500);
  };

  const handleMarkFulfilled = (id: string) => {
    updateSalesOrder(id, { status: 'fulfilled' });
    setToastMessage('Order marked as fulfilled/dispatched.');
    setTimeout(() => setToastMessage(null), 2500);
  };

  const handleDuplicate = (id: string, num: string) => {
    duplicateSalesOrder(id);
    setToastMessage(`Sales Order ${num} duplicated successfully.`);
    setTimeout(() => setToastMessage(null), 3000);
  };

  const handleDelete = (id: string, num: string) => {
    deleteSalesOrder(id);
    setDeleteConfirmId(null);
    setToastMessage(`Sales Order ${num} deleted.`);
    setTimeout(() => setToastMessage(null), 3000);
  };

  const getStatusBadge = (status: SalesOrderStatus) => {
    switch (status) {
      case 'confirmed':
        return <span className="bg-blue-50 text-blue-700 border border-blue-200 text-[10px] font-bold px-2 py-0.5 rounded uppercase">Confirmed</span>;
      case 'fulfilled':
        return <span className="bg-emerald-50 text-emerald-700 border border-emerald-200 text-[10px] font-bold px-2 py-0.5 rounded uppercase">Fulfilled</span>;
      case 'invoiced':
        return <span className="bg-purple-50 text-purple-700 border border-purple-200 text-[10px] font-bold px-2 py-0.5 rounded uppercase">Invoiced</span>;
      case 'cancelled':
        return <span className="bg-rose-50 text-rose-700 border border-rose-200 text-[10px] font-bold px-2 py-0.5 rounded uppercase">Cancelled</span>;
      default:
        return <span className="bg-slate-100 text-slate-700 border border-slate-200 text-[10px] font-bold px-2 py-0.5 rounded uppercase">Draft</span>;
    }
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-5 right-5 z-50 bg-slate-900 text-white text-xs px-4 py-2.5 rounded-lg shadow-xl flex items-center gap-2 border border-slate-700 animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Top Banner */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-2xs p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-base font-bold text-slate-900 flex items-center gap-2">
            <ShoppingCart className="w-5 h-5 text-blue-600" />
            <span>Sales Orders (Order Management)</span>
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Track confirmed client orders, fulfillment schedules, and convert to tax invoices upon dispatch
          </p>
        </div>

        <button
          onClick={onOpenCreateOrder}
          className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs transition-colors shrink-0"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>New Sales Order</span>
        </button>
      </div>

      {/* Sales Orders Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-2xs p-4 space-y-4">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="relative w-full sm:w-80">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Search by order number or customer..."
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-500"
            />
          </div>

          <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg text-xs font-medium self-start sm:self-auto">
            {['all', 'draft', 'confirmed', 'fulfilled', 'invoiced'].map(st => (
              <button
                key={st}
                onClick={() => setStatusFilter(st)}
                className={`px-2.5 py-1 rounded-md transition-colors capitalize ${
                  statusFilter === st ? 'bg-white text-slate-900 shadow-xs font-semibold' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {st}
              </button>
            ))}
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-600 border-collapse">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-50/75 text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
                <th className="py-2.5 px-3">Date</th>
                <th className="py-2.5 px-3">Order #</th>
                <th className="py-2.5 px-3">Customer Name</th>
                <th className="py-2.5 px-3">Expected Delivery</th>
                <th className="py-2.5 px-3">Status</th>
                <th className="py-2.5 px-3 text-right">Order Amount</th>
                <th className="py-2.5 px-3 text-center">Actions (Edit / Duplicate / Delete / Convert)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredOrders.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-slate-400">
                    <Calendar className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                    <p className="font-medium text-slate-600">No sales orders found</p>
                    <p className="text-[11px] text-slate-400 mt-1">Record client purchase orders and manage delivery fulfillments</p>
                    <button
                      onClick={onOpenCreateOrder}
                      className="mt-3 inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs"
                    >
                      <Plus className="w-3.5 h-3.5" /> Create Sales Order
                    </button>
                  </td>
                </tr>
              ) : (
                filteredOrders.map(so => (
                  <tr key={so.id} className="hover:bg-slate-50/70 transition-colors">
                    <td className="py-3 px-3 text-slate-500 font-mono whitespace-nowrap">{so.date}</td>
                    <td className="py-3 px-3 font-semibold text-blue-600 font-mono whitespace-nowrap">
                      {so.orderNumber}
                    </td>
                    <td className="py-3 px-3 font-medium text-slate-800 max-w-xs truncate">
                      {so.customerName}
                    </td>
                    <td className="py-3 px-3 text-slate-500 font-mono whitespace-nowrap">
                      {so.expectedDeliveryDate}
                    </td>
                    <td className="py-3 px-3 whitespace-nowrap">
                      {getStatusBadge(so.status)}
                    </td>
                    <td className="py-3 px-3 text-right font-mono font-bold text-slate-900 tabular-nums whitespace-nowrap">
                      {formatMoney(so.totalAmount, so.currency)}
                    </td>
                    <td className="py-3 px-3 text-center whitespace-nowrap">
                      <div className="flex items-center justify-center gap-1">
                        {/* 1. Edit */}
                        {onEditOrder && (
                          <button
                            onClick={() => onEditOrder(so)}
                            className="p-1.5 text-slate-500 hover:text-blue-600 hover:bg-blue-50 rounded transition-colors"
                            title="Edit sales order"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                        )}

                        {/* 2. Duplicate */}
                        <button
                          onClick={() => handleDuplicate(so.id, so.orderNumber)}
                          className="p-1.5 text-slate-500 hover:text-emerald-600 hover:bg-emerald-50 rounded transition-colors"
                          title="Duplicate sales order"
                        >
                          <Copy className="w-3.5 h-3.5" />
                        </button>

                        {/* 3. Delete */}
                        <button
                          onClick={() => setDeleteConfirmId(so.id)}
                          className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded transition-colors"
                          title="Delete sales order"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>

                        <div className="w-px h-3.5 bg-slate-200 mx-0.5" />

                        {/* Conversion & Fulfillment */}
                        {so.status === 'confirmed' && (
                          <button
                            onClick={() => handleMarkFulfilled(so.id)}
                            className="px-2 py-1 text-[10px] font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded transition-colors"
                          >
                            Mark Fulfilled
                          </button>
                        )}

                        {so.status !== 'invoiced' ? (
                          <button
                            onClick={() => handleConvertToInvoice(so.id, so.orderNumber)}
                            className="px-2 py-1 text-[10px] font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded transition-colors shadow-2xs flex items-center gap-1"
                            title="Convert to Tax Invoice"
                          >
                            <FileText className="w-3 h-3" />
                            <span>Invoice</span>
                          </button>
                        ) : (
                          <span className="text-purple-700 text-[11px] font-medium px-1">Invoiced</span>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Delete Confirmation Modal */}
      {deleteConfirmId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4">
          <div className="bg-white w-full max-w-sm rounded-xl p-5 shadow-2xl border border-slate-200 space-y-3">
            <div className="flex items-center gap-2 text-rose-600 font-bold text-sm">
              <AlertTriangle className="w-4 h-4" />
              <span>Confirm Delete Sales Order</span>
            </div>
            <p className="text-xs text-slate-600">
              Are you sure you want to delete this order?
            </p>
            <div className="flex justify-end gap-2 pt-2">
              <button
                onClick={() => setDeleteConfirmId(null)}
                className="px-3 py-1.5 text-xs text-slate-600 hover:bg-slate-100 rounded-lg"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  const so = salesOrders.find(s => s.id === deleteConfirmId);
                  if (so) handleDelete(so.id, so.orderNumber);
                }}
                className="px-4 py-1.5 text-xs font-semibold text-white bg-rose-600 hover:bg-rose-700 rounded-lg"
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
