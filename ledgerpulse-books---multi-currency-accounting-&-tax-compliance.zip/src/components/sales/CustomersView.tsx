import React, { useState } from 'react';
import { useAccounting } from '../../context/AccountingContext';
import {
  Users,
  Plus,
  Search,
  Building,
  Edit2,
  Copy,
  Trash2,
  CheckCircle2,
  AlertTriangle
} from 'lucide-react';
import { Customer } from '../../types';

interface CustomersViewProps {
  onOpenAddCustomer: () => void;
  onEditCustomer: (customer: Customer) => void;
  onCreateEstimateForCustomer: (customerId: string) => void;
  onCreateInvoiceForCustomer: (customerId: string) => void;
}

export const CustomersView: React.FC<CustomersViewProps> = ({
  onOpenAddCustomer,
  onEditCustomer,
  onCreateEstimateForCustomer,
  onCreateInvoiceForCustomer,
}) => {
  const { customers, invoices, formatMoney, deleteCustomer, duplicateCustomer } = useAccounting();
  const [searchTerm, setSearchTerm] = useState('');
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);

  const filteredCustomers = customers.filter(c =>
    c.companyName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    c.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    c.taxId.toLowerCase().includes(searchTerm.toLowerCase()) ||
    (c.pincode && c.pincode.includes(searchTerm))
  );

  const handleDuplicate = (id: string, name: string) => {
    duplicateCustomer(id);
    setToastMessage(`Customer "${name}" duplicated successfully.`);
    setTimeout(() => setToastMessage(null), 3000);
  };

  const handleDelete = (id: string, name: string) => {
    deleteCustomer(id);
    setDeleteConfirmId(null);
    setToastMessage(`Customer "${name}" deleted.`);
    setTimeout(() => setToastMessage(null), 3000);
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-5 right-5 z-50 bg-slate-900 text-white text-xs px-4 py-2.5 rounded-lg shadow-xl flex items-center gap-2 border border-slate-700 animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Top Banner */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-2xs p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-base font-bold text-slate-900 flex items-center gap-2">
            <Users className="w-5 h-5 text-blue-600" />
            <span>Customers (Sales Accounts)</span>
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Manage client directory, GSTIN/Tax identification, billing terms, pincodes, and receivables
          </p>
        </div>

        <button
          onClick={onOpenAddCustomer}
          className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs transition-colors shrink-0"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>New Customer</span>
        </button>
      </div>

      {/* Customer Directory Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-2xs p-4 space-y-4">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="Search by company, contact, GSTIN, or pincode..."
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-500"
          />
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-600 border-collapse">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-50/75 text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
                <th className="py-2.5 px-3">Company / Client Name</th>
                <th className="py-2.5 px-3">Primary Contact</th>
                <th className="py-2.5 px-3">Place of Supply & GSTIN</th>
                <th className="py-2.5 px-3">Billing Address & Pincode</th>
                <th className="py-2.5 px-3 text-right">Receivables</th>
                <th className="py-2.5 px-3 text-center">Actions (Edit / Duplicate / Delete)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredCustomers.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-12 text-center text-slate-400">
                    <Building className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                    <p className="font-medium text-slate-600">No customers found</p>
                    <p className="text-[11px] text-slate-400 mt-1">Get started by creating your first client account</p>
                    <button
                      onClick={onOpenAddCustomer}
                      className="mt-3 inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs"
                    >
                      <Plus className="w-3.5 h-3.5" /> Add Customer
                    </button>
                  </td>
                </tr>
              ) : (
                filteredCustomers.map(cust => {
                  const custInvoices = invoices.filter(i => i.customerId === cust.id && i.status !== 'void');
                  const outstanding = custInvoices.reduce((sum, i) => sum + i.balanceDue, 0);

                  return (
                    <tr key={cust.id} className="hover:bg-slate-50/70 transition-colors">
                      <td className="py-3 px-3">
                        <div className="font-bold text-slate-900">{cust.companyName}</div>
                        <div className="text-[11px] text-slate-500 font-mono">Currency: {cust.currency} · Net {cust.paymentTermsDays}d</div>
                      </td>
                      <td className="py-3 px-3">
                        <div className="font-medium text-slate-800">{cust.name}</div>
                        <div className="text-[11px] text-slate-400 flex items-center gap-1.5 mt-0.5">
                          <span>{cust.email}</span>
                          {cust.phone && <span>· {cust.phone}</span>}
                        </div>
                      </td>
                      <td className="py-3 px-3">
                        <div className="text-slate-800 font-semibold">{cust.placeOfSupply}</div>
                        <div className="text-[11px] text-slate-500 font-mono">GSTIN: {cust.taxId}</div>
                        {cust.pan && <div className="text-[10px] text-slate-400 font-mono">PAN: {cust.pan}</div>}
                      </td>
                      <td className="py-3 px-3 max-w-xs">
                        <div className="text-slate-700 line-clamp-1">{cust.billingAddress || '—'}</div>
                        {cust.pincode && (
                          <div className="text-[11px] text-blue-700 font-mono font-medium">
                            PIN: {cust.pincode}
                          </div>
                        )}
                      </td>
                      <td className="py-3 px-3 text-right font-mono font-bold tabular-nums">
                        {outstanding > 0 ? (
                          <span className="text-rose-600">{formatMoney(outstanding, cust.currency)}</span>
                        ) : (
                          <span className="text-emerald-600 font-medium">All Clear</span>
                        )}
                      </td>
                      <td className="py-3 px-3 text-center whitespace-nowrap">
                        <div className="flex items-center justify-center gap-1">
                          {/* 1. Edit */}
                          <button
                            onClick={() => onEditCustomer(cust)}
                            className="p-1.5 text-slate-500 hover:text-blue-600 hover:bg-blue-50 rounded transition-colors"
                            title="Edit customer details"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>

                          {/* 2. Duplicate */}
                          <button
                            onClick={() => handleDuplicate(cust.id, cust.companyName)}
                            className="p-1.5 text-slate-500 hover:text-emerald-600 hover:bg-emerald-50 rounded transition-colors"
                            title="Duplicate customer"
                          >
                            <Copy className="w-3.5 h-3.5" />
                          </button>

                          {/* 3. Delete */}
                          <button
                            onClick={() => setDeleteConfirmId(cust.id)}
                            className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded transition-colors"
                            title="Delete customer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>

                          <div className="w-px h-3.5 bg-slate-200 mx-0.5" />

                          {/* Quick transactional creation */}
                          <button
                            onClick={() => onCreateEstimateForCustomer(cust.id)}
                            className="px-2 py-1 text-[10px] font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded transition-colors"
                            title="Create Quote / Estimate"
                          >
                            + Estimate
                          </button>
                          <button
                            onClick={() => onCreateInvoiceForCustomer(cust.id)}
                            className="px-2 py-1 text-[10px] font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded transition-colors shadow-2xs"
                            title="Create Sales Invoice"
                          >
                            + Invoice
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Delete Confirmation Modal */}
      {deleteConfirmId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4">
          <div className="bg-white w-full max-w-sm rounded-xl p-5 shadow-2xl border border-slate-200 space-y-3">
            <div className="flex items-center gap-2 text-rose-600 font-bold text-sm">
              <AlertTriangle className="w-4 h-4" />
              <span>Confirm Delete Customer</span>
            </div>
            <p className="text-xs text-slate-600">
              Are you sure you want to delete this customer? This cannot be undone.
            </p>
            <div className="flex justify-end gap-2 pt-2">
              <button
                onClick={() => setDeleteConfirmId(null)}
                className="px-3 py-1.5 text-xs text-slate-600 hover:bg-slate-100 rounded-lg"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  const cust = customers.find(c => c.id === deleteConfirmId);
                  if (cust) handleDelete(cust.id, cust.companyName);
                }}
                className="px-4 py-1.5 text-xs font-semibold text-white bg-rose-600 hover:bg-rose-700 rounded-lg"
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
