import React, { useState } from 'react';
import { useAccounting } from '../../context/AccountingContext';
import { X, Wallet } from 'lucide-react';
import { CurrencyCode } from '../../types';

interface ExpenseCreateModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ExpenseCreateModal: React.FC<ExpenseCreateModalProps> = ({ isOpen, onClose }) => {
  const { chartOfAccounts, bankAccounts, taxRates, createExpense, expenses, vendors } = useAccounting();

  if (!isOpen) return null;

  const expenseAccounts = chartOfAccounts.filter(a => a.type === 'expense');

  const [expenseNumber, setExpenseNumber] = useState(`EXP-2026-00${expenses.length + 85}`);
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [category, setCategory] = useState('Software & Cloud Subscriptions');
  const [selectedAccCode, setSelectedAccCode] = useState(expenseAccounts[0]?.code || '5000');
  const [vendorName, setVendorName] = useState('Google Cloud / SaaS Services');
  const [amount, setAmount] = useState<number>(4500);
  const [taxRateId, setTaxRateId] = useState('tax-gst-18');
  const [paidThroughBankAccountId, setPaidThroughBankAccountId] = useState(bankAccounts[0]?.id || '');
  const [paymentMode, setPaymentMode] = useState<'bank_transfer' | 'credit_card' | 'upi' | 'cash'>('upi');
  const [referenceNumber, setReferenceNumber] = useState(`UPI-${Date.now().toString().slice(-6)}`);
  const [notes, setNotes] = useState('Production development tooling license subscription');

  const selectedTax = taxRates.find(t => t.id === taxRateId);
  const taxPct = selectedTax ? selectedTax.rate : 18;
  const taxAmount = Math.round(amount * (taxPct / 100));
  const totalAmount = amount + taxAmount;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const acc = chartOfAccounts.find(a => a.code === selectedAccCode);

    createExpense({
      expenseNumber,
      date,
      category,
      accountCode: selectedAccCode,
      accountName: acc ? acc.name : 'General Expense',
      vendorName,
      amount,
      currency: 'INR',
      exchangeRate: 1.0,
      taxRateId,
      taxAmount,
      totalAmount,
      paidThroughBankAccountId,
      paymentMode,
      referenceNumber,
      notes
    });

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-xs p-4">
      <div className="bg-white w-full max-w-lg rounded-2xl shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95">
        <div className="px-6 py-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
          <div>
            <h2 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <Wallet className="w-4 h-4 text-amber-600" />
              <span>Record Direct Expense</span>
            </h2>
            <p className="text-xs text-slate-500">Immediate outlay deducted from bank balance with GST ITC claim</p>
          </div>
          <button onClick={onClose} className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-700 font-semibold mb-1">Expense Category <span className="text-rose-500">*</span></label>
              <input
                type="text"
                value={category}
                onChange={e => setCategory(e.target.value)}
                placeholder="e.g. SaaS Subscriptions, Office Supplies..."
                className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 font-medium"
                required
              />
            </div>
            <div>
              <label className="block text-slate-700 font-semibold mb-1">Expense Account (GL) <span className="text-rose-500">*</span></label>
              <select
                value={selectedAccCode}
                onChange={e => setSelectedAccCode(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 font-medium"
              >
                {expenseAccounts.map(a => (
                  <option key={a.code} value={a.code}>{a.code} - {a.name}</option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-700 font-semibold mb-1">Paid To / Payee Name</label>
              <input
                type="text"
                value={vendorName}
                onChange={e => setVendorName(e.target.value)}
                placeholder="Merchant or Vendor name..."
                className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2"
              />
            </div>
            <div>
              <label className="block text-slate-700 font-semibold mb-1">Expense Date</label>
              <input
                type="date"
                value={date}
                onChange={e => setDate(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-700 font-semibold mb-1">Expense Base Amount (INR) <span className="text-rose-500">*</span></label>
              <input
                type="number"
                min="1"
                value={amount}
                onChange={e => setAmount(Number(e.target.value))}
                className="w-full font-mono font-bold text-sm bg-slate-50 border border-slate-200 rounded-lg px-3 py-2"
                required
              />
            </div>
            <div>
              <label className="block text-slate-700 font-semibold mb-1">GST Tax Rate (Input Tax Credit)</label>
              <select
                value={taxRateId}
                onChange={e => setTaxRateId(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2"
              >
                {taxRates.map(r => (
                  <option key={r.id} value={r.id}>{r.name}</option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-700 font-semibold mb-1">Paid Through Bank A/C <span className="text-rose-500">*</span></label>
              <select
                value={paidThroughBankAccountId}
                onChange={e => setPaidThroughBankAccountId(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 font-medium"
              >
                {bankAccounts.map(b => (
                  <option key={b.id} value={b.id}>{b.bankName} - {b.name}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-slate-700 font-semibold mb-1">Payment Mode</label>
              <select
                value={paymentMode}
                onChange={e => setPaymentMode(e.target.value as any)}
                className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 capitalize"
              >
                <option value="upi">UPI / Instant Transfer</option>
                <option value="credit_card">Corporate Credit Card</option>
                <option value="bank_transfer">NEFT / RTGS</option>
                <option value="cash">Petty Cash</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-slate-700 font-semibold mb-1">Reference / UTR / Receipt No</label>
            <input
              type="text"
              value={referenceNumber}
              onChange={e => setReferenceNumber(e.target.value)}
              className="w-full font-mono bg-slate-50 border border-slate-200 rounded-lg px-3 py-2"
            />
          </div>

          <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 flex justify-between font-mono text-xs">
            <span className="text-slate-600">GST ITC Claimable: ₹{taxAmount.toLocaleString()}</span>
            <span className="font-bold text-slate-900">Total Deducted: ₹{totalAmount.toLocaleString()}</span>
          </div>

          <div className="pt-2 flex items-center justify-end gap-2 border-t border-slate-200">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-slate-600 hover:bg-slate-100 rounded-lg"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs"
            >
              Record & Disburse
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
