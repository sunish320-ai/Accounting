import React, { useState } from 'react';
import { useAccounting } from '../../context/AccountingContext';
import {
  Wallet,
  Plus,
  Search,
  CheckCircle2,
  Receipt,
  Trash2,
  Edit2,
  Copy,
  AlertTriangle,
  Calendar,
  CreditCard
} from 'lucide-react';
import { Expense } from '../../types';

interface ExpensesViewProps {
  onOpenCreateExpense: () => void;
  onEditExpense?: (expense: Expense) => void;
}

export const ExpensesView: React.FC<ExpensesViewProps> = ({ onOpenCreateExpense, onEditExpense }) => {
  const { expenses, formatMoney, deleteExpense, duplicateExpense } = useAccounting();
  const [searchTerm, setSearchTerm] = useState('');
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);

  const filtered = expenses.filter(exp =>
    exp.expenseNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
    exp.category.toLowerCase().includes(searchTerm.toLowerCase()) ||
    (exp.vendorName && exp.vendorName.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  const totalExpenseAmount = expenses.reduce((sum, e) => sum + e.totalAmount, 0);

  const handleDuplicate = (id: string, num: string) => {
    duplicateExpense(id);
    setToastMessage(`Expense ${num} duplicated.`);
    setTimeout(() => setToastMessage(null), 3000);
  };

  const handleDelete = (id: string, num: string) => {
    deleteExpense(id);
    setDeleteConfirmId(null);
    setToastMessage(`Expense ${num} deleted.`);
    setTimeout(() => setToastMessage(null), 3000);
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      {/* Toast */}
      {toastMessage && (
        <div className="fixed bottom-5 right-5 z-50 bg-slate-900 text-white text-xs px-4 py-2.5 rounded-lg shadow-xl flex items-center gap-2 border border-slate-700 animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Top Banner */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-2xs p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-base font-bold text-slate-900 flex items-center gap-2">
            <Wallet className="w-5 h-5 text-amber-600" />
            <span>Direct Business Expenses (Purchases)</span>
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Log immediate operational outlays, subscriptions, travel, and utility payments with automated GST ITC claims
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="text-right hidden sm:block">
            <div className="text-[11px] text-slate-400">Total Direct Expenses</div>
            <div className="text-base font-bold font-mono text-slate-900">{formatMoney(totalExpenseAmount, 'INR')}</div>
          </div>

          <button
            onClick={onOpenCreateExpense}
            className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs transition-colors shrink-0"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Record Expense</span>
          </button>
        </div>
      </div>

      {/* Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-2xs p-4 space-y-4">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="Search expenses by category or payee..."
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-500"
          />
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-600 border-collapse">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-50/75 text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
                <th className="py-2.5 px-3">Date</th>
                <th className="py-2.5 px-3">Expense #</th>
                <th className="py-2.5 px-3">Category & Account</th>
                <th className="py-2.5 px-3">Paid To / Payee</th>
                <th className="py-2.5 px-3">Payment Mode</th>
                <th className="py-2.5 px-3 text-right">Taxable</th>
                <th className="py-2.5 px-3 text-right">GST ITC</th>
                <th className="py-2.5 px-3 text-right">Total Disbursed</th>
                <th className="py-2.5 px-3 text-center">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={9} className="py-12 text-center text-slate-400">
                    <Wallet className="w-8 h-8 text-slate-300 mx-auto mb-2 opacity-50" />
                    <p className="text-sm font-medium text-slate-600">No direct expenses recorded yet</p>
                    <p className="text-xs text-slate-400 mt-1">Record utility bills, petty cash, software subscriptions or travel expenses.</p>
                  </td>
                </tr>
              ) : (
                filtered.map(exp => (
                  <tr key={exp.id} className="hover:bg-slate-50/70 transition-colors">
                    <td className="py-3 px-3 text-slate-500 font-mono whitespace-nowrap">{exp.date}</td>
                    <td className="py-3 px-3 font-semibold text-blue-600 font-mono whitespace-nowrap">
                      {exp.expenseNumber}
                    </td>
                    <td className="py-3 px-3">
                      <div className="font-semibold text-slate-800">{exp.category}</div>
                      <div className="text-[10px] text-slate-400 font-mono">{exp.accountCode} - {exp.accountName}</div>
                    </td>
                    <td className="py-3 px-3 font-medium text-slate-800">
                      {exp.vendorName || 'General Payee'}
                    </td>
                    <td className="py-3 px-3 uppercase text-[10px] font-mono">
                      <span className="bg-slate-100 px-1.5 py-0.5 rounded text-slate-700">
                        {exp.paymentMode.replace('_', ' ')}
                      </span>
                    </td>
                    <td className="py-3 px-3 text-right font-mono tabular-nums whitespace-nowrap">
                      {formatMoney(exp.amount, exp.currency)}
                    </td>
                    <td className="py-3 px-3 text-right font-mono text-emerald-600 tabular-nums whitespace-nowrap">
                      +{formatMoney(exp.taxAmount, exp.currency)}
                    </td>
                    <td className="py-3 px-3 text-right font-mono font-bold text-slate-900 tabular-nums whitespace-nowrap">
                      {formatMoney(exp.totalAmount, exp.currency)}
                    </td>
                    <td className="py-3 px-3 text-center whitespace-nowrap">
                      <div className="flex items-center justify-center gap-1">
                        {onEditExpense && (
                          <button
                            onClick={() => onEditExpense(exp)}
                            className="p-1.5 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded transition-colors"
                            title="Edit Expense"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                        <button
                          onClick={() => handleDuplicate(exp.id, exp.expenseNumber)}
                          className="p-1.5 text-slate-400 hover:text-emerald-600 hover:bg-emerald-50 rounded transition-colors"
                          title="Duplicate Expense"
                        >
                          <Copy className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => setDeleteConfirmId(exp.id)}
                          className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded transition-colors"
                          title="Delete Expense"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Delete Confirmation Modal */}
      {deleteConfirmId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-xs p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-sm w-full p-6 text-center border border-slate-200">
            <div className="w-12 h-12 rounded-full bg-rose-50 text-rose-600 mx-auto flex items-center justify-center mb-4">
              <AlertTriangle className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-slate-900 mb-2">Delete Expense?</h3>
            <p className="text-sm text-slate-600 mb-6">
              Are you sure you want to delete this expense record?
            </p>
            <div className="flex gap-3 justify-center">
              <button
                onClick={() => setDeleteConfirmId(null)}
                className="px-4 py-2 border border-slate-300 rounded-lg text-sm font-medium text-slate-700 hover:bg-slate-50 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  const exp = expenses.find(e => e.id === deleteConfirmId);
                  handleDelete(deleteConfirmId, exp?.expenseNumber || '');
                }}
                className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-lg text-sm font-medium transition-colors"
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

