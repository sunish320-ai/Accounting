import React, { useState } from 'react';
import { X, Plus, Trash2, ArrowLeftRight } from 'lucide-react';
import { useAccounting } from '../../context/AccountingContext';
import { BillLineItem } from '../../types';

interface PurchaseReturnCreateModalProps {
  isOpen: boolean;
  onClose: () => void;
  preselectedVendorId?: string;
  preselectedBillId?: string;
}

export const PurchaseReturnCreateModal: React.FC<PurchaseReturnCreateModalProps> = ({
  isOpen,
  onClose,
  preselectedVendorId,
  preselectedBillId,
}) => {
  const { vendors, bills, taxRates, createDebitNote, settings } = useAccounting();

  const [vendorId, setVendorId] = useState(preselectedVendorId || (vendors[0]?.id || ''));
  const [billId, setBillId] = useState(preselectedBillId || '');
  const [returnDate, setReturnDate] = useState(new Date().toISOString().split('T')[0]);
  const [reason, setReason] = useState('Damaged goods received / Defective quality');
  const [items, setItems] = useState<BillLineItem[]>([
    {
      id: 'item-1',
      description: 'Returned Goods / Rejected Batch',
      category: 'Purchase Returns',
      hsnSac: '998311',
      quantity: 1,
      unitRate: 1000,
      taxRateId: 'tax-gst-18',
      amount: 1000,
      taxAmount: 180,
    },
  ]);
  const [tdsReversed, setTdsReversed] = useState(0);

  if (!isOpen) return null;

  const selectedVendor = vendors.find(v => v.id === vendorId);
  const vendorBills = bills.filter(b => b.vendorId === vendorId);

  const calculateItemAmount = (item: BillLineItem) => {
    const base = item.quantity * item.unitRate;
    const rate = taxRates.find(r => r.id === item.taxRateId)?.rate || 0;
    const tax = (base * rate) / 100;
    return { amount: base, taxAmount: tax };
  };

  const updateItem = (index: number, updates: Partial<BillLineItem>) => {
    const newItems = [...items];
    newItems[index] = { ...newItems[index], ...updates };
    const { amount, taxAmount } = calculateItemAmount(newItems[index]);
    newItems[index].amount = amount;
    newItems[index].taxAmount = taxAmount;
    setItems(newItems);
  };

  const addItem = () => {
    setItems([
      ...items,
      {
        id: `item-${Date.now()}`,
        description: '',
        category: 'Purchase Returns',
        hsnSac: '998311',
        quantity: 1,
        unitRate: 0,
        taxRateId: 'tax-gst-18',
        amount: 0,
        taxAmount: 0,
      },
    ]);
  };

  const removeItem = (index: number) => {
    if (items.length > 1) {
      setItems(items.filter((_, i) => i !== index));
    }
  };

  const subtotal = items.reduce((sum, item) => sum + item.amount, 0);
  const taxTotal = items.reduce((sum, item) => sum + item.taxAmount, 0);
  const grandTotal = subtotal + taxTotal;
  const netClaimable = grandTotal - tdsReversed;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!vendorId) return;

    createDebitNote({
      debitNoteNumber: `DN-2026-00${Date.now().toString().slice(-4)}`,
      vendorId,
      vendorName: selectedVendor?.name || '',
      vendorPan: selectedVendor?.pan || '',
      billId: billId ? billId : undefined,
      date: returnDate,
      status: 'open',
      currency: selectedVendor?.currency || settings.baseCurrency,
      exchangeRate: 1,
      items,
      subtotal,
      taxAmount: taxTotal,
      grossAmount: grandTotal,
      tdsReversalAmount: tdsReversed,
      netDebitAmount: netClaimable,
      reason,
      notes: `Issued against vendor account. Reason: ${reason}`,
    });

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="bg-white rounded-xl shadow-2xl border border-slate-200 w-full max-w-4xl my-8 overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        <div className="flex items-center justify-between px-6 py-4 bg-slate-900 text-white">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-rose-500/20 text-rose-400 flex items-center justify-center font-bold">
              <ArrowLeftRight className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-lg font-semibold tracking-tight">Record Purchase Return / Debit Note</h2>
              <p className="text-xs text-slate-400">Debit note issued to vendor for returned goods or price reduction</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1">
                Vendor <span className="text-rose-500">*</span>
              </label>
              <select
                value={vendorId}
                onChange={(e) => {
                  setVendorId(e.target.value);
                  setBillId('');
                }}
                required
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg bg-white focus:outline-none focus:ring-2 focus:ring-rose-500/20 focus:border-rose-500"
              >
                {vendors.map((v) => (
                  <option key={v.id} value={v.id}>
                    {v.name} ({v.companyName || v.currency})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1">
                Against Bill (Optional)
              </label>
              <select
                value={billId}
                onChange={(e) => setBillId(e.target.value)}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg bg-white focus:outline-none focus:ring-2 focus:ring-rose-500/20 focus:border-rose-500"
              >
                <option value="">-- No specific bill (On-Account) --</option>
                {vendorBills.map((b) => (
                  <option key={b.id} value={b.id}>
                    {b.billNumber} ({b.currency} {b.grossAmount.toLocaleString()} - {b.billDate})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1">
                Return Date <span className="text-rose-500">*</span>
              </label>
              <input
                type="date"
                value={returnDate}
                onChange={(e) => setReturnDate(e.target.value)}
                required
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg bg-white focus:outline-none focus:ring-2 focus:ring-rose-500/20 focus:border-rose-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1">
              Reason for Return / Adjustment <span className="text-rose-500">*</span>
            </label>
            <input
              type="text"
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              placeholder="e.g. Defective materials returned to vendor, post-sale discount adjustment"
              required
              className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg bg-white focus:outline-none focus:ring-2 focus:ring-rose-500/20 focus:border-rose-500"
            />
          </div>

          {/* Line items table */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-700">Returned Line Items</h3>
              <button
                type="button"
                onClick={addItem}
                className="inline-flex items-center gap-1 text-xs font-semibold text-rose-600 hover:text-rose-700"
              >
                <Plus className="w-3.5 h-3.5" /> Add Return Item
              </button>
            </div>

            <div className="border border-slate-200 rounded-lg overflow-hidden">
              <table className="w-full text-left text-sm">
                <thead className="bg-slate-50 text-slate-500 text-xs font-medium border-b border-slate-200">
                  <tr>
                    <th className="px-4 py-2.5">Item & Description</th>
                    <th className="px-3 py-2.5 w-24">Qty</th>
                    <th className="px-3 py-2.5 w-28">Rate</th>
                    <th className="px-3 py-2.5 w-36">GST Tax Rate</th>
                    <th className="px-4 py-2.5 w-28 text-right">Taxable</th>
                    <th className="px-2 py-2.5 w-10"></th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {items.map((item, idx) => (
                    <tr key={item.id} className="hover:bg-slate-50/50">
                      <td className="p-2">
                        <input
                          type="text"
                          value={item.description}
                          onChange={(e) => updateItem(idx, { description: e.target.value })}
                          placeholder="Returned item description"
                          required
                          className="w-full px-2.5 py-1.5 text-xs border border-slate-200 rounded focus:border-rose-500 focus:outline-none"
                        />
                      </td>
                      <td className="p-2">
                        <input
                          type="number"
                          min="1"
                          value={item.quantity}
                          onChange={(e) => updateItem(idx, { quantity: Number(e.target.value) || 0 })}
                          className="w-full px-2.5 py-1.5 text-xs border border-slate-200 rounded text-right focus:border-rose-500 focus:outline-none font-mono"
                        />
                      </td>
                      <td className="p-2">
                        <input
                          type="number"
                          min="0"
                          step="0.01"
                          value={item.unitRate}
                          onChange={(e) => updateItem(idx, { unitRate: Number(e.target.value) || 0 })}
                          className="w-full px-2.5 py-1.5 text-xs border border-slate-200 rounded text-right focus:border-rose-500 focus:outline-none font-mono"
                        />
                      </td>
                      <td className="p-2">
                        <select
                          value={item.taxRateId}
                          onChange={(e) => updateItem(idx, { taxRateId: e.target.value })}
                          className="w-full px-2 py-1.5 text-xs border border-slate-200 rounded focus:border-rose-500 focus:outline-none"
                        >
                          {taxRates.map((tr) => (
                            <option key={tr.id} value={tr.id}>
                              {tr.name} ({tr.rate}%)
                            </option>
                          ))}
                        </select>
                      </td>
                      <td className="p-2 text-right font-mono text-xs font-semibold text-slate-700">
                        {settings.baseCurrency} {item.amount.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                      </td>
                      <td className="p-2 text-center">
                        <button
                          type="button"
                          onClick={() => removeItem(idx)}
                          disabled={items.length === 1}
                          className="text-slate-400 hover:text-rose-600 disabled:opacity-30 disabled:hover:text-slate-400"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Calculations Summary */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 bg-slate-50 p-4 rounded-xl border border-slate-200">
            <div className="space-y-3">
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600">
                TDS Withholding Reversal (if applicable)
              </label>
              <div className="flex items-center gap-2">
                <span className="text-xs text-slate-500 font-medium">Reversed TDS Amount:</span>
                <input
                  type="number"
                  min="0"
                  step="0.01"
                  value={tdsReversed}
                  onChange={(e) => setTdsReversed(Number(e.target.value) || 0)}
                  placeholder="0.00"
                  className="w-36 px-2.5 py-1.5 text-xs border border-slate-300 rounded font-mono text-right bg-white focus:outline-none focus:border-rose-500"
                />
              </div>
              <p className="text-[11px] text-slate-500 leading-relaxed">
                Reversing TDS adjusts Form 26Q return balances and creates credit to Vendor Account under Section 194.
              </p>
            </div>

            <div className="space-y-2 text-right text-xs">
              <div className="flex justify-between text-slate-600">
                <span>Total Taxable (Subtotal):</span>
                <span className="font-mono font-medium">{settings.baseCurrency} {subtotal.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
              </div>
              <div className="flex justify-between text-slate-600">
                <span>Input Tax Credit (ITC) Reversal (GST):</span>
                <span className="font-mono font-medium">{settings.baseCurrency} {taxTotal.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
              </div>
              <div className="flex justify-between text-slate-900 font-semibold border-t border-slate-200 pt-2">
                <span>Gross Debit Note:</span>
                <span className="font-mono">{settings.baseCurrency} {grandTotal.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
              </div>
              {tdsReversed > 0 && (
                <div className="flex justify-between text-rose-600 font-medium">
                  <span>Less TDS Reversal:</span>
                  <span className="font-mono">- {settings.baseCurrency} {tdsReversed.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
                </div>
              )}
              <div className="flex justify-between text-emerald-700 font-bold text-sm border-t border-slate-300 pt-2">
                <span>Net Vendor Adjustment / Refund Claim:</span>
                <span className="font-mono">{settings.baseCurrency} {netClaimable.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
              </div>
            </div>
          </div>

          {/* Form Actions */}
          <div className="flex items-center justify-end gap-3 pt-2 border-t border-slate-200">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-sm font-medium text-slate-700 hover:bg-slate-100 rounded-lg transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 text-sm font-semibold text-white bg-rose-600 hover:bg-rose-700 rounded-lg transition-colors shadow-xs"
            >
              Issue Debit Note
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
