import React, { useState } from 'react';
import { useAccounting } from '../../context/AccountingContext';
import { X, Plus, Trash2, Package } from 'lucide-react';
import { BillLineItem, CurrencyCode } from '../../types';

interface PurchaseOrderCreateModalProps {
  isOpen: boolean;
  onClose: () => void;
  preSelectedVendorId?: string;
  preselectedVendorId?: string;
}

export const PurchaseOrderCreateModal: React.FC<PurchaseOrderCreateModalProps> = ({
  isOpen,
  onClose,
  preSelectedVendorId,
  preselectedVendorId,
}) => {
  const { vendors, currencies, taxRates, createPurchaseOrder, purchaseOrders } = useAccounting();

  if (!isOpen) return null;

  const [selectedVendorId, setSelectedVendorId] = useState(
    preselectedVendorId || preSelectedVendorId || vendors[0]?.id || ''
  );
  const currentVendor = vendors.find(v => v.id === selectedVendorId) || vendors[0];

  const [poNumber, setPoNumber] = useState(`PO-2026-00${purchaseOrders.length + 40}`);
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);

  const defaultExp = new Date();
  defaultExp.setDate(defaultExp.getDate() + 15);
  const [expectedDate, setExpectedDate] = useState(defaultExp.toISOString().split('T')[0]);

  const [currency, setCurrency] = useState<CurrencyCode>(currentVendor?.currency || 'INR');
  const [notes, setNotes] = useState('Standard procurement order. Please quote PO number on shipping manifests.');

  const [items, setItems] = useState<BillLineItem[]>([
    {
      id: `po-item-${Date.now()}`,
      description: 'Datacenter Server Rack Movement & High-Speed Optical Cabling',
      category: currentVendor?.category || 'Shipping & Freight',
      hsnSac: '996511',
      quantity: 1,
      unitRate: 40000,
      taxRateId: 'tax-gst-18',
      amount: 40000,
      taxAmount: 7200
    }
  ]);

  const updateRow = (index: number, updates: Partial<BillLineItem>) => {
    setItems(prev => {
      const next = [...prev];
      const item = { ...next[index], ...updates };

      const sub = (item.quantity || 0) * (item.unitRate || 0);
      const taxRateObj = taxRates.find(t => t.id === item.taxRateId);
      const taxPct = taxRateObj ? taxRateObj.rate : 0;
      const taxAmount = sub * (taxPct / 100);

      next[index] = {
        ...item,
        amount: sub,
        taxAmount
      };
      return next;
    });
  };

  const addRow = () => {
    setItems([
      ...items,
      {
        id: `po-item-${Date.now()}-${items.length}`,
        description: '',
        category: currentVendor?.category || 'Procurement',
        hsnSac: '998311',
        quantity: 1,
        unitRate: 0,
        taxRateId: 'tax-gst-18',
        amount: 0,
        taxAmount: 0
      }
    ]);
  };

  const removeRow = (index: number) => {
    if (items.length <= 1) return;
    setItems(items.filter((_, idx) => idx !== index));
  };

  const subtotal = items.reduce((sum, item) => sum + item.amount, 0);
  const taxAmount = items.reduce((sum, item) => sum + item.taxAmount, 0);
  const grossAmount = subtotal + taxAmount;

  const curObj = currencies.find(c => c.code === currency) || { exchangeRateToBase: 1 };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentVendor) return;

    createPurchaseOrder({
      poNumber,
      vendorId: currentVendor.id,
      vendorName: currentVendor.companyName,
      vendorTaxId: currentVendor.taxId,
      vendorPan: currentVendor.pan,
      date,
      expectedDate,
      status: 'issued',
      currency,
      exchangeRate: curObj.exchangeRateToBase,
      items,
      subtotal,
      taxAmount,
      grossAmount,
      notes
    });

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="bg-white w-full max-w-3xl rounded-2xl shadow-2xl border border-slate-200 overflow-hidden my-6 animate-in fade-in zoom-in-95">
        <div className="px-6 py-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
          <div>
            <h2 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <Package className="w-4 h-4 text-emerald-600" />
              <span>Issue Purchase Order (PO)</span>
            </h2>
            <p className="text-xs text-slate-500">Official order sent to supplier with procurement terms</p>
          </div>
          <button onClick={onClose} className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4 max-h-[75vh] overflow-y-auto text-xs">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-slate-700 font-semibold mb-1">Vendor / Supplier <span className="text-rose-500">*</span></label>
              <select
                value={selectedVendorId}
                onChange={e => setSelectedVendorId(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 font-medium"
              >
                {vendors.map(v => (
                  <option key={v.id} value={v.id}>{v.companyName}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-slate-700 font-semibold mb-1">PO Number <span className="text-rose-500">*</span></label>
              <input
                type="text"
                value={poNumber}
                onChange={e => setPoNumber(e.target.value)}
                className="w-full font-mono font-semibold text-blue-600 bg-slate-50 border border-slate-200 rounded-lg px-3 py-2"
                required
              />
            </div>

            <div>
              <label className="block text-slate-700 font-semibold mb-1">Currency</label>
              <select
                value={currency}
                onChange={e => setCurrency(e.target.value as CurrencyCode)}
                className="w-full font-mono font-semibold bg-slate-50 border border-slate-200 rounded-lg px-3 py-2"
              >
                {currencies.map(c => (
                  <option key={c.code} value={c.code}>{c.code} ({c.symbol})</option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-slate-700 font-semibold mb-1">PO Date</label>
              <input
                type="date"
                value={date}
                onChange={e => setDate(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2"
              />
            </div>
            <div>
              <label className="block text-slate-700 font-semibold mb-1">Expected Delivery Date</label>
              <input
                type="date"
                value={expectedDate}
                onChange={e => setExpectedDate(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2"
              />
            </div>
          </div>

          {/* Line items */}
          <div className="space-y-2">
            <h3 className="font-bold text-slate-800 uppercase tracking-wider text-[11px]">Items to Order</h3>
            <div className="border border-slate-200 rounded-lg overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="bg-slate-100 text-slate-600 font-semibold border-b border-slate-200">
                    <th className="py-2 px-3 w-5/12">Description</th>
                    <th className="py-2 px-2 w-20">HSN/SAC</th>
                    <th className="py-2 px-2 w-16 text-right">Qty</th>
                    <th className="py-2 px-2 w-28 text-right">Unit Rate</th>
                    <th className="py-2 px-2 w-28">GST Rate</th>
                    <th className="py-2 px-3 w-28 text-right">Total</th>
                    <th className="py-2 px-1 w-8 text-center"></th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {items.map((item, idx) => (
                    <tr key={item.id}>
                      <td className="py-2 px-3">
                        <input
                          type="text"
                          value={item.description}
                          onChange={e => updateRow(idx, { description: e.target.value })}
                          className="w-full bg-transparent border-0 focus:ring-0 p-0 text-slate-800 font-medium"
                          required
                        />
                      </td>
                      <td className="py-2 px-2">
                        <input
                          type="text"
                          value={item.hsnSac}
                          onChange={e => updateRow(idx, { hsnSac: e.target.value })}
                          className="w-full font-mono bg-transparent border-0 focus:ring-0 p-0 text-slate-600"
                        />
                      </td>
                      <td className="py-2 px-2 text-right">
                        <input
                          type="number"
                          min="1"
                          value={item.quantity}
                          onChange={e => updateRow(idx, { quantity: Number(e.target.value) })}
                          className="w-full font-mono text-right bg-transparent border-0 focus:ring-0 p-0"
                        />
                      </td>
                      <td className="py-2 px-2 text-right">
                        <input
                          type="number"
                          min="0"
                          value={item.unitRate}
                          onChange={e => updateRow(idx, { unitRate: Number(e.target.value) })}
                          className="w-full font-mono text-right bg-transparent border-0 focus:ring-0 p-0 font-medium"
                        />
                      </td>
                      <td className="py-2 px-2">
                        <select
                          value={item.taxRateId}
                          onChange={e => updateRow(idx, { taxRateId: e.target.value })}
                          className="w-full text-[11px] bg-slate-50 border border-slate-200 rounded px-1 py-1"
                        >
                          {taxRates.map(r => (
                            <option key={r.id} value={r.id}>{r.name}</option>
                          ))}
                        </select>
                      </td>
                      <td className="py-2 px-3 text-right font-mono font-bold text-slate-900 tabular-nums">
                        {(item.amount + item.taxAmount).toLocaleString()}
                      </td>
                      <td className="py-2 px-1 text-center">
                        <button
                          type="button"
                          onClick={() => removeRow(idx)}
                          disabled={items.length <= 1}
                          className="text-slate-300 hover:text-rose-500"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <button
              type="button"
              onClick={addRow}
              className="text-xs text-blue-600 hover:text-blue-700 font-semibold flex items-center gap-1 pt-1"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Line Item</span>
            </button>
          </div>

          <div className="flex justify-end pt-2">
            <div className="w-full md:w-5/12 bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-1.5 text-xs">
              <div className="flex justify-between text-slate-600">
                <span>Subtotal:</span>
                <span className="font-mono">{subtotal.toLocaleString()}</span>
              </div>
              <div className="flex justify-between text-slate-600">
                <span>GST (Claimable ITC):</span>
                <span className="font-mono">{taxAmount.toLocaleString()}</span>
              </div>
              <div className="flex justify-between font-bold text-sm text-slate-900 border-t border-slate-200 pt-1.5">
                <span>Gross PO Value:</span>
                <span className="font-mono">{currency} {grossAmount.toLocaleString()}</span>
              </div>
            </div>
          </div>

          <div className="pt-2 flex items-center justify-end gap-2 border-t border-slate-200">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-slate-600 hover:bg-slate-100 rounded-lg"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs"
            >
              Issue Purchase Order
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
