import React, { useState } from 'react';
import { useAccounting } from '../../context/AccountingContext';
import {
  Package,
  Plus,
  Search,
  CheckCircle2,
  Receipt,
  Calendar,
  X,
  Edit2,
  Copy,
  Trash2,
  AlertTriangle
} from 'lucide-react';
import { PurchaseOrder, PurchaseOrderStatus } from '../../types';

interface PurchaseOrdersViewProps {
  onOpenCreatePO: () => void;
  onNavigateToBills: () => void;
  onEditPurchaseOrder?: (po: PurchaseOrder) => void;
}

export const PurchaseOrdersView: React.FC<PurchaseOrdersViewProps> = ({
  onOpenCreatePO,
  onNavigateToBills,
  onEditPurchaseOrder,
}) => {
  const {
    purchaseOrders,
    formatMoney,
    convertPurchaseOrderToBill,
    updatePurchaseOrder,
    deletePurchaseOrder,
    duplicatePurchaseOrder
  } = useAccounting();

  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);

  const filtered = purchaseOrders.filter(po => {
    const matchesSearch =
      po.poNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      po.vendorName.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || po.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const getStatusBadge = (status: PurchaseOrderStatus) => {
    switch (status) {
      case 'issued':
        return <span className="text-[11px] font-semibold text-blue-700 bg-blue-50 border border-blue-200 px-2 py-0.5 rounded">Issued</span>;
      case 'billed':
        return <span className="text-[11px] font-semibold text-purple-700 bg-purple-50 border border-purple-200 px-2 py-0.5 rounded">Billed</span>;
      case 'draft':
        return <span className="text-[11px] font-semibold text-amber-700 bg-amber-50 border border-amber-200 px-2 py-0.5 rounded">Draft</span>;
      case 'cancelled':
        return <span className="text-[11px] font-semibold text-slate-400 bg-slate-100 px-2 py-0.5 rounded">Cancelled</span>;
    }
  };

  const handleConvertToBill = (id: string, poNum: string) => {
    const bill = convertPurchaseOrderToBill(id);
    setToastMessage(`Purchase Order ${poNum} converted to Vendor Bill ${bill.billNumber}!`);
    setTimeout(() => setToastMessage(null), 3000);
  };

  const handleDuplicate = (id: string, poNum: string) => {
    duplicatePurchaseOrder(id);
    setToastMessage(`Purchase Order ${poNum} duplicated.`);
    setTimeout(() => setToastMessage(null), 3000);
  };

  const handleDelete = (id: string, poNum: string) => {
    deletePurchaseOrder(id);
    setDeleteConfirmId(null);
    setToastMessage(`Purchase Order ${poNum} deleted.`);
    setTimeout(() => setToastMessage(null), 3000);
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      {/* Toast */}
      {toastMessage && (
        <div className="fixed bottom-5 right-5 z-50 bg-slate-900 text-white text-xs px-4 py-2.5 rounded-lg shadow-xl flex items-center gap-2 border border-slate-700 animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Top Banner */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-2xs p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-base font-bold text-slate-900 flex items-center gap-2">
            <Package className="w-5 h-5 text-emerald-600" />
            <span>Purchase Orders (Purchases)</span>
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Issue procurement orders to suppliers and convert directly to vendor bills with automated TDS calculations
          </p>
        </div>

        <button
          onClick={onOpenCreatePO}
          className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs transition-colors shrink-0"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>New Purchase Order</span>
        </button>
      </div>

      {/* Table & Filters */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-2xs p-4 space-y-4">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="relative w-full sm:w-80">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Search POs or vendor name..."
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-500"
            />
          </div>

          <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg text-xs font-medium">
            {['all', 'issued', 'billed', 'draft'].map(tab => (
              <button
                key={tab}
                onClick={() => setStatusFilter(tab)}
                className={`px-3 py-1 rounded-md transition-colors capitalize ${
                  statusFilter === tab ? 'bg-white text-slate-900 shadow-xs font-semibold' : 'text-slate-600'
                }`}
              >
                {tab}
              </button>
            ))}
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-600 border-collapse">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-50/75 text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
                <th className="py-2.5 px-3">Date</th>
                <th className="py-2.5 px-3">PO #</th>
                <th className="py-2.5 px-3">Vendor Name</th>
                <th className="py-2.5 px-3">Expected Date</th>
                <th className="py-2.5 px-3">Status</th>
                <th className="py-2.5 px-3 text-right">Order Amount</th>
                <th className="py-2.5 px-3 text-center">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-slate-400">
                    <Package className="w-8 h-8 text-slate-300 mx-auto mb-2 opacity-50" />
                    <p className="text-sm font-medium text-slate-600">No purchase orders recorded</p>
                    <p className="text-xs text-slate-400 mt-1">Create your first purchase order to issue to suppliers.</p>
                  </td>
                </tr>
              ) : (
                filtered.map(po => (
                  <tr key={po.id} className="hover:bg-slate-50/70 transition-colors">
                    <td className="py-3 px-3 text-slate-500 font-mono whitespace-nowrap">{po.date}</td>
                    <td className="py-3 px-3 font-semibold text-blue-600 font-mono whitespace-nowrap">
                      {po.poNumber}
                    </td>
                    <td className="py-3 px-3 font-medium text-slate-800">
                      <div>{po.vendorName}</div>
                      <div className="text-[10px] text-slate-400 font-mono">PAN: {po.vendorPan}</div>
                    </td>
                    <td className="py-3 px-3 text-slate-500 font-mono whitespace-nowrap">
                      {po.expectedDate}
                    </td>
                    <td className="py-3 px-3 whitespace-nowrap">
                      {getStatusBadge(po.status)}
                    </td>
                    <td className="py-3 px-3 text-right font-mono font-bold text-slate-900 tabular-nums whitespace-nowrap">
                      {formatMoney(po.grossAmount, po.currency)}
                    </td>
                    <td className="py-3 px-3 text-center whitespace-nowrap">
                      <div className="flex items-center justify-center gap-1">
                        {po.status !== 'billed' && (
                          <button
                            onClick={() => handleConvertToBill(po.id, po.poNumber)}
                            className="px-2 py-1 text-[11px] font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded transition-colors shadow-2xs flex items-center gap-1"
                            title="Convert to Vendor Bill"
                          >
                            <Receipt className="w-3 h-3" />
                            <span>Bill</span>
                          </button>
                        )}
                        {onEditPurchaseOrder && (
                          <button
                            onClick={() => onEditPurchaseOrder(po)}
                            className="p-1.5 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded transition-colors"
                            title="Edit Purchase Order"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                        <button
                          onClick={() => handleDuplicate(po.id, po.poNumber)}
                          className="p-1.5 text-slate-400 hover:text-emerald-600 hover:bg-emerald-50 rounded transition-colors"
                          title="Duplicate Purchase Order"
                        >
                          <Copy className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => setDeleteConfirmId(po.id)}
                          className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded transition-colors"
                          title="Delete Purchase Order"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Delete Confirmation Modal */}
      {deleteConfirmId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-xs p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-sm w-full p-6 text-center border border-slate-200">
            <div className="w-12 h-12 rounded-full bg-rose-50 text-rose-600 mx-auto flex items-center justify-center mb-4">
              <AlertTriangle className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-slate-900 mb-2">Delete Purchase Order?</h3>
            <p className="text-sm text-slate-600 mb-6">
              Are you sure you want to delete this purchase order? This action cannot be undone.
            </p>
            <div className="flex gap-3 justify-center">
              <button
                onClick={() => setDeleteConfirmId(null)}
                className="px-4 py-2 border border-slate-300 rounded-lg text-sm font-medium text-slate-700 hover:bg-slate-50 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  const po = purchaseOrders.find(p => p.id === deleteConfirmId);
                  handleDelete(deleteConfirmId, po?.poNumber || '');
                }}
                className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-lg text-sm font-medium transition-colors"
              >
                Delete PO
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

