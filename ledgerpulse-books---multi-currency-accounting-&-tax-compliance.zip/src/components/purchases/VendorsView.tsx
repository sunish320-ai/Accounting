import React, { useState } from 'react';
import { useAccounting } from '../../context/AccountingContext';
import {
  Building2,
  Plus,
  Search,
  Building,
  Edit2,
  Copy,
  Trash2,
  CheckCircle2,
  AlertTriangle
} from 'lucide-react';
import { Vendor } from '../../types';

interface VendorsViewProps {
  onOpenAddVendor: () => void;
  onEditVendor: (vendor: Vendor) => void;
  onCreatePOForVendor: (vendorId: string) => void;
  onCreateBillForVendor: (vendorId: string) => void;
}

export const VendorsView: React.FC<VendorsViewProps> = ({
  onOpenAddVendor,
  onEditVendor,
  onCreatePOForVendor,
  onCreateBillForVendor,
}) => {
  const { vendors, bills, formatMoney, tdsRates, deleteVendor, duplicateVendor } = useAccounting();
  const [searchTerm, setSearchTerm] = useState('');
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);

  const filteredVendors = vendors.filter(v =>
    v.companyName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    v.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    v.pan.toLowerCase().includes(searchTerm.toLowerCase()) ||
    v.category.toLowerCase().includes(searchTerm.toLowerCase()) ||
    (v.pincode && v.pincode.includes(searchTerm))
  );

  const handleDuplicate = (id: string, name: string) => {
    duplicateVendor(id);
    setToastMessage(`Vendor "${name}" duplicated successfully.`);
    setTimeout(() => setToastMessage(null), 3000);
  };

  const handleDelete = (id: string, name: string) => {
    deleteVendor(id);
    setDeleteConfirmId(null);
    setToastMessage(`Vendor "${name}" deleted.`);
    setTimeout(() => setToastMessage(null), 3000);
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-5 right-5 z-50 bg-slate-900 text-white text-xs px-4 py-2.5 rounded-lg shadow-xl flex items-center gap-2 border border-slate-700 animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Top Banner */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-2xs p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-base font-bold text-slate-900 flex items-center gap-2">
            <Building2 className="w-5 h-5 text-purple-600" />
            <span>Vendors & Suppliers Directory</span>
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Manage vendors, PAN verification, statutory TDS sections, pincodes, and accounts payable
          </p>
        </div>

        <button
          onClick={onOpenAddVendor}
          className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-white bg-purple-600 hover:bg-purple-700 rounded-lg shadow-xs transition-colors shrink-0"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>New Vendor</span>
        </button>
      </div>

      {/* Vendor Directory Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-2xs p-4 space-y-4">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="Search by vendor, contact, PAN, or category..."
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-purple-500"
          />
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-600 border-collapse">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-50/75 text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
                <th className="py-2.5 px-3">Company / Vendor Name</th>
                <th className="py-2.5 px-3">Category & Place of Supply</th>
                <th className="py-2.5 px-3">PAN & GSTIN</th>
                <th className="py-2.5 px-3">Address & Pincode</th>
                <th className="py-2.5 px-3">Default TDS</th>
                <th className="py-2.5 px-3 text-right">Payable Balance</th>
                <th className="py-2.5 px-3 text-center">Actions (Edit / Duplicate / Delete)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredVendors.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-slate-400">
                    <Building className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                    <p className="font-medium text-slate-600">No vendors found</p>
                    <p className="text-[11px] text-slate-400 mt-1">Add your suppliers to manage bills and statutory TDS deductions</p>
                    <button
                      onClick={onOpenAddVendor}
                      className="mt-3 inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-purple-600 hover:bg-purple-700 rounded-lg shadow-xs"
                    >
                      <Plus className="w-3.5 h-3.5" /> Add Vendor
                    </button>
                  </td>
                </tr>
              ) : (
                filteredVendors.map(vend => {
                  const vendBills = bills.filter(b => b.vendorId === vend.id && b.status !== 'paid');
                  const totalDue = vendBills.reduce((sum, b) => sum + b.balanceDue, 0);
                  const tdsObj = tdsRates.find(r => r.section === vend.defaultTdsSection);

                  return (
                    <tr key={vend.id} className="hover:bg-slate-50/70 transition-colors">
                      <td className="py-3 px-3">
                        <div className="font-bold text-slate-900">{vend.companyName}</div>
                        <div className="text-[11px] text-slate-400">Contact: {vend.name} · {vend.email}</div>
                      </td>
                      <td className="py-3 px-3">
                        <span className="font-medium text-slate-700 bg-slate-100 px-2 py-0.5 rounded text-[11px]">
                          {vend.category}
                        </span>
                        {vend.placeOfSupply && (
                          <div className="text-[10px] text-slate-500 font-medium mt-0.5">{vend.placeOfSupply}</div>
                        )}
                      </td>
                      <td className="py-3 px-3 font-mono">
                        <div className="font-bold text-slate-800">PAN: {vend.pan}</div>
                        <div className="text-[10px] text-slate-400">GSTIN: {vend.taxId}</div>
                      </td>
                      <td className="py-3 px-3 max-w-xs">
                        <div className="text-slate-700 line-clamp-1">{vend.address || '—'}</div>
                        {vend.pincode && (
                          <div className="text-[11px] text-purple-700 font-mono font-medium">
                            PIN: {vend.pincode}
                          </div>
                        )}
                      </td>
                      <td className="py-3 px-3">
                        {tdsObj ? (
                          <div className="text-purple-700 font-semibold font-mono text-[11px]">
                            {tdsObj.code} ({tdsObj.rate}%)
                          </div>
                        ) : (
                          <span className="text-slate-400">No TDS</span>
                        )}
                      </td>
                      <td className="py-3 px-3 text-right font-mono font-bold tabular-nums">
                        {totalDue > 0 ? (
                          <span className="text-rose-600">{formatMoney(totalDue, vend.currency)}</span>
                        ) : (
                          <span className="text-emerald-600 font-medium">Nil</span>
                        )}
                      </td>
                      <td className="py-3 px-3 text-center whitespace-nowrap">
                        <div className="flex items-center justify-center gap-1">
                          {/* 1. Edit */}
                          <button
                            onClick={() => onEditVendor(vend)}
                            className="p-1.5 text-slate-500 hover:text-purple-600 hover:bg-purple-50 rounded transition-colors"
                            title="Edit vendor details"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>

                          {/* 2. Duplicate */}
                          <button
                            onClick={() => handleDuplicate(vend.id, vend.companyName)}
                            className="p-1.5 text-slate-500 hover:text-emerald-600 hover:bg-emerald-50 rounded transition-colors"
                            title="Duplicate vendor"
                          >
                            <Copy className="w-3.5 h-3.5" />
                          </button>

                          {/* 3. Delete */}
                          <button
                            onClick={() => setDeleteConfirmId(vend.id)}
                            className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded transition-colors"
                            title="Delete vendor"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>

                          <div className="w-px h-3.5 bg-slate-200 mx-0.5" />

                          {/* Transactional Shortcuts */}
                          <button
                            onClick={() => onCreatePOForVendor(vend.id)}
                            className="px-2 py-1 text-[10px] font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded transition-colors"
                            title="Generate Purchase Order"
                          >
                            + PO
                          </button>
                          <button
                            onClick={() => onCreateBillForVendor(vend.id)}
                            className="px-2 py-1 text-[10px] font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded transition-colors shadow-2xs"
                            title="Record Vendor Bill"
                          >
                            + Bill
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Delete Confirmation Modal */}
      {deleteConfirmId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4">
          <div className="bg-white w-full max-w-sm rounded-xl p-5 shadow-2xl border border-slate-200 space-y-3">
            <div className="flex items-center gap-2 text-rose-600 font-bold text-sm">
              <AlertTriangle className="w-4 h-4" />
              <span>Confirm Delete Vendor</span>
            </div>
            <p className="text-xs text-slate-600">
              Are you sure you want to delete this vendor? This cannot be undone.
            </p>
            <div className="flex justify-end gap-2 pt-2">
              <button
                onClick={() => setDeleteConfirmId(null)}
                className="px-3 py-1.5 text-xs text-slate-600 hover:bg-slate-100 rounded-lg"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  const vend = vendors.find(v => v.id === deleteConfirmId);
                  if (vend) handleDelete(vend.id, vend.companyName);
                }}
                className="px-4 py-1.5 text-xs font-semibold text-white bg-rose-600 hover:bg-rose-700 rounded-lg"
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
