import React, { useState } from 'react';
import { useAccounting } from '../../context/AccountingContext';
import {
  CornerUpLeft,
  Plus,
  Search,
  CheckCircle2,
  Receipt,
  RotateCcw,
  Edit2,
  Copy,
  Trash2,
  AlertTriangle
} from 'lucide-react';
import { DebitNote, DebitNoteStatus } from '../../types';

interface PurchaseReturnsViewProps {
  onOpenCreateDebitNote: () => void;
  onEditDebitNote?: (debitNote: DebitNote) => void;
}

export const PurchaseReturnsView: React.FC<PurchaseReturnsViewProps> = ({ onOpenCreateDebitNote, onEditDebitNote }) => {
  const { debitNotes, formatMoney, updateDebitNote, deleteDebitNote, duplicateDebitNote } = useAccounting();
  const [searchTerm, setSearchTerm] = useState('');
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);

  const filtered = debitNotes.filter(dn =>
    dn.debitNoteNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
    dn.vendorName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    dn.reason.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleMarkRefunded = (id: string, num: string) => {
    updateDebitNote(id, { status: 'refunded' });
    setToastMessage(`Debit Note ${num} marked as Refunded by Vendor.`);
    setTimeout(() => setToastMessage(null), 3000);
  };

  const handleDuplicate = (id: string, num: string) => {
    duplicateDebitNote(id);
    setToastMessage(`Debit Note ${num} duplicated as draft.`);
    setTimeout(() => setToastMessage(null), 3000);
  };

  const handleDelete = (id: string, num: string) => {
    deleteDebitNote(id);
    setDeleteConfirmId(null);
    setToastMessage(`Debit Note ${num} deleted.`);
    setTimeout(() => setToastMessage(null), 3000);
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      {/* Toast */}
      {toastMessage && (
        <div className="fixed bottom-5 right-5 z-50 bg-slate-900 text-white text-xs px-4 py-2.5 rounded-lg shadow-xl flex items-center gap-2 border border-slate-700 animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Top Banner */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-2xs p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-base font-bold text-slate-900 flex items-center gap-2">
            <CornerUpLeft className="w-5 h-5 text-emerald-600" />
            <span>Purchase Returns & Debit Notes</span>
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Issue vendor debit notes for return of defective goods, service billing credits, or TDS reversals (GST Sec 34(2))
          </p>
        </div>

        <button
          onClick={onOpenCreateDebitNote}
          className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs transition-colors shrink-0"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>New Debit Note</span>
        </button>
      </div>

      {/* Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-2xs p-4 space-y-4">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="Search debit notes or vendor..."
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-500"
          />
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-600 border-collapse">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-50/75 text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
                <th className="py-2.5 px-3">Date</th>
                <th className="py-2.5 px-3">Debit Note #</th>
                <th className="py-2.5 px-3">Vendor</th>
                <th className="py-2.5 px-3">Reason / Narrative</th>
                <th className="py-2.5 px-3">Status</th>
                <th className="py-2.5 px-3 text-right">TDS Reversed</th>
                <th className="py-2.5 px-3 text-right">Net Debit Claim</th>
                <th className="py-2.5 px-3 text-center">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-12 text-center text-slate-400">
                    <CornerUpLeft className="w-8 h-8 text-slate-300 mx-auto mb-2 opacity-50" />
                    <p className="text-sm font-medium text-slate-600">No purchase returns or debit notes recorded</p>
                    <p className="text-xs text-slate-400 mt-1">Issue debit notes to vendors for item returns or price corrections.</p>
                  </td>
                </tr>
              ) : (
                filtered.map(dn => (
                  <tr key={dn.id} className="hover:bg-slate-50/70 transition-colors">
                    <td className="py-3 px-3 text-slate-500 font-mono whitespace-nowrap">{dn.date}</td>
                    <td className="py-3 px-3 font-semibold text-blue-600 font-mono whitespace-nowrap">
                      {dn.debitNoteNumber}
                    </td>
                    <td className="py-3 px-3 font-medium text-slate-800">
                      <div>{dn.vendorName}</div>
                      {dn.billId && <div className="text-[10px] text-slate-400 font-mono">Bill: {dn.billId}</div>}
                    </td>
                    <td className="py-3 px-3 text-slate-600 max-w-xs">
                      {dn.reason}
                    </td>
                    <td className="py-3 px-3 whitespace-nowrap">
                      <span className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded ${
                        dn.status === 'open' ? 'bg-blue-50 text-blue-700 border border-blue-200' :
                        dn.status === 'refunded' ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' : 'bg-slate-100 text-slate-600'
                      }`}>
                        {dn.status}
                      </span>
                    </td>
                    <td className="py-3 px-3 text-right font-mono text-blue-600 tabular-nums whitespace-nowrap">
                      {dn.tdsReversalAmount > 0 ? formatMoney(dn.tdsReversalAmount, dn.currency) : '—'}
                    </td>
                    <td className="py-3 px-3 text-right font-mono font-bold text-slate-900 tabular-nums whitespace-nowrap">
                      {formatMoney(dn.netDebitAmount, dn.currency)}
                    </td>
                    <td className="py-3 px-3 text-center whitespace-nowrap">
                      <div className="flex items-center justify-center gap-1">
                        {onEditDebitNote && (
                          <button
                            onClick={() => onEditDebitNote(dn)}
                            className="p-1.5 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded transition-colors"
                            title="Edit Debit Note"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                        <button
                          onClick={() => handleDuplicate(dn.id, dn.debitNoteNumber)}
                          className="p-1.5 text-slate-400 hover:text-emerald-600 hover:bg-emerald-50 rounded transition-colors"
                          title="Duplicate Debit Note"
                        >
                          <Copy className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => setDeleteConfirmId(dn.id)}
                          className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded transition-colors"
                          title="Delete Debit Note"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                        {dn.status === 'open' && (
                          <button
                            onClick={() => handleMarkRefunded(dn.id, dn.debitNoteNumber)}
                            className="px-2 py-1 text-[11px] font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded transition-colors ml-1"
                            title="Mark Refunded"
                          >
                            Refunded
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Delete Confirmation Modal */}
      {deleteConfirmId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-xs p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-sm w-full p-6 text-center border border-slate-200">
            <div className="w-12 h-12 rounded-full bg-rose-50 text-rose-600 mx-auto flex items-center justify-center mb-4">
              <AlertTriangle className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-slate-900 mb-2">Delete Debit Note?</h3>
            <p className="text-sm text-slate-600 mb-6">
              Are you sure you want to delete this debit note? This action cannot be undone.
            </p>
            <div className="flex gap-3 justify-center">
              <button
                onClick={() => setDeleteConfirmId(null)}
                className="px-4 py-2 border border-slate-300 rounded-lg text-sm font-medium text-slate-700 hover:bg-slate-50 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  const dn = debitNotes.find(d => d.id === deleteConfirmId);
                  handleDelete(deleteConfirmId, dn?.debitNoteNumber || '');
                }}
                className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-lg text-sm font-medium transition-colors"
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

